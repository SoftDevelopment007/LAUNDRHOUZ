package com.laundrhouz.android.activities;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.RequiresApi;

import com.github.lzyzsd.circleprogress.DonutProgress;
import com.kofigyan.stateprogressbar.StateProgressBar;
import com.laundrhouz.android.R;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import modules.base.ActivityBase;
import modules.bean.MasterOrderDetails;

public class CollectionDateStatusActivity extends ActivityBase {

    StateProgressBar stateProgressBar;
    String[] descriptionData = {"Pickup", "Clean", "Deliver"};
    MasterOrderDetails masterOrderDetails;
    DonutProgress progressBar;
    TextView textViewStatus, textViewStatusDescription, textViewPickupdate, textViewPickupTime;
    TextView textViewDeliveryTime, textViewDeliverydate;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collection_date_status);
        setToolbar();
        if (getIntent().hasExtra("masterOrderDetails")) {
            masterOrderDetails = (MasterOrderDetails) getIntent().getSerializableExtra("masterOrderDetails");
        } else if (getIntent().hasExtra("fromNotification")) {
            masterOrderDetails = (MasterOrderDetails) getIntent().getSerializableExtra("masterOrderDetailsNoti");
        }
        initComponent();
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private void initComponent() {
        stateProgressBar = findViewById(R.id.stateProgressBar);
        progressBar = findViewById(R.id.progressBar);
        textViewStatusDescription = findViewById(R.id.textViewStatusDescription);
        textViewPickupdate = findViewById(R.id.textViewPickupdate);
        textViewStatus = findViewById(R.id.textViewStatus);
        textViewPickupTime = findViewById(R.id.textViewPickupTime);
        textViewDeliveryTime = findViewById(R.id.textViewDeliveryTime);
        textViewDeliverydate = findViewById(R.id.textViewDeliverydate);

        stateProgressBar.setStateDescriptionData(descriptionData);

        if (getIntent().hasExtra("masterOrderDetails")) {
            if (masterOrderDetails.master_order_status.equalsIgnoreCase("Pending")) {
                stateProgressBar.setCurrentStateNumber(StateProgressBar.StateNumber.ONE);
                progressBar.setProgress(0);
                textViewStatus.setText(getResources().getString(R.string.pick_up));
                textViewStatusDescription.setText(getResources().getString(R.string.pickup_shortly));
            } else if (masterOrderDetails.master_order_status.equalsIgnoreCase("Processed")
                    || masterOrderDetails.master_order_status.equalsIgnoreCase("Dispatched")) {
                stateProgressBar.setCurrentStateNumber(StateProgressBar.StateNumber.TWO);
                progressBar.setProgress(50);
                textViewStatus.setText(getResources().getString(R.string.clean));
                textViewStatusDescription.setText(getResources().getString(R.string.clean_description));
            } else if (masterOrderDetails.master_order_status.equalsIgnoreCase("Delivered")) {
                stateProgressBar.setCurrentStateNumber(StateProgressBar.StateNumber.THREE);
                progressBar.setProgress(100);
                textViewStatus.setText(getResources().getString(R.string.deliver));
                textViewStatusDescription.setText(getResources().getString(R.string.lorem_your_laundry_cloths_is_cleaned_and_ready_to_deliver_to_your_home));
            }
            textViewPickupTime.setText(masterOrderDetails.pickup_time);
            setDateAndTimeForPickup(masterOrderDetails.pickup_date, textViewPickupdate);
            setDeliveryTime(masterOrderDetails.deliver_date, textViewDeliveryTime);
            setDateAndTime(masterOrderDetails.deliver_date, textViewDeliverydate);

        } else if (getIntent().hasExtra("masterOrderDetailsNoti") && masterOrderDetails != null) {

            if (masterOrderDetails.master_order_status.equalsIgnoreCase("Pending")) {
                stateProgressBar.setCurrentStateNumber(StateProgressBar.StateNumber.ONE);
                progressBar.setProgress(0);
                textViewStatus.setText(getResources().getString(R.string.pick_up));
                textViewStatusDescription.setText(getResources().getString(R.string.pickup_shortly));
            } else if (masterOrderDetails.master_order_status.equalsIgnoreCase("Processed") ||
                    masterOrderDetails.master_order_status.equalsIgnoreCase("Dispatched")) {
                stateProgressBar.setCurrentStateNumber(StateProgressBar.StateNumber.TWO);
                progressBar.setProgress(50);
                textViewStatus.setText(getResources().getString(R.string.clean));
                textViewStatusDescription.setText(getResources().getString(R.string.clean_description));
            } else if (masterOrderDetails.master_order_status.equalsIgnoreCase("Delivered")) {
                stateProgressBar.setCurrentStateNumber(StateProgressBar.StateNumber.THREE);
                progressBar.setProgress(100);
                textViewStatus.setText(getResources().getString(R.string.deliver));
                textViewStatusDescription.setText(getResources().getString(R.string.lorem_your_laundry_cloths_is_cleaned_and_ready_to_deliver_to_your_home));
            }

            textViewPickupTime.setText(masterOrderDetails.pickup_time);
            setDateAndTimeForPickup(masterOrderDetails.pickup_date, textViewPickupdate);
            setDeliveryTime(masterOrderDetails.deliver_date, textViewDeliveryTime);
            setDateAndTime(masterOrderDetails.deliver_date, textViewDeliverydate);
        }
    }

    private void setDateAndTime(String deliver_date, TextView textView) {

        @SuppressLint("SimpleDateFormat") SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date dateAndTime  = null;
        try {
            dateAndTime  = format1.parse(deliver_date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        @SuppressLint("SimpleDateFormat") DateFormat format2 = new SimpleDateFormat("EEEE,dd MMM yyyy");
        String finalDay = format2.format(dateAndTime );
        textView.setText(finalDay);

    }

    private void setDeliveryTime(String deliver_time, TextView textView) {

        @SuppressLint("SimpleDateFormat") SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date dateAndTime  = null;
        try {
            dateAndTime  = format1.parse(deliver_time);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        @SuppressLint("SimpleDateFormat") DateFormat format2 = new SimpleDateFormat("hh:mm a");
        String finalDay = format2.format(dateAndTime );
        textView.setText(finalDay);

    }

    private void setDateAndTimeForPickup(String pickUpDate, TextView textView) {

        @SuppressLint("SimpleDateFormat") SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
        Date dateAndTime = null;
        try {
            dateAndTime  = format1.parse(pickUpDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        @SuppressLint("SimpleDateFormat") DateFormat format2 = new SimpleDateFormat("EEEE,dd MMM yyyy");
        String finalDay = format2.format(dateAndTime );
        System.out.println("DAY_FROM_DATE===>>>>" + finalDay);
        textView.setText(finalDay);
    }

    private void setToolbar() {
        TextView textViewToolbarTitle = findViewById(R.id.textViewToolbarTitle);
        textViewToolbarTitle.setText(getResources().getString(R.string.collection_date));
        TextView textViewStart = findViewById(R.id.textViewStart);
        textViewStart.setVisibility(View.GONE);
    }

    @Override
    public void onBackPressed() {
        if (getIntent().hasExtra("fromNotification")) {
            Intent intent = new Intent(CollectionDateStatusActivity.this, MyOrdersActivity.class);
            intent.putExtra("fromNotification", "fromNotification");
            startActivity(intent);
            finish();
        } else {
            super.onBackPressed();
        }
    }
}
