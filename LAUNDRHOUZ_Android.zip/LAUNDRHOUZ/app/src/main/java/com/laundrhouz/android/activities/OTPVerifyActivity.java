package com.laundrhouz.android.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.laundrhouz.android.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import modules.app.AppController;
import modules.base.ActivityBase;
import modules.base.LogUtil;
import modules.blu.ServerHelper;
import modules.deserializer.BaseDeserializer;
import modules.http.BaseHttpRequest;
import modules.http.ResponseData;
import modules.validation.Validation;

public class OTPVerifyActivity extends ActivityBase implements View.OnClickListener {
    Button btn_phone_generate_otp, btn_email_send_otp, btnSignIn;
    EditText etPhoneNumber, et_email, etOTP;
    String phoneNumber, otp;
    String email;
    FirebaseAuth auth;
    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallback;
    private String verificationCode;
    LinearLayout linearLayoutGenrateOTP, linearLayoutVerifyOTP;
    Spinner spinnerForVerifyOtp;
    boolean isVerifyByEmail = false;
    List<String> verifyList;
    ArrayAdapter<String> verifyAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otpverify);
        setToolbar();
        initComponent();
        itemClickListner();
        StartFirebaseLogin();

    }

    private void setToolbar() {
        TextView textViewToolbarTitle = findViewById(R.id.textViewToolbarTitle);
        textViewToolbarTitle.setText(getResources().getString(R.string.order_confirmation));
        textViewToolbarTitle.setText("Verify OTP");
        TextView textViewStart = findViewById(R.id.textViewStart);
        ImageView imageViewLogout = findViewById(R.id.imageViewLogout);
        textViewStart.setOnClickListener(this);
        imageViewLogout.setVisibility(View.VISIBLE);
        imageViewLogout.setOnClickListener(this);
    }

    private void itemClickListner() {
        spinnerForVerifyOtp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                if (position == 0) {
                    et_email.setVisibility(View.GONE);
                    btn_email_send_otp.setVisibility(View.GONE);
                    etPhoneNumber.setVisibility(View.VISIBLE);
                    btn_phone_generate_otp.setVisibility(View.VISIBLE);
                    isVerifyByEmail = false;
                } else if (position == 1) {
                    et_email.setVisibility(View.VISIBLE);
                    btn_email_send_otp.setVisibility(View.VISIBLE);
                    etPhoneNumber.setVisibility(View.GONE);
                    btn_phone_generate_otp.setVisibility(View.GONE);
                    isVerifyByEmail = true;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });


        btn_email_send_otp.setOnClickListener(this);
        btn_phone_generate_otp.setOnClickListener(this);
        btnSignIn.setOnClickListener(this);
    }

    private void SigninWithPhone(PhoneAuthCredential credential, final boolean fromCompleteState) {
        showProgressDialog();
        auth.signInWithCredential(credential)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Log.d("OTP_Successful", "signInWithCredential:success+123");

                            FirebaseUser user = task.getResult().getUser();
                            Log.d("OTP_Successful", "signInWithCredential:USER_123" + user.getPhoneNumber());

                            if (isOnline())
                                processToInsertPhoneAndOtp(fromCompleteState);


                        } else {
                            Log.d("OTP_Fail", "signInWithCredential:USER_123_fail");
                            prefs.setIsVerify("0");
                            dismissProgressDialog();
                            Toast.makeText(OTPVerifyActivity.this, "Incorrect OTP", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void initComponent() {
        btn_email_send_otp = findViewById(R.id.btn_email_send_otp);
        btn_phone_generate_otp = findViewById(R.id.btn_phone_generate_otp);
        btnSignIn = findViewById(R.id.btn_sign_in);
        etPhoneNumber = findViewById(R.id.et_phone_number);
        etOTP = findViewById(R.id.et_otp);
        spinnerForVerifyOtp = findViewById(R.id.spinnerForVerifyOtp);
        et_email = findViewById(R.id.et_email);

        etPhoneNumber.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        et_email.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        etOTP.setBackgroundResource(R.drawable.edittext_credentials_back_white);

        linearLayoutGenrateOTP = findViewById(R.id.linearLayoutGenrateOTP);
        linearLayoutVerifyOTP = findViewById(R.id.linearLayoutVerifyOTP);

        verifyList = new ArrayList<>();
        setData();
    }

    private void setData() {
        verifyList.add("Verify by Phone Number");
        verifyList.add("Verify by Email");
        verifyAdapter = new ArrayAdapter<>(OTPVerifyActivity.this, android.R.layout.simple_spinner_item, verifyList);
        verifyAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinnerForVerifyOtp.setAdapter(verifyAdapter);

        etPhoneNumber.setText(prefs.getMobileNumber());
        etPhoneNumber.setEnabled(false);
        et_email.setText(prefs.getEmail());
        et_email.setEnabled(false);

    }

    private void StartFirebaseLogin() {
        auth = FirebaseAuth.getInstance();
        auth.setLanguageCode("en");
        mCallback = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

            @Override
            public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                super.onCodeSent(s, forceResendingToken);
                linearLayoutGenrateOTP.setVisibility(View.GONE);
                linearLayoutVerifyOTP.setVisibility(View.VISIBLE);
                verificationCode = s;
                LogUtil.debug("verificationCode1_SENT===>>>" + verificationCode);
                LogUtil.debug("verificationCode2_SENT===>>>" + forceResendingToken);

                Toast.makeText(OTPVerifyActivity.this, "Code sent.", Toast.LENGTH_SHORT).show();
                dismissProgressDialog();
            }

            @Override
            public void onVerificationCompleted(PhoneAuthCredential credential) {
               /* linearLayoutGenrateOTP.setVisibility(View.GONE);
                linearLayoutVerifyOTP.setVisibility(View.VISIBLE);
*/
                LogUtil.debug("verificationCode_COMPLETE===>>>" + credential.getSmsCode());
                SigninWithPhone(credential, true);
//                dismissProgressDialog();
            }

            @Override
            public void onVerificationFailed(FirebaseException e) {
                dismissProgressDialog();
                Toast.makeText(OTPVerifyActivity.this, "verification fialed", Toast.LENGTH_SHORT).show();
            }

        };
    }

    private boolean validation() {
        boolean check = true;
        if (!Validation.hasText(etOTP)) check = false;
        return check;
    }

    private boolean validationEmail() {
        boolean check = true;
        if (!Validation.isEmailAddress(et_email, true)) check = false;
        return check;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.textViewStart:
                onBackPressed();
                break;
            case R.id.imageViewLogout:
                Intent intent = new Intent(OTPVerifyActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
                prefs.clear();
                prefs.clearUser();
                prefs.setPostCode("");
                prefs.setPromoCodeAmount(null);
                prefs.setPromoCode(null);
                break;
            case R.id.btn_email_send_otp:
                if (isOnline())
                    processToOTPEmail();
                break;

            case R.id.btn_phone_generate_otp:
                phoneNumber = etPhoneNumber.getText().toString();
                PhoneAuthProvider.getInstance().verifyPhoneNumber(
                        phoneNumber,                     // Phone number to verify
                        60,                           // Timeout duration
                        TimeUnit.SECONDS,                // Unit of timeout
                        OTPVerifyActivity.this,        // Activity (for callback binding)
                        mCallback);
                showProgressDialog();
                break;
            case R.id.btn_sign_in:
                if (isVerifyByEmail) {
                    if (isOnline())
                        processToCheckOTPEmail();
                } else {
                    otp = etOTP.getText().toString();
                    if (!otp.equalsIgnoreCase("")) {
                        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationCode, otp);
                        SigninWithPhone(credential, false);
                    } else {
                        showMessage("Please Enter OTP.");
                    }
                }
                break;
        }
    }


   /* public void testPhoneAutoRetrieve() {
        // [START auth_test_phone_auto]
        // The test phone number and code should be whitelisted in the console.
        String phoneNumber = "+919974666136";
        String smsCode = "123456";

        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        FirebaseAuthSettings firebaseAuthSettings = firebaseAuth.getFirebaseAuthSettings();

        // Configure faking the auto-retrieval with the whitelisted numbers.
        firebaseAuthSettings.setAutoRetrievedSmsCodeForPhoneNumber(phoneNumber, smsCode);

        PhoneAuthProvider phoneAuthProvider = PhoneAuthProvider.getInstance();
        phoneAuthProvider.verifyPhoneNumber(
                phoneNumber,
                60L,
                TimeUnit.SECONDS,
                this, *//* activity *//*
                new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                    @Override
                    public void onVerificationCompleted(PhoneAuthCredential credential) {
                        // Instant verification is applied and a credential is directly returned.
                        // ...
                        showMessage("Complete...");
                    }

                    // [START_EXCLUDE]
                    @Override
                    public void onVerificationFailed(FirebaseException e) {
                        showMessage("Faild...");

                    }
                    // [END_EXCLUDE]
                });
        // [END auth_test_phone_auto]
    }*/

    private void processToOTPEmail() {

        if (!validationEmail()) {
            return;
        }
        Map<String, String> param = getParam();
        param.put("email", et_email.getText().toString());

        showProgressDialog();
        LogUtil.debug("PARAMETER====>>>>>" + param);
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.SEND_OTP_ON_MAIL, ResponseData.class, param, new Response.Listener<ResponseData>() {
            @Override
            public void onResponse(ResponseData userDetails) {
                dismissProgressDialog();
                if (userDetails.getResult()) {
                    email = et_email.getText().toString();
                    linearLayoutGenrateOTP.setVisibility(View.GONE);
                    linearLayoutVerifyOTP.setVisibility(View.VISIBLE);
                    showMessage(userDetails.getMessage());

                } else {
                    showMessage(userDetails.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                dismissProgressDialog();
                showErrorMessage(volleyError);
            }
        }, new BaseDeserializer<>(ResponseData.class));
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

    private void processToCheckOTPEmail() {

        if (!validation()) {
            return;
        }
        Map<String, String> param = getParam();
        param.put("email", email);
        param.put("otp", etOTP.getText().toString());

        showProgressDialog();
        LogUtil.debug("PARAMETER====>>>>>" + param);
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.CHECK_OTP_EMAIL, ResponseData.class, param, new Response.Listener<ResponseData>() {
            @Override
            public void onResponse(ResponseData userDetails) {
                dismissProgressDialog();
                if (userDetails.getResult()) {
                    if (getIntent().hasExtra("fromCart")) {
                        finish();
                    } else {
                        Intent intent = new Intent(OTPVerifyActivity.this, HomeActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    }
                    linearLayoutGenrateOTP.setVisibility(View.GONE);
                    linearLayoutVerifyOTP.setVisibility(View.VISIBLE);
                    prefs.setIsVerify("1");
                    auth.signOut();
                    showMessage(userDetails.getMessage());
                } else {
                    prefs.setIsVerify("0");
                    showMessage(userDetails.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                dismissProgressDialog();
                showErrorMessage(volleyError);
            }
        }, new BaseDeserializer<>(ResponseData.class));
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

    private void processToInsertPhoneAndOtp(boolean fromCompleteState) {
        if (!fromCompleteState) {
            if (!validation()) {
                return;
            }
        }
        Map<String, String> param = getParam();
        param.put("mobile_no", phoneNumber);
        if (fromCompleteState) {
            param.put("otp", "");
        } else {
            param.put("otp", etOTP.getText().toString());
        }
//        showProgressDialog();
        LogUtil.debug("PARAMETER====>>>>>" + param);
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.VERIFY_PHONE_OTP, ResponseData.class, param, new Response.Listener<ResponseData>() {
            @Override
            public void onResponse(ResponseData userDetails) {
                dismissProgressDialog();
                if (userDetails.getResult()) {
                    if (getIntent().hasExtra("fromCart")) {
                        finish();
                    } else {
                        Intent intent = new Intent(OTPVerifyActivity.this, HomeActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    }
                    prefs.setIsVerify("1");
                    auth.signOut();
                    showMessage(userDetails.getMessage());
                } else {
                    prefs.setIsVerify("0");
                    showMessage(userDetails.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                dismissProgressDialog();
                showErrorMessage(volleyError);
            }
        }, new BaseDeserializer<>(ResponseData.class));
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

}