package com.laundrhouz.android.activities;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import com.hbb20.CountryCodePicker;
import com.laundrhouz.android.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import modules.base.ActivityBaseLocation;
import modules.base.LogUtil;
import modules.bean.UserDetails;
import modules.validation.Validation;

public class SignUpActivity extends ActivityBaseLocation implements View.OnClickListener {

    EditText editTextGender, editTextPassword, editTextConfirmPassword;
    EditText editTextFirstName, editTextLastName, editTextEmail, editTextMobileNo, editTextDOB;
    //    EditText editTextCountryCode;
    Button buttonSignupNext;
    double latitude, longitude;
    CountryCodePicker countryCodePicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        setToolbar();
        initComponant();
        clickListner();
    }

    @Override
    public void updatedLocation(Location location) {
        latitude = location.getLatitude();
        longitude = location.getLongitude();

        LogUtil.debug("Latitude==>> " + latitude + " Longitude==>> " + longitude);
    }

    private void setToolbar() {
        TextView textViewToolbarTitle = findViewById(R.id.textViewToolbarTitle);
        textViewToolbarTitle.setText("Register");
        TextView textViewStart = findViewById(R.id.textViewStart);
        textViewStart.setOnClickListener(this);
    }

    private void initComponant() {
        editTextFirstName = findViewById(R.id.editTextFirstName);
        editTextFirstName.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        editTextLastName = findViewById(R.id.editTextLastName);
        editTextLastName.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextEmail.setBackgroundResource(R.drawable.edittext_credentials_back_white);
//        editTextCountryCode = findViewById(R.id.editTextCountryCode);
//        editTextCountryCode.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        editTextMobileNo = findViewById(R.id.editTextMobileNo);
        editTextMobileNo.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        editTextDOB = findViewById(R.id.editTextDOB);
        editTextDOB.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        editTextGender = findViewById(R.id.editTextGender);
        editTextGender.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        buttonSignupNext = findViewById(R.id.buttonSignupNext);

        countryCodePicker = findViewById(R.id.ccp);
        countryCodePicker.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        countryCodePicker.registerCarrierNumberEditText(editTextMobileNo);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextPassword.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        editTextConfirmPassword = findViewById(R.id.editTextConfirmPassword);
        editTextConfirmPassword.setBackgroundResource(R.drawable.edittext_credentials_back_white);
    }

    private void clickListner() {
        editTextGender.setOnClickListener(this);
        editTextDOB.setOnClickListener(this);
        buttonSignupNext.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.editTextGender:
                if (editTextGender.getText().toString().equalsIgnoreCase("Male")) {
                    editTextGender.setText("Female");
                    editTextGender.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.female, 0);
                } else {
                    editTextGender.setText("Male");
                    editTextGender.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.male, 0);
                }
                break;
            case R.id.editTextDOB:
                setDateTimeField(editTextDOB);
                break;
            case R.id.buttonSignupNext:
                if (latitude == 0 && longitude == 0) {
                    showMessage("Please Wait Location Searching...");
                    return;
                }
                if (!validation()) {
                    return;
                }

                UserDetails userDetails = new UserDetails();
                userDetails.fname = editTextFirstName.getText().toString();
                userDetails.lname = editTextLastName.getText().toString();
                userDetails.email = editTextEmail.getText().toString();
                userDetails.mobile_no = "+"+countryCodePicker.getSelectedCountryCode() + editTextMobileNo.getText().toString();
                userDetails.dob = editTextDOB.getText().toString();
                userDetails.latitude = String.valueOf(latitude);
                userDetails.longitude = String.valueOf(longitude);
                if (editTextGender.getText().toString().trim().equalsIgnoreCase("Male")) {
                    userDetails.gender = "1";
                } else {
                    userDetails.gender = "2";
                }

                Intent intent = new Intent(getApplicationContext(), AddAddressActivity.class);
                intent.putExtra("userDetails", userDetails);
                intent.putExtra("password", editTextPassword.getText().toString());

                startActivity(intent);
                break;
            case R.id.textViewStart:
                onBackPressed();
                break;
        }
    }

    private void setDateTimeField(final EditText editText) {

        Calendar newCalendar = Calendar.getInstance();
        DatePickerDialog mDatePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                @SuppressLint("SimpleDateFormat") SimpleDateFormat sd = new SimpleDateFormat("dd-MM-yyyy");
                final Date startDate = newDate.getTime();
                String fdate = sd.format(startDate);

                editText.setText(fdate);

            }
        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
        mDatePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        mDatePickerDialog.show();
    }

    private boolean validation() {
        boolean check = true;
        if (!Validation.hasText(editTextFirstName)) check = false;
        if (!Validation.hasText(editTextLastName)) check = false;
//        if (!Validation.hasText(editTextCountryCode)) check = false;
        if (!Validation.hasText(editTextMobileNo)) check = false;
        if (!Validation.isEmailAddress(editTextEmail, true)) check = false;
        if (!Validation.hasText(editTextDOB)) check = false;
        if (!Validation.hasText(editTextPassword)) check = false;
        if (!Validation.isConfirmPassword(editTextPassword, editTextConfirmPassword)) check = false;

        return check;
    }

/*
    private void check() {
        String countryCode = editTextCountryCode.getText().toString().trim();
        String phoneNumber = editTextMobileNo.getText().toString().trim();
        if (countryCode.length() > 0 && phoneNumber.length() > 0) {
            if (isValidPhoneNumber(phoneNumber)) {
                boolean status = validateUsing_libphonenumber(countryCode, phoneNumber);
                if (status) {
                    showMessage("Valid Phone Number (libphonenumber)");
                } else {
                    showMessage("Invalid Phone Number (libphonenumber)");
                }
            } else {
                showMessage("Invalid Phone Number (isValidPhoneNumber)");
            }
        } else {
            Toast.makeText(getApplicationContext(), "Country Code and Phone Number is required", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isValidPhoneNumber(CharSequence phoneNumber) {
        if (!TextUtils.isEmpty(phoneNumber)) {
            return Patterns.PHONE.matcher(phoneNumber).matches();
        }
        return false;
    }

    private boolean validateUsing_libphonenumber(String countryCode, String phNumber) {
        PhoneNumberUtil phoneNumberUtil = PhoneNumberUtil.getInstance();
        String isoCode = phoneNumberUtil.getRegionCodeForCountryCode(Integer.parseInt(countryCode));
        Phonenumber.PhoneNumber phoneNumber = null;
        try {
            //phoneNumber = phoneNumberUtil.parse(phNumber, "IN");  //if you want to pass region code
            phoneNumber = phoneNumberUtil.parse(phNumber, isoCode);
        } catch (NumberParseException e) {
            System.err.println(e);
        }

        boolean isValid = phoneNumberUtil.isValidNumber(phoneNumber);
        if (isValid) {
            String internationalFormat = phoneNumberUtil.format(phoneNumber, PhoneNumberUtil.PhoneNumberFormat.INTERNATIONAL);
            Toast.makeText(this, "Phone Number is Valid " + internationalFormat, Toast.LENGTH_LONG).show();
            return true;
        } else {
            Toast.makeText(this, "Phone Number is Invalid " + phoneNumber, Toast.LENGTH_LONG).show();
            return false;
        }
    }*/
}
