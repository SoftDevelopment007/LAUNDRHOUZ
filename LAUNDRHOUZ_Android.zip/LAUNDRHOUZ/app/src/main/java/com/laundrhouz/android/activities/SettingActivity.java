package com.laundrhouz.android.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.laundrhouz.android.R;
import com.laundrhouz.android.fragments.ChangePasswordFragment;
import com.laundrhouz.android.fragments.EditProfileFragment;

import modules.adapter.AdapterViewPager;
import modules.base.ActivityBase;

public class SettingActivity extends ActivityBase {

    private TabLayout tabLayoutOrderHistory;
    private ViewPager viewPagerOrderHistory;
    private AdapterViewPager adapterViewPager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        setToolbar();
        initComponent();
    }

    private void initComponent() {

        tabLayoutOrderHistory = findViewById(R.id.tabLayoutOrderHistory);
        viewPagerOrderHistory = findViewById(R.id.viewPagerOrderHistory);
        adapterViewPager = new AdapterViewPager(getSupportFragmentManager());

        setUpViewPagerAndTabLayout();

    }

    private void setToolbar() {
        TextView textViewToolbarTitle = findViewById(R.id.textViewToolbarTitle);
        textViewToolbarTitle.setText("Settings");
        TextView textViewStart = findViewById(R.id.textViewStart);
        textViewStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void setUpViewPagerAndTabLayout() {
        adapterViewPager.addFragment(new EditProfileFragment(), "Edit Profile");
        adapterViewPager.addFragment(new ChangePasswordFragment(), "Change Password");
        viewPagerOrderHistory.setAdapter(adapterViewPager);
        tabLayoutOrderHistory.setupWithViewPager(viewPagerOrderHistory);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.viewPagerOrderHistory);
        if (fragment != null) {
            fragment.onActivityResult(requestCode, resultCode, data);
        }
    }
}
