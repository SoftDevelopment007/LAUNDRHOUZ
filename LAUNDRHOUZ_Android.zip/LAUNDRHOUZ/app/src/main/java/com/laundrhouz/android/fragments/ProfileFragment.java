package com.laundrhouz.android.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.laundrhouz.android.R;
import com.laundrhouz.android.activities.ChooseDefaultAddressActivity;
import com.laundrhouz.android.activities.ChoosePhoneNumberActivity;
import com.laundrhouz.android.activities.LoginActivity;
import com.laundrhouz.android.activities.MyCleanBagPlanActivity;
import com.laundrhouz.android.activities.MyOrdersActivity;
import com.laundrhouz.android.activities.PaymentMethodActivity;
import com.laundrhouz.android.activities.SettingActivity;
import com.laundrhouz.android.activities.ShareAppActivity;

import java.util.Objects;

import modules.base.FragmentBase;
import modules.blu.ServerHelper;

public class ProfileFragment extends FragmentBase implements View.OnClickListener {

    private RelativeLayout relativeLayoutAddress, relativeLayoutMyOrders, relativeLayoutPhone, relativeLayoutPaymentMethod, relativeLayoutMyCleanBagPlan,
            relativeLayoutRefer;
    private TextView textViewUserName, textViewEmail;
    ImageView imageViewSetting, imageViewUserProfile;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        initComponent(view);
        Objects.requireNonNull(getActivity()).findViewById(R.id.textViewStart).setOnClickListener(this);
        return view;
    }

    private void initComponent(View view) {
        textViewUserName = view.findViewById(R.id.textViewUserName);
        textViewEmail = view.findViewById(R.id.textViewEmail);
        imageViewSetting = view.findViewById(R.id.imageViewSetting);
        imageViewUserProfile = view.findViewById(R.id.imageViewUserProfile);

        relativeLayoutAddress = view.findViewById(R.id.relativeLayoutAddress);
        relativeLayoutAddress.setOnClickListener(this);
        relativeLayoutMyOrders = view.findViewById(R.id.relativeLayoutMyOrders);
        relativeLayoutMyOrders.setOnClickListener(this);
        relativeLayoutPhone = view.findViewById(R.id.relativeLayoutPhone);
        relativeLayoutPhone.setOnClickListener(this);
        relativeLayoutPaymentMethod = view.findViewById(R.id.relativeLayoutPaymentMethod);
        relativeLayoutPaymentMethod.setOnClickListener(this);
        relativeLayoutMyCleanBagPlan = view.findViewById(R.id.relativeLayoutMyCleanBagPlan);
        relativeLayoutMyCleanBagPlan.setOnClickListener(this);
        relativeLayoutRefer = view.findViewById(R.id.relativeLayoutRefer);
        relativeLayoutRefer.setOnClickListener(this);

        imageViewSetting.setOnClickListener(this);

        setData();
    }

    private void setData() {
        textViewUserName.setText(prefs.getFirstName() + " " + prefs.getLastName());
        textViewEmail.setText(prefs.getEmail());
        Glide.with(context)
//                .load(ServerHelper.IMAGE_PATH + prefs.getUserImage())
                .load(R.drawable.login_icon)
                .apply(RequestOptions.placeholderOf(R.drawable.user).error(R.drawable.user))
                .into(imageViewUserProfile);
    }

    @Override
    public void onClick(View view) {
        Intent intent;
        switch (view.getId()) {
            case R.id.textViewStart:
                intent = new Intent(getContext(), LoginActivity.class);
                startActivity(intent);
                Objects.requireNonNull(getActivity()).finish();
                prefs.clear();
                prefs.clearUser();
                prefs.setPostCode("");
                prefs.setPromoCodeAmount(null);
                prefs.setPromoCode(null);
                break;
            case R.id.relativeLayoutAddress:
                intent = new Intent(getContext(), ChooseDefaultAddressActivity.class);
                startActivity(intent);
                break;
            case R.id.relativeLayoutPhone:
                intent = new Intent(getContext(), ChoosePhoneNumberActivity.class);
                startActivity(intent);
                break;
            case R.id.relativeLayoutMyOrders:
                intent = new Intent(getContext(), MyOrdersActivity.class);
                startActivity(intent);
                break;
            case R.id.relativeLayoutPaymentMethod:
                intent = new Intent(getContext(), PaymentMethodActivity.class);
                startActivity(intent);
                break;
            case R.id.relativeLayoutMyCleanBagPlan:
                intent = new Intent(getContext(), MyCleanBagPlanActivity.class);
                startActivity(intent);
                break;
            case R.id.relativeLayoutRefer:
                intent = new Intent(getContext(), ShareAppActivity.class);
                startActivity(intent);
                break;
            case R.id.imageViewSetting:
                intent = new Intent(getContext(), SettingActivity.class);
                startActivity(intent);
                break;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        setData();
    }
}
