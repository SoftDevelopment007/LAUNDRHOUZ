package com.laundrhouz.android.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.laundrhouz.android.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import modules.adapter.DeliveryMethodAdapter;
import modules.app.AppController;
import modules.base.ActivityBase;
import modules.base.LogUtil;
import modules.bean.AddressDetails;
import modules.bean.InsertOrderDetails;
import modules.blu.ServerHelper;
import modules.deserializer.BaseDeserializerList;
import modules.http.BaseHttpRequest;
import modules.http.ResponseData;
import modules.utils.AppConstants;

public class DeliveryMethodActivity extends ActivityBase implements View.OnClickListener {

    RecyclerView recyclerViewAddress;
    Button buttonConfirm;
    List<AddressDetails> addressDetailsList;
    DeliveryMethodAdapter deliveryMethodAdapter;
    RelativeLayout addAnotherAddress;
    boolean isLoaded = false;
    InsertOrderDetails insertOrderDetails = new InsertOrderDetails();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_method);
        setToolbar();
        if (getIntent().hasExtra("orederDetails")) {
            insertOrderDetails = (InsertOrderDetails) getIntent().getSerializableExtra("orederDetails");
        }

        initComponent();
        itemClickListner();
    }

    private void setToolbar() {
        TextView textViewToolbarTitle = findViewById(R.id.textViewToolbarTitle);
        textViewToolbarTitle.setText(getResources().getString(R.string.delivery_method));
        TextView textViewStart = findViewById(R.id.textViewStart);
        textViewStart.setOnClickListener(this);
        TextView textViewEnd = findViewById(R.id.textViewEnd);
        textViewEnd.setVisibility(View.VISIBLE);
        textViewEnd.setBackground(null);
        textViewEnd.setText(getResources().getString(R.string.next));
        textViewEnd.setOnClickListener(this);
    }

    private void initComponent() {
        addAnotherAddress = findViewById(R.id.addAnotherAddress);
        recyclerViewAddress = findViewById(R.id.recyclerViewAddress);
        buttonConfirm = findViewById(R.id.buttonConfirm);

        addressDetailsList = new ArrayList<>();


        setData();
    }

    private void setData() {
        deliveryMethodAdapter = new DeliveryMethodAdapter(DeliveryMethodActivity.this, addressDetailsList);
        recyclerViewAddress.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerViewAddress.setAdapter(deliveryMethodAdapter);

        if (isOnline())
            processToLoadAddress();
    }

    private void itemClickListner() {
        buttonConfirm.setOnClickListener(this);
        addAnotherAddress.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.textViewStart:
                onBackPressed();
                break;
            case R.id.textViewEnd:
                for (int i = 0; i < addressDetailsList.size(); i++) {
                    if (addressDetailsList.get(i).isChecked) {

                        insertOrderDetails.address_id = addressDetailsList.get(i).add_id;
                        insertOrderDetails.address = addressDetailsList.get(i).address
                                + " " + addressDetailsList.get(i).city
                                + " " + addressDetailsList.get(i).country
                                + " " + addressDetailsList.get(i).post_code;
                        break;
                    }
                }
                Intent intent = new Intent(getApplicationContext(), PaymentMethodActivity.class);
                intent.putExtra("orederDetails", insertOrderDetails);
                startActivity(intent);
                break;
            case R.id.buttonConfirm:
                String add_id = "";
                for (int i = 0; i < addressDetailsList.size(); i++) {
                    if (addressDetailsList.get(i).isChecked) {
                        add_id = addressDetailsList.get(i).add_id;
                        insertOrderDetails.address = addressDetailsList.get(i).address
                                + " " + addressDetailsList.get(i).city
                                + " " + addressDetailsList.get(i).country
                                + " " + addressDetailsList.get(i).post_code;
                        break;
                    }
                }
                insertOrderDetails.address_id = add_id;
                Intent intent1 = new Intent(getApplicationContext(), PaymentMethodActivity.class);
                intent1.putExtra("orederDetails", insertOrderDetails);
                startActivity(intent1);
                break;
            case R.id.addAnotherAddress:
                Intent intent2 = new Intent(getApplicationContext(), AddAnotherAddressActivity.class);
                startActivityForResult(intent2, AppConstants.ACTIVITY_FOR_RESULT_ADDRESS_DATA);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data != null && resultCode == RESULT_OK) {
            if (isOnline())
                processToLoadAddress();
        }
    }

    private void processToLoadAddress() {
        Map<String, String> param = new HashMap<>();
        param.put("user_id", prefs.getUserId());
        showProgressDialog();
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.FETCH_ADDRESS, ResponseData.class, param, new Response.Listener<ResponseData>() {
            @Override
            public void onResponse(ResponseData response) {
                dismissProgressDialog();
                addressDetailsList.clear();
                if (response.getResult()) {
                    List<AddressDetails> tempList = (List<AddressDetails>) response.getData();
                    addressDetailsList.addAll(tempList);
                    LogUtil.debug("LIST=====>>>>>" + addressDetailsList.size());
                } else {
                    showMessage(response.getMessage());
                }
                deliveryMethodAdapter.notifyDataSetChanged();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dismissProgressDialog();
                showErrorMessage(error);
            }
        }, new BaseDeserializerList<>(ResponseData.class, AddressDetails.class));
        baseHttpRequest.setToken(prefs.getAccessTocken());
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }
/*
    @Override
    protected void onResume() {
        super.onResume();
        if (isLoaded) {
            if (isOnline())
                processToLoadAddress();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        isLoaded = true;
    }*/
}
