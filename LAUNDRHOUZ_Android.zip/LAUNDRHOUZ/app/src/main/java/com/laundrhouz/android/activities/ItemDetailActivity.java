package com.laundrhouz.android.activities;

import android.app.ActivityOptions;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.laundrhouz.android.R;

import java.util.ArrayList;
import java.util.List;

import modules.adapter.FaqListAdapter;
import modules.adapter.ItemDetailAdapter;
import modules.adapter.PrepaidOfferAdapter;
import modules.adapter.RelatedOfferAdapter;
import modules.adapter.SpecialOfferAdapter;
import modules.base.ActivityBase;
import modules.base.LogUtil;
import modules.bean.FaqListDetails;
import modules.bean.ItemDetails;
import modules.bean.SubcategoryDetails;
import modules.blu.ServerHelper;
import modules.customeviews.NonScrollExpandableListView;
import modules.room_db.dao.CartDetails;

public class ItemDetailActivity extends ActivityBase implements View.OnClickListener {

    NonScrollExpandableListView expandableListViewFAQ;
    List<FaqListDetails> faqListDetailsList;
    FaqListAdapter faqListAdapter;
    SubcategoryDetails subcategoryDetails;
    TextView textViewDescription;
    ImageView imageViewLoadingIcon, imageViewItem;
    TextView textViewShirts;
    CollapsingToolbarLayout collapsing_toolbar;
    TextView textViewToolbarTitle;
    ImageView textViewStart;
    TextView textViewEnd;

    RecyclerView recyclerViewShirts;
    List<ItemDetails> itemDetailsList;
    ItemDetailAdapter itemDetailAdapter;

    RecyclerView recyclerViewSpecialOffers;
    List<ItemDetails> specialOfferList;
    SpecialOfferAdapter specialOfferAdapter;

    RecyclerView recyclerViewPrepaidOffer;
    List<ItemDetails> prepaidOfferList;
    PrepaidOfferAdapter prepaidOfferAdapter;

    RecyclerView recyclerViewRelatedOffer;
    List<ItemDetails> relatedOfferList;
    RelatedOfferAdapter relatedOfferAdapter;
    AppBarLayout appbar;
    LinearLayout linearLayoutSubCategory, linearLayoutPrPaid, linearLayoutRelated, linearLayoutSepcialOffer;
    Button buttonGotoCart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail2);
//        setContentView(R.layout.activity_item_detail);

//        setToolbar();
        setToolbar2();
        initComponent();
    }

    private void initComponent() {
        recyclerViewShirts = findViewById(R.id.recyclerViewShirts);
        recyclerViewSpecialOffers = findViewById(R.id.recyclerViewSpecialOffers);
        expandableListViewFAQ = findViewById(R.id.expandableListViewFAQ);
        textViewDescription = findViewById(R.id.textViewDescription);
        imageViewLoadingIcon = findViewById(R.id.imageViewLoadingIcon);
        imageViewItem = findViewById(R.id.imageViewItem);
        textViewShirts = findViewById(R.id.textViewShirts);
        buttonGotoCart = findViewById(R.id.buttonGotoCart);


        recyclerViewPrepaidOffer = findViewById(R.id.recyclerViewPrepaidOffer);
        recyclerViewRelatedOffer = findViewById(R.id.recyclerViewRelatedOffer);

        linearLayoutSubCategory = findViewById(R.id.linearLayoutSubCategory);
        linearLayoutPrPaid = findViewById(R.id.linearLayoutPrPaid);
        linearLayoutRelated = findViewById(R.id.linearLayoutRelated);
        linearLayoutSepcialOffer = findViewById(R.id.linearLayoutSepcialOffer);

        faqListDetailsList = new ArrayList<>();
        itemDetailsList = new ArrayList<>();
        prepaidOfferList = new ArrayList<>();
        specialOfferList = new ArrayList<>();
        relatedOfferList = new ArrayList<>();

        buttonGotoCart.setOnClickListener(this);

        setData();
    }

    private void setData() {

        if (getIntent().hasExtra("subCategoryDetails")) {

            subcategoryDetails = (SubcategoryDetails) getIntent().getSerializableExtra("subCategoryDetails");
            faqListDetailsList.addAll(subcategoryDetails.faqlist);
//            itemDetailsList.addAll(subcategoryDetails.itemlist);
            textViewDescription.setText(subcategoryDetails.description);

            for (int i = 0; i < subcategoryDetails.itemlist.size(); i++) {
                if (subcategoryDetails.itemlist.get(i).subtype_id.equalsIgnoreCase("1")) {
                    itemDetailsList.add(subcategoryDetails.itemlist.get(i));
                } else if (subcategoryDetails.itemlist.get(i).subtype_id.equalsIgnoreCase("2")) {
                    prepaidOfferList.add(subcategoryDetails.itemlist.get(i));
                } else if (subcategoryDetails.itemlist.get(i).subtype_id.equalsIgnoreCase("3")) {
                    relatedOfferList.add(subcategoryDetails.itemlist.get(i));
                } else if (subcategoryDetails.itemlist.get(i).subtype_id.equalsIgnoreCase("4")) {
                    specialOfferList.add(subcategoryDetails.itemlist.get(i));
                }
            }

            if (!subcategoryDetails.name.equalsIgnoreCase("")) {
                textViewShirts.setText(subcategoryDetails.name);
            }

            appbar.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
                @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
                @Override
                public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {

                    if ((collapsing_toolbar.getHeight() + verticalOffset) < (2 * ViewCompat.getMinimumHeight(collapsing_toolbar))) {
                        textViewStart.setImageResource(R.drawable.ic_back_white);
                        textViewToolbarTitle.setTextColor(getResources().getColor(R.color.white));
                        textViewEnd.setTextColor(getResources().getColor(R.color.white));
                        textViewToolbarTitle.setText(subcategoryDetails.name);
                        textViewToolbarTitle.setVisibility(View.VISIBLE);
                    } else {
                        textViewStart.setImageResource(R.drawable.ic_back);
                        textViewToolbarTitle.setTextColor(getResources().getColor(R.color.black));
                        textViewEnd.setTextColor(getResources().getColor(R.color.black));
                        textViewToolbarTitle.setVisibility(View.GONE);
                    }
                }
            });
        }

        itemDetailAdapter = new ItemDetailAdapter(ItemDetailActivity.this, itemDetailsList);
        itemDetailAdapter.setItemCart(new ItemDetailAdapter.ItemCart() {
            @Override
            public void addTocart(int position, int quantity) {

                if (appDatabase.cartDetailsDao().isExist(itemDetailsList.get(position).item_id)) {
                    appDatabase.cartDetailsDao().update(quantity, itemDetailsList.get(position).item_id);
                } else {

                    CartDetails cartDetails = new CartDetails();
                    cartDetails.product_id = itemDetailsList.get(position).item_id;
                    cartDetails.category_id = itemDetailsList.get(position).cat_id;
                    cartDetails.sub_category_id = itemDetailsList.get(position).subcat_id;
                    cartDetails.product_name = itemDetailsList.get(position).item_name;
                    cartDetails.product_image = ServerHelper.IMAGE_PATH + subcategoryDetails.image;
                    cartDetails.original_price = itemDetailsList.get(position).item_originalprice;

                    if (itemDetailsList.get(position).item_discprice == 0) {
                        cartDetails.discount_price = itemDetailsList.get(position).item_originalprice;
                    } else {
                        cartDetails.discount_price = itemDetailsList.get(position).item_discprice;
                    }
                    cartDetails.quantity = quantity;
                    cartDetails.short_discription = itemDetailsList.get(position).short_desc;
                    appDatabase.cartDetailsDao().insert(cartDetails);
                }
            }
        });
        recyclerViewShirts.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerViewShirts.setAdapter(itemDetailAdapter);

        specialOfferAdapter = new SpecialOfferAdapter(ItemDetailActivity.this, specialOfferList, subcategoryDetails.image);
        recyclerViewSpecialOffers.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerViewSpecialOffers.setAdapter(specialOfferAdapter);

        prepaidOfferAdapter = new PrepaidOfferAdapter(ItemDetailActivity.this, prepaidOfferList, subcategoryDetails.image);
        recyclerViewPrepaidOffer.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerViewPrepaidOffer.setAdapter(prepaidOfferAdapter);

        relatedOfferAdapter = new RelatedOfferAdapter(ItemDetailActivity.this, relatedOfferList, subcategoryDetails.image);
        recyclerViewRelatedOffer.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerViewRelatedOffer.setAdapter(relatedOfferAdapter);


        faqListAdapter = new FaqListAdapter(getApplicationContext(), faqListDetailsList);
        expandableListViewFAQ.setAdapter(faqListAdapter);

        imageViewLoadingIcon.setVisibility(View.VISIBLE);
        Glide.with(ItemDetailActivity.this)
                .load(ServerHelper.IMAGE_PATH + subcategoryDetails.image)
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        imageViewLoadingIcon.setVisibility(View.GONE);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        imageViewLoadingIcon.setVisibility(View.GONE);
                        return false;
                    }
                })
                .apply(new RequestOptions().error(R.drawable.no_image_found))
                .into(imageViewItem);

        setLayOut();
    }

    private void setLayOut() {

        if (itemDetailsList.isEmpty()) {
            linearLayoutSubCategory.setVisibility(View.GONE);
        }
        if (prepaidOfferList.isEmpty()) {
            linearLayoutPrPaid.setVisibility(View.GONE);
        }
        if (relatedOfferList.isEmpty()) {
            linearLayoutRelated.setVisibility(View.GONE);
        }
        if (specialOfferList.isEmpty()) {
            linearLayoutSepcialOffer.setVisibility(View.GONE);
        }
    }

    private void setToolbar() {
        TextView textViewToolbarTitle = findViewById(R.id.textViewToolbarTitle);
        textViewToolbarTitle.setText(getResources().getString(R.string.phone));
        TextView textViewStart = findViewById(R.id.textViewStart);
        textViewStart.setOnClickListener(this);
        TextView textViewEnd = findViewById(R.id.textViewEnd);
        textViewEnd.setVisibility(View.VISIBLE);
        textViewEnd.setBackground(null);
        textViewEnd.setText(getResources().getString(R.string.done));
        textViewEnd.setOnClickListener(this);
        textViewEnd.setTextColor(getResources().getColor(R.color.black));
    }

    private void setToolbar2() {
        textViewToolbarTitle = findViewById(R.id.textViewToolbarTitle);
        textViewStart = findViewById(R.id.textViewStart);
        textViewEnd = findViewById(R.id.textViewEnd);

//        textViewToolbarTitle.setText(getResources().getString(R.string.phone));
        textViewStart.setOnClickListener(this);
        textViewEnd.setVisibility(View.GONE);
        textViewToolbarTitle.setVisibility(View.GONE);
        textViewEnd.setBackground(null);
        textViewEnd.setText(getResources().getString(R.string.done));
        textViewEnd.setOnClickListener(this);
        textViewEnd.setTextColor(getResources().getColor(R.color.black));

        collapsing_toolbar = findViewById(R.id.collapsing_toolbar);
        appbar = findViewById(R.id.appbar);


    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.textViewStart:
                onBackPressed();
                break;
            case R.id.textViewEnd:
                onBackPressed();
                break;
            case R.id.buttonGotoCart:
                Intent intent = new Intent(ItemDetailActivity.this, HomeActivity.class);
                intent.putExtra("forCart", true);
                ActivityOptions options = ActivityOptions.makeCustomAnimation(context, R.anim.slide_in_right, R.anim.slide_out_left);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent, options.toBundle());
                finish();//finishing activity
                break;
        }
    }
}
