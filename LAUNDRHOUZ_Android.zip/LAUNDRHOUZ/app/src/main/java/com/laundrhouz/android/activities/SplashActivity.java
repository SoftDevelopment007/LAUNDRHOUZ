package com.laundrhouz.android.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.crashlytics.android.Crashlytics;
import com.laundrhouz.android.R;

import io.fabric.sdk.android.Fabric;
import modules.base.ActivityBase;

public class SplashActivity extends ActivityBase {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Fabric.with(SplashActivity.this, new Crashlytics());
        setContentView(R.layout.activity_splash);
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
               /* Intent intent = new Intent(getApplicationContext(), OTPVerifyActivity.class);
                startActivity(intent);
                finish();*/


                if (prefs.isLogin()) {
                    if (prefs.getIsVerify().equalsIgnoreCase("0")) {
                        Intent intent = new Intent(getApplicationContext(), OTPVerifyActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                        startActivity(intent);
                        finish();
                    }
                } else if (prefs.getPostCode() != null && !prefs.getPostCode().equalsIgnoreCase("")) {
                    Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Intent intent = new Intent(getApplicationContext(), CheckLocationActivity.class);
//                    Intent intent = new Intent(getApplicationContext(), LocationActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        }, 3000);
    }
}
