package com.laundrhouz.android.activities;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.laundrhouz.android.R;

import java.util.Map;

import modules.app.AppController;
import modules.base.ActivityBase;
import modules.base.LogUtil;
import modules.bean.UserDetails;
import modules.blu.ServerHelper;
import modules.deserializer.BaseDeserializer;
import modules.http.BaseHttpRequest;
import modules.http.ResponseData;
import modules.validation.Validation;

public class LoginActivity extends ActivityBase implements View.OnClickListener {

    TextView textViewSignUp, textViewStatus, textViewContent;
    EditText editTextUsername, editTextPassword;
    //    String emailOrPhone, Password;
    int step = 1;
    Button buttonLogin;
//    String userName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        LogUtil.debug("GCM_TOCKENNNN===>>>>" + prefs.getGcmToken());
        initComponent();
    }

    private void initComponent() {
        textViewSignUp = findViewById(R.id.textViewSignUp);
        SpannableString signUp = new SpannableString("Don't have an account? Sign up");
        signUp.setSpan(new StyleSpan(Typeface.BOLD), 23, 30, 0);
        signUp.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.black)), 23, 30, 0);
        textViewSignUp.setText(signUp);
        buttonLogin = findViewById(R.id.buttonLogin);
        textViewStatus = findViewById(R.id.textViewStatus);
        textViewContent = findViewById(R.id.textViewContent);
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextUsername.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextPassword.setBackgroundResource(R.drawable.edittext_credentials_back_white);

        buttonLogin.setOnClickListener(this);
        textViewSignUp.setOnClickListener(this);
    }


    @Override
    public void onBackPressed() {
        switch (step) {
            case 1:
                super.onBackPressed();
                break;
            case 2:
              /*  if (emailOrPhone == null) {
                    editTextUsername.setHint(getResources().getString(R.string.email_or_phone_number));
                    editTextUsername.setInputType(InputType.TYPE_CLASS_TEXT);
                } else
                    editTextUsername.setText(emailOrPhone);
                */

                editTextUsername.setVisibility(View.VISIBLE);
                editTextPassword.setVisibility(View.GONE);
                editTextPassword.setText("");

                buttonLogin.setText(getResources().getString(R.string.next));
                textViewStatus.setText(getResources().getString(R.string.sign_into_existing_account));
                textViewContent.setText(getResources().getString(R.string.enter_your_credentials_to_login_to_account));
                editTextUsername.setBackgroundResource(R.drawable.edittext_credentials_back_white);
                step = 1;

                break;
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.buttonLogin:
                if (step == 1) {
                    if (isOnline())
                        processToVerifyEmailOrMobile();
                } else if (step == 2) {
                    if (isOnline())
                        processToCheckLogin();
                }
                break;
            case R.id.textViewSignUp:
                Intent intent = new Intent(getApplicationContext(), SignUpActivity.class);
                startActivity(intent);
                break;

        }
    }

    private void processToVerifyEmailOrMobile() {

        if (!validation()) {
            return;
        }
        Map<String, String> param = getParam();
        param.put("email_mno", editTextUsername.getText().toString());

        showProgressDialog();
        LogUtil.debug("PARAMETER====>>>>>" + param);
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.VERIFY_EMAIL_MOBILE, ResponseData.class, param, new Response.Listener<ResponseData>() {
            @Override
            public void onResponse(ResponseData userDetails) {
                dismissProgressDialog();
                if (userDetails.getResult()) {
                    editTextUsername.setVisibility(View.GONE);
                    editTextPassword.setVisibility(View.VISIBLE);
                    buttonLogin.setText(getResources().getString(R.string.signin));
                    step = 2;
                } else {
                    showMessage(userDetails.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                dismissProgressDialog();
                showErrorMessage(volleyError);
            }
        }, new BaseDeserializer<>(ResponseData.class));
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

    private void processToCheckLogin() {

        if (!validationForPassword()) {
            return;
        }
        Map<String, String> param = getParam();
        param.put("username", editTextUsername.getText().toString());
        param.put("password", editTextPassword.getText().toString());
        param.put("gcm_id", prefs.getGcmToken());

        showProgressDialog();
        LogUtil.debug("PARAMETER====>>>>>" + param);
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.CHECK_LOGIN, UserDetails.class, param, new Response.Listener<UserDetails>() {
            @Override
            public void onResponse(UserDetails userDetails) {
                dismissProgressDialog();
                if (userDetails.getResult()) {

                    editTextUsername.setBackgroundResource(R.drawable.edittext_credentials_back_green);
                    textViewStatus.setText(getResources().getString(R.string.congrats));
                    textViewContent.setText(getResources().getString(R.string.you_ve_successfully_provide_credentials_to_login));

                    editTextUsername.setText("");
                    editTextPassword.setText("");

                    saveDataToLocal(userDetails);

                } else {
                    showMessage(userDetails.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                dismissProgressDialog();
                showErrorMessage(volleyError);
            }
        }, new BaseDeserializer<>(UserDetails.class));
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

    private void saveDataToLocal(UserDetails userDetails) {
        prefs.setUserId(userDetails.id);
        prefs.setFirstName(userDetails.fname);
        prefs.setLastName(userDetails.lname);
        prefs.setEmail(userDetails.email);
        prefs.setEmailVerifiedAt(userDetails.email_verified_at);
        prefs.setMobileNumber(userDetails.mobile_no);
        prefs.setDob(userDetails.dob);
        prefs.setGender(userDetails.gender);
        prefs.setUserImage(userDetails.logo);
        prefs.setLatitude(userDetails.latitude);
        prefs.setLongitude(userDetails.longitude);
        prefs.setDeviceType(userDetails.device_type);
        prefs.setGcmId(userDetails.gcm_id);
        prefs.setUserRole(userDetails.user_role);
        prefs.setTocken(userDetails.token);
        prefs.setAccessTocken(userDetails.access_token);
        prefs.setIsVerify(userDetails.is_verify);
        prefs.setIsActive(userDetails.is_active);
        prefs.setIsDelete(userDetails.is_delete);
        prefs.setCreatedAt(userDetails.created_at);
        prefs.setUpdateAt(userDetails.updated_at);
        prefs.setDefaultAddressId(userDetails.add_id);
        prefs.setAddressId(userDetails.add_id);
        prefs.setAddress(userDetails.address);
        prefs.setCity(userDetails.city);
        prefs.setPostCode(userDetails.post_code);
        prefs.setCountryId(userDetails.country);

        prefs.setDefaultPaymentId(userDetails.payment_id);
        prefs.setPaymentId(userDetails.payment_id);
        prefs.setPaymentMethod(userDetails.payment_method);
        prefs.setPaymentUniiqId(userDetails.payment_uniqid);
        prefs.setMyRefrrelCode(userDetails.my_referral_code);
        prefs.setPaymentPostcode(userDetails.postcode);
        prefs.setPlanId(userDetails.plan_id);

        if (getIntent().hasExtra("fromCart")) {
            if (prefs.getIsVerify().equalsIgnoreCase("1")) {
                finish();
            } else {
                Intent intent = new Intent(getApplicationContext(), OTPVerifyActivity.class);
                intent.putExtra("fromCart", "fromCart");
                startActivity(intent);
                finish();
            }
        } else {
            if (prefs.getIsVerify().equalsIgnoreCase("0")) {
                Intent intent = new Intent(getApplicationContext(), OTPVerifyActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }/* else if (prefs.getPlanId() != null && prefs.getPlanId().equalsIgnoreCase("")) {
                Intent intent = new Intent(getApplicationContext(), MyCleanBagPlanActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            } */else {
                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            }
        }
    }

    private boolean validation() {
        boolean check = true;
        if (!Validation.hasText(editTextUsername)) check = false;
        return check;
    }

    private boolean validationForPassword() {
        boolean check = true;
        if (!Validation.hasText(editTextPassword)) check = false;
        return check;
    }
}
