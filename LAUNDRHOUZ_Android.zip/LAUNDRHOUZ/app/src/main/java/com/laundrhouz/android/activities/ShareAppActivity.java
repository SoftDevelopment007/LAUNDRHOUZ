package com.laundrhouz.android.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.laundrhouz.android.BuildConfig;
import com.laundrhouz.android.R;

import modules.base.ActivityBase;

public class ShareAppActivity extends ActivityBase implements View.OnClickListener {

    TextView textViewRefrealCode;
    LinearLayout linearLayoutShare;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_app);
        setToolbar();
        initializeAllView();
    }

    private void initializeAllView() {
        textViewRefrealCode = findViewById(R.id.textViewRefrealCode);
        textViewRefrealCode.setText(prefs.getMyRefrrelCode());
        linearLayoutShare = findViewById(R.id.linearLayoutShare);
        linearLayoutShare.setOnClickListener(this);
    }

    private void setToolbar() {
        TextView textViewStart = findViewById(R.id.textViewStart);
        textViewStart.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.linearLayoutShare:
                try {
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("text/plain");
                    shareIntent.putExtra(Intent.EXTRA_SUBJECT, "My application name");
                    String shareMessage = "\nRegister with " + prefs.getMyRefrrelCode() + " and earn discount on your first order on " + getResources().getString(R.string.app_name) + "\n\n ";
                    shareMessage = shareMessage + "Download app now   https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID + "\n\n";
                    shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                    startActivity(Intent.createChooser(shareIntent, "Choose Anyone"));
                } catch (Exception e) {
                    //e.toString();
                }
                break;
            case R.id.textViewStart:
                onBackPressed();
                break;
        }
    }
}
