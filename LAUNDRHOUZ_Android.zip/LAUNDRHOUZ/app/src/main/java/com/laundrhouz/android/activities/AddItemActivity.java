package com.laundrhouz.android.activities;

import android.content.Intent;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.laundrhouz.android.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import modules.adapter.ItemCategoryAdapter;
import modules.app.AppController;
import modules.base.ActivityBase;
import modules.bean.SearchCategoryDetails;
import modules.blu.ServerHelper;
import modules.deserializer.BaseDeserializerList;
import modules.http.BaseHttpRequest;
import modules.http.ResponseData;

public class AddItemActivity extends ActivityBase implements View.OnClickListener {

    RecyclerView recyclerviewItemCategory;
    ItemCategoryAdapter itemCategoryAdapter;
    List<SearchCategoryDetails> categoryDetailsList;
    EditText editTextSearchItem;
    ImageView imageViewBack, imageVIewClose;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);
        setToolbar();
        initComponent();
        itemClickListner();
    }

    private void setToolbar() {
        ImageView imageViewBack = findViewById(R.id.imageViewBack);
        ImageView imageVIewClose = findViewById(R.id.imageVIewClose);
        editTextSearchItem = findViewById(R.id.editTextSearchItem);

        imageViewBack.setOnClickListener(this);
        imageVIewClose.setOnClickListener(this);
    }

    private void initComponent() {
        recyclerviewItemCategory = findViewById(R.id.recyclerviewItemCategory);
        imageViewBack = findViewById(R.id.imageViewBack);
        imageVIewClose = findViewById(R.id.imageVIewClose);

        categoryDetailsList = new ArrayList<>();
        showProgressDialog();

        setData();
    }

    private void setData() {
        itemCategoryAdapter = new ItemCategoryAdapter(AddItemActivity.this, categoryDetailsList);
        recyclerviewItemCategory.setLayoutManager(new LinearLayoutManager(AddItemActivity.this));
        recyclerviewItemCategory.setAdapter(itemCategoryAdapter);

        if (isOnline())
            processToSearchItem("");

    }

    private void itemClickListner() {
        editTextSearchItem.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (isOnline())
                    processToSearchItem(editTextSearchItem.getText().toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
    }

    private void processToSearchItem(String searchText) {
        Map<String, String> param = new HashMap<>();
        param.put("user_id", prefs.getUserId());
        param.put("item_name", searchText);

        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.FETCH_ITEM_FILTER, ResponseData.class, param, new Response.Listener<ResponseData>() {
            @Override
            public void onResponse(ResponseData response) {
                dismissProgressDialog();
                if (response.getResult()) {
                    categoryDetailsList.clear();
                    List<SearchCategoryDetails> tempList = (List<SearchCategoryDetails>) response.getData();
                    categoryDetailsList.addAll(tempList);
                } else {
                    categoryDetailsList.clear();
                }
                itemCategoryAdapter.notifyDataSetChanged();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dismissProgressDialog();
                showErrorMessage(error);
            }
        }, new BaseDeserializerList<>(ResponseData.class, SearchCategoryDetails.class));
        baseHttpRequest.setToken(prefs.getAccessTocken());
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.imageViewBack:
                onBackPressed();
                break;
            case R.id.imageVIewClose:
                editTextSearchItem.setText("");
                hideKeyBoard();
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Intent intent = new Intent();
        setResult(2, intent);
    }
}
