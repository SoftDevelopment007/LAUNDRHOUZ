package com.laundrhouz.android.activities;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;

import com.laundrhouz.android.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import modules.adapter.TimeSlotAdapter;
import modules.base.ActivityBase;
import modules.base.LogUtil;
import modules.bean.InsertOrderDetails;
import modules.bean.PaymentMethodDetails;
import modules.bean.TimeSlotDetails;

public class CollectionDateActivity extends ActivityBase implements View.OnClickListener {

    RecyclerView recyclerViewTimeSlot;
    TimeSlotAdapter timeSlotAdapter;
    Button buttonSchedule;
    CalendarView datePicker;
    List<TimeSlotDetails> timeSlotDetailsList;
    List<TimeSlotDetails> tempList;
    long currentDate, selectedDate;
    long selectTomorrowDate;
    InsertOrderDetails insertOrderDetails = new InsertOrderDetails();
    PaymentMethodDetails paymentMethodDetails;
    String collectionDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collection_date);
        setToolbar();

        if (getIntent().hasExtra("orederDetails")) {
            insertOrderDetails = (InsertOrderDetails) getIntent().getSerializableExtra("orederDetails");
            paymentMethodDetails = (PaymentMethodDetails) getIntent().getSerializableExtra("paymentDetails");

        }

        initComponent();
        itemClickListner();
    }

    private void setToolbar() {
        TextView textViewToolbarTitle = findViewById(R.id.textViewToolbarTitle);
        textViewToolbarTitle.setText(getResources().getString(R.string.collection_date));
        TextView textViewStart = findViewById(R.id.textViewStart);
        textViewStart.setOnClickListener(this);
    }

    private void initComponent() {
        datePicker = findViewById(R.id.datePicker);
        datePicker.setMinDate(System.currentTimeMillis() - 1000);
        buttonSchedule = findViewById(R.id.buttonSchedule);
        recyclerViewTimeSlot = findViewById(R.id.recyclerViewTimeSlot);

        timeSlotDetailsList = new ArrayList<>();
        tempList = new ArrayList<>();

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 1);

        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        Date c = Calendar.getInstance().getTime();
        Date calTomorrow = cal.getTime();

        String formattedDate = df.format(c);
        collectionDate = formattedDate;

        String formattedDateTomorrow = df.format(calTomorrow);

        try {
            Date select_date = df.parse(formattedDate);
            Date current_date = df.parse(formattedDate);
            Date tomorrow_date = df.parse(formattedDateTomorrow);

            currentDate = current_date.getTime();
            selectedDate = select_date.getTime();
            selectTomorrowDate = tomorrow_date.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }

        setData();
    }

    private void setData() {
        timeSlotDetailsList.add(new TimeSlotDetails("08:00 am", "10:00 am"));
        timeSlotDetailsList.add(new TimeSlotDetails("11:00 am", "01:00 pm"));
        timeSlotDetailsList.add(new TimeSlotDetails("02:00 pm", "04:00 pm"));

        tempList.addAll(timeSlotDetailsList);

        timeSlotAdapter = new TimeSlotAdapter(CollectionDateActivity.this, timeSlotDetailsList);
        timeSlotAdapter.setiItemClick(new TimeSlotAdapter.ItemClick() {
            @Override
            public void timeSelect(int position) {

                if (selectedDate == currentDate) {

                    @SuppressLint("SimpleDateFormat") SimpleDateFormat displayFormat = new SimpleDateFormat("HH:mm");
                    @SuppressLint("SimpleDateFormat") SimpleDateFormat parseFormat = new SimpleDateFormat("hh:mm a");
                    Date date = null;
                    try {
                        date = parseFormat.parse(timeSlotDetailsList.get(position).start_time);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                    if (splitString(getCurrentTime()) < splitString(displayFormat.format(date))) {
                        for (int i = 0; i < timeSlotDetailsList.size(); i++) {
                            timeSlotDetailsList.get(i).isValid = false;
                        }

                        timeSlotDetailsList.get(position).isValid = true;
                    } else {
                        for (int i = 0; i < timeSlotDetailsList.size(); i++) {
                            timeSlotDetailsList.get(i).isValid = false;
                        }
                        timeSlotDetailsList.get(position).isValid = false;
                        showMessage("Please Select Valid Time Slot...");
                    }

                } else {
                    @SuppressLint("SimpleDateFormat") SimpleDateFormat displayFormat = new SimpleDateFormat("HH:mm");
                    @SuppressLint("SimpleDateFormat") SimpleDateFormat parseFormat = new SimpleDateFormat("hh:mm a");
                    Date date = null;
                    try {
                        date = parseFormat.parse(timeSlotDetailsList.get(position).start_time);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                    for (int i = 0; i < timeSlotDetailsList.size(); i++) {
                        timeSlotDetailsList.get(i).isValid = false;
                    }
                    timeSlotDetailsList.get(position).isValid = true;
                }

                timeSlotAdapter.notifyDataSetChanged();
            }
        });
        recyclerViewTimeSlot.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerViewTimeSlot.setAdapter(timeSlotAdapter);
    }


    public void setAdapter() {

    }

    public static String getCurrentTime() {
        //date output format
        @SuppressLint("SimpleDateFormat") SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm a");
        Calendar cal = Calendar.getInstance();
        return dateFormat.format(cal.getTime());
    }

    public static int splitString(String time) {
        String[] str = time.split(":");
        return Integer.parseInt(str[0]);
    }

    private void itemClickListner() {
        buttonSchedule.setOnClickListener(this);

        datePicker.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                // display the selected date by using a toast
                SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");

                month = month + 1;
                String date = dayOfMonth + "/" + month + "/" + year;

                collectionDate = date;
                dayOfMonth = dayOfMonth + 1;
                String tomorrowDate = dayOfMonth + "/" + month + "/" + year;

                Date c = Calendar.getInstance().getTime();
                String formattedDate = df.format(c);

                for (int i = 0; i < timeSlotDetailsList.size(); i++) {
                    timeSlotDetailsList.get(i).isValid = false;
                }
                timeSlotAdapter.notifyDataSetChanged();

                try {
                    Date tomorrow_Date = df.parse(tomorrowDate);
                    Date select_date = df.parse(date);
                    Date current_date = df.parse(formattedDate);
                    currentDate = current_date.getTime();
                    selectedDate = select_date.getTime();
                    selectTomorrowDate = tomorrow_Date.getTime();
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.textViewStart:
                onBackPressed();
                break;
            case R.id.buttonSchedule:
                boolean check = false;
                String timeSlot = "";

                for (int i = 0; i < timeSlotDetailsList.size(); i++) {
                    if (timeSlotDetailsList.get(i).isValid) {
                        timeSlot = timeSlotDetailsList.get(i).start_time + " - " + timeSlotDetailsList.get(i).end_time;
                        check = true;
                        break;
                    }
                }

                if (check) {
                    LogUtil.debug("TIME_SLOT====>>>" + timeSlot.trim());

                    insertOrderDetails.pickup_time = timeSlot.trim();
                    insertOrderDetails.pickup_date = collectionDate;

                    Intent intent = new Intent(getApplicationContext(), DeliveryDateActivity.class);
                    intent.putExtra("selectedDate", selectTomorrowDate);
                    intent.putExtra("orderDetails", insertOrderDetails);
                    intent.putExtra("paymentDetails", paymentMethodDetails);
                    startActivity(intent);
                } else {
                    showMessage("Please Select Collection Time Slot...");
                }


        }
    }


}
