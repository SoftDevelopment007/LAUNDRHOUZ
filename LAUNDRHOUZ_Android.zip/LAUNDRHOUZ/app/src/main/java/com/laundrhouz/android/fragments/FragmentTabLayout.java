package com.laundrhouz.android.fragments;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.laundrhouz.android.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import modules.adapter.ItemsAdapter;
import modules.app.AppController;
import modules.base.FragmentBase;
import modules.base.LogUtil;
import modules.bean.CategoryDetails;
import modules.bean.SubcategoryDetails;
import modules.blu.ServerHelper;
import modules.deserializer.BaseDeserializerList;
import modules.http.BaseHttpRequest;
import modules.http.ResponseData;

public class FragmentTabLayout extends FragmentBase {

    View view;
    RecyclerView recyclerview_subCaegory;
    ItemsAdapter itemsAdapter;
    CategoryDetails categoryDetail;
    List<SubcategoryDetails> subcategoryDetailsList;
    boolean isLoaded = false;
    TextView tvNorecord;

    public static FragmentTabLayout getInstance(CategoryDetails categoryDetails, int position) {
        FragmentTabLayout fragmentTabLayout = new FragmentTabLayout();
        Bundle bundle = new Bundle();
        bundle.putSerializable("newsDetails", categoryDetails);
        bundle.putInt("position", position);
        fragmentTabLayout.setArguments(bundle);
        return fragmentTabLayout;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_tab_layout, container, false);
        initComponents();

        return view;
    }

    private void initComponents() {

        categoryDetail = (CategoryDetails) getArguments().getSerializable("newsDetails");
        subcategoryDetailsList = new ArrayList<>();

        recyclerview_subCaegory = view.findViewById(R.id.recyclerview_subCaegory);
        tvNorecord = view.findViewById(R.id.tvNorecord);

        itemsAdapter = new ItemsAdapter(getActivity(), subcategoryDetailsList);

//        recyclerview_subCaegory.setLayoutManager(new GridLayoutManager(getContext(), 2, LinearLayoutManager.VERTICAL, false));
        recyclerview_subCaegory.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerview_subCaegory.setAdapter(itemsAdapter);

//        if (!isLoaded) {
        if (isOnline())
            processToLoadNewsPost();
//        }
    }

    private void processToLoadNewsPost() {
        Map<String, String> param = new HashMap<>();
//        param.put("user_id", "1");
        param.put("cat_id", categoryDetail.category_id);
        showProgressDialog();
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper. FETCH_SUB_CATEGORY, ResponseData.class, param, new Response.Listener<ResponseData>() {
            @Override
            public void onResponse(ResponseData response) {
                dismissProgressDialog();
                subcategoryDetailsList.clear();
                if (response.getResult()) {
                    subcategoryDetailsList.addAll((List<SubcategoryDetails>) response.getData());
                    LogUtil.debug("POSTLIST=====>>>>>" + subcategoryDetailsList.size());
                }
                itemsAdapter.notifyDataSetChanged();
                isLoaded = true;
                setLayoutData();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dismissProgressDialog();
                showErrorMessage(error);
                setLayoutData();

            }
        }, new BaseDeserializerList<>(ResponseData.class, SubcategoryDetails.class));
//        baseHttpRequest.setToken("MTVmOTA1M2It");
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

    private void setLayoutData() {
        if (subcategoryDetailsList.isEmpty()) {
            tvNorecord.setVisibility(View.VISIBLE);
            recyclerview_subCaegory.setVisibility(View.GONE);
        } else {
            tvNorecord.setVisibility(View.GONE);
            recyclerview_subCaegory.setVisibility(View.VISIBLE);
        }
    }

    /*@Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            if (isLoaded) {
                if (isOnline())
                    processToLoadNewsPost();
            }
        }
    }*/
}
