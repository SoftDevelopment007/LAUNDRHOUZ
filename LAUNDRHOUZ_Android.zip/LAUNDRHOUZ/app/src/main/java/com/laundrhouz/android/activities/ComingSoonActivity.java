package com.laundrhouz.android.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.laundrhouz.android.R;

import modules.base.ActivityBase;

public class ComingSoonActivity extends ActivityBase implements View.OnClickListener {

    TextView tvContinueWithApp, textViewSignIn;
    ImageView imageViewEmaiSubmit;
    String postalCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coming_soon);
        initComponant();
        itemClickListner();

        if (getIntent().hasExtra("postalCode")) {
            postalCode = getIntent().getStringExtra("postalCode");
        }
    }

    private void initComponant() {
        tvContinueWithApp = findViewById(R.id.tvContinueWithApp);
        imageViewEmaiSubmit = findViewById(R.id.imageViewEmaiSubmit);
        textViewSignIn = findViewById(R.id.textViewSignIn);
    }

    private void itemClickListner() {
        tvContinueWithApp.setOnClickListener(this);
        imageViewEmaiSubmit.setOnClickListener(this);
        textViewSignIn.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tvContinueWithApp:
                prefs.setPostCode(postalCode);
                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
                break;
            case R.id.imageViewEmaiSubmit:
                break;

            case R.id.textViewSignIn:
                Intent i = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(i);
                break;
        }
    }
}
