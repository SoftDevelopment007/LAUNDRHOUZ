package com.laundrhouz.android.activities;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.laundrhouz.android.R;

public class OrderConfirmedActivity extends AppCompatActivity implements View.OnClickListener {

    Button buttonConfirmOrder;
    TextView textViewTrackOrder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_confirmed);
        setToolbar();
        initComponent();
    }

    private void initComponent() {
        textViewTrackOrder = findViewById(R.id.textViewTrackOrder);
        textViewTrackOrder.setOnClickListener(this);
        buttonConfirmOrder = findViewById(R.id.buttonConfirmOrder);
        buttonConfirmOrder.setOnClickListener(this);
    }

    private void setToolbar() {
        TextView textViewToolbarTitle = findViewById(R.id.textViewToolbarTitle);
        textViewToolbarTitle.setText(getResources().getString(R.string.order_confirmed));
        TextView textViewStart = findViewById(R.id.textViewStart);
        textViewStart.setVisibility(View.GONE);
    }

    @Override
    public void onClick(View view) {
        Intent intent;
        switch (view.getId()) {
            case R.id.buttonConfirmOrder:
                intent = new Intent(getApplicationContext(), HomeActivity.class);
                startActivity(intent);
                finish();
                break;
            case R.id.textViewTrackOrder:
                break;
        }
    }
}
