package com.laundrhouz.android.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.laundrhouz.android.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import modules.adapter.LaundryPlanAdapter;
import modules.app.AppController;
import modules.base.ActivityBase;
import modules.base.LogUtil;
import modules.bean.PlanDetails;
import modules.bean.UserDetails;
import modules.blu.ServerHelper;
import modules.deserializer.BaseDeserializer;
import modules.deserializer.BaseDeserializerList;
import modules.http.BaseHttpRequest;
import modules.http.ResponseData;

public class MyCleanBagPlanActivity extends ActivityBase implements View.OnClickListener {

    RecyclerView recyclerViewFirst, recyclerViewSecond, recyclerViewThird;
    List<PlanDetails> planDetailsList;
    LaundryPlanAdapter laundryPlanAdapterFirst;
    UserDetails userDetails;
    String password, from;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_clean_bag_plan);
        if (getIntent() != null) {
            from = getIntent().getStringExtra("from");
            userDetails = (UserDetails) getIntent().getSerializableExtra("user");
            password = getIntent().getStringExtra("password");
        }
        setToolbar();
        initComponent();
    }

    private void initComponent() {
        recyclerViewFirst = findViewById(R.id.recyclerViewFirst);
        recyclerViewSecond = findViewById(R.id.recyclerViewSecond);
        recyclerViewThird = findViewById(R.id.recyclerViewThird);
        RecyclerView.LayoutManager recyclerViewFirstLayoutManager = new LinearLayoutManager(getApplicationContext());
        /*RecyclerView.LayoutManager recyclerViewSecondLayoutManager = new LinearLayoutManager(getApplicationContext());
        RecyclerView.LayoutManager recyclerViewThirdLayoutManager = new LinearLayoutManager(getApplicationContext());*/
        recyclerViewFirst.setLayoutManager(recyclerViewFirstLayoutManager);
        /*recyclerViewSecond.setLayoutManager(recyclerViewSecondLayoutManager);
        recyclerViewThird.setLayoutManager(recyclerViewThirdLayoutManager);*/
        planDetailsList = new ArrayList<>();
        setFirstData();
        laundryPlanAdapterFirst = new LaundryPlanAdapter(planDetailsList, new LaundryPlanAdapter.Click() {
            @Override
            public void onClick(PlanDetails planDetails) {
                if (isOnline())
                    if (userDetails != null)
                        processToRegister(planDetails, true);
                    else
                        processToChangePlan(planDetails);
            }
        });
        recyclerViewFirst.setAdapter(laundryPlanAdapterFirst);
        /*stringListSecond = new ArrayList<>();
        setSecondData();
        laundryPlanAdapterSecond = new LaundryPlanAdapter(stringListSecond);
        recyclerViewSecond.setAdapter(laundryPlanAdapterSecond);
        stringListThird = new ArrayList<>();
        setThirdData();
        laundryPlanAdapterThird = new LaundryPlanAdapter(stringListThird);
        recyclerViewThird.setAdapter(laundryPlanAdapterThird);*/
    }

    private void processToRegister(PlanDetails planDetails, boolean isUsingPlan) {

        Long timeStamp = System.currentTimeMillis() / 1000L;

        Map<String, String> param = getParam();
        param.put("fname", userDetails.fname);
        param.put("lname", userDetails.lname);
        param.put("email", userDetails.email);
        param.put("password", password);
        param.put("gender", userDetails.gender);

        param.put("dob", userDetails.dob);
        param.put("mobile_number", userDetails.mobile_no);
        param.put("gcm_id", prefs.getGcmToken());
        param.put("timestamp", String.valueOf(timeStamp).trim());
        param.put("user_role", "Customer");
        param.put("post_code", userDetails.post_code);
        param.put("country", userDetails.country);
        param.put("city", userDetails.city);
        param.put("useraddress", userDetails.address);
        param.put("latitude", userDetails.latitude);
        param.put("logitude", userDetails.longitude);

        param.put("payment_method", userDetails.payment_method);
        param.put("payment_uniqid", userDetails.payment_uniqid);
        param.put("mm_yy", userDetails.mm_yy);
        param.put("postcode", userDetails.post_code);

        if (isUsingPlan) {
            param.put("plan_id", planDetails.plan_id);
            param.put("weight", planDetails.weight);
        } else {
            param.put("plan_id", "");
            param.put("weight", "");
        }


        showProgressDialog();
        LogUtil.debug("PARAMETER====>>>>>" + param);
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.USER_REGISTER, UserDetails.class, param, new Response.Listener<UserDetails>() {
            @Override
            public void onResponse(UserDetails userDetails) {
                dismissProgressDialog();
                if (userDetails.getResult()) {
                    LogUtil.debug("SUCCESSSS=====>>>" + userDetails.getMessage());
                    showMessage(userDetails.getMessage());

                    Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();

                } else {
                    showMessage(userDetails.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                dismissProgressDialog();
                showErrorMessage(volleyError);
            }
        }, new BaseDeserializer<>(UserDetails.class));
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

    private void processToChangePlan(PlanDetails planDetails) {
        /*showProgressDialog();
        Map<String, String> param = new HashMap<>();
        param.put("user_id", prefs.getUserId());

        LogUtil.debug("PARAMETER====>>>>>" + param);
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.CHECK_LOGIN, UserDetails.class, param, new Response.Listener<UserDetails>() {
            @Override
            public void onResponse(UserDetails userDetails) {
                dismissProgressDialog();
                if (userDetails.getResult()) {


                } else {
                    showMessage(userDetails.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                dismissProgressDialog();
                showErrorMessage(volleyError);
            }
        }, new BaseDeserializer<>(UserDetails.class));
        AppController.getInstance().addToRequestQueue(baseHttpRequest);*/
    }

   /* private void setThirdData() {
        stringListThird.clear();
        stringListThird.add("Home");
        stringListThird.add("Bath Met");
        stringListThird.add("Bed Sheet");
    }

    private void setSecondData() {
        stringListSecond.add("The Pond - 25 lbs/month-$35.00");
        stringListSecond.add("The Lake - 50 lbs/month-$35.00");
        stringListSecond.add("The River - 100 lbs/month-$35.00");
        stringListSecond.add("The Ocean - 150 lbs/month-$35.00");
    }*/

    private void setFirstData() {
        showProgressDialog();
        Map<String, String> param = new HashMap<>();

        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.FETCH_PLAN, ResponseData.class, param, new Response.Listener<ResponseData>() {
            @Override
            public void onResponse(ResponseData response) {
                dismissProgressDialog();
                if (response.getResult()) {
                    List<PlanDetails> tempList = (List<PlanDetails>) response.getData();
                    planDetailsList.addAll(tempList);
                    laundryPlanAdapterFirst.notifyDataSetChanged();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dismissProgressDialog();
                showErrorMessage(error);
            }
        }, new BaseDeserializerList<>(ResponseData.class, PlanDetails.class));
        baseHttpRequest.setToken(prefs.getAccessTocken());
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

    private void setToolbar() {
        TextView textViewToolbarTitle = findViewById(R.id.textViewToolbarTitle);
        textViewToolbarTitle.setText(getResources().getString(R.string.my_clean_bag_plan));
        TextView textViewStart = findViewById(R.id.textViewStart);
        TextView textViewEnd = findViewById(R.id.textViewEnd);
        textViewEnd.setBackground(null);
        textViewEnd.setBackgroundDrawable(null);
        textViewEnd.setText(getResources().getString(R.string.skip));

        if (from != null && from.equalsIgnoreCase("AddPaymentMethodActivity")) {
            textViewEnd.setVisibility(View.VISIBLE);
        } else {
            textViewEnd.setVisibility(View.GONE);
        }
        textViewStart.setOnClickListener(this);
        textViewEnd.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.textViewStart:
                onBackPressed();
                break;
            case R.id.textViewEnd:
                PlanDetails planDetails = new PlanDetails();
                processToRegister(planDetails, false);
                break;
        }
    }
}
