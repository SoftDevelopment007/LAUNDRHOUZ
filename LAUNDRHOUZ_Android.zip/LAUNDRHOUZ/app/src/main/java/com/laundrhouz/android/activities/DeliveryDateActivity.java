package com.laundrhouz.android.activities;

import android.annotation.TargetApi;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.RequiresApi;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

import com.laundrhouz.android.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import modules.base.ActivityBase;
import modules.base.LogUtil;
import modules.bean.InsertOrderDetails;
import modules.bean.PaymentMethodDetails;

public class DeliveryDateActivity extends ActivityBase implements View.OnClickListener {

    Button buttonSchedule;
    DatePicker datePicker;
    TimePicker timePicker;
    TextView textViewPickATime;
    long date = 0;
    InsertOrderDetails insertOrderDetails = new InsertOrderDetails();
    PaymentMethodDetails paymentMethodDetails;
    String selectDate = "";

    @TargetApi(Build.VERSION_CODES.O)
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_date);
        setToolbar();
        initComponent();


        itemClickListner();


    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void itemClickListner() {
        datePicker.setOnDateChangedListener(new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker datePicker, int year, int month, int dayOfMonth) {
                SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
                month = month + 1;

                String date = dayOfMonth + "/" + month + "/" + year;
                selectDate = date;
            }
        });

    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void initComponent() {
        buttonSchedule = findViewById(R.id.buttonSchedule);
        datePicker = findViewById(R.id.datePicker);
        timePicker = findViewById(R.id.timePicker);
        textViewPickATime = findViewById(R.id.textViewPickATime);


        timePicker.setIs24HourView(false);
        buttonSchedule.setOnClickListener(this);

        if (getIntent().hasExtra("selectedDate")) {
            date = getIntent().getLongExtra("selectedDate", 0);
            insertOrderDetails = (InsertOrderDetails) getIntent().getSerializableExtra("orderDetails");
            paymentMethodDetails = (PaymentMethodDetails) getIntent().getSerializableExtra("paymentDetails");
            datePicker.setMinDate(date);
        }
    }


    private void setToolbar() {
        TextView textViewToolbarTitle = findViewById(R.id.textViewToolbarTitle);
        textViewToolbarTitle.setText(getResources().getString(R.string.deliver_date));
        TextView textViewStart = findViewById(R.id.textViewStart);
        textViewStart.setOnClickListener(this);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.textViewStart:
                onBackPressed();
                break;
            case R.id.buttonSchedule:
                String deliveryDateAndTime = "";
//                String time = timePicker.getHour() + ":" + timePicker.getMinute() + ":" + "00" +" "+ getTime(timePicker.getHour());
                String time = timePicker.getHour() + ":" + timePicker.getMinute() + ":" + "00";
                LogUtil.debug("TIMEEEEEEE===>>>" + time);

                if (!selectDate.equalsIgnoreCase("")) {
                    deliveryDateAndTime = selectDate + " " + time;
                    LogUtil.debug("DATEEEEEE===>>>" + selectDate);
                } else {
                    deliveryDateAndTime = getDate(date, "dd/MM/yyyy") + " " + time;
                    LogUtil.debug("DATEEEEEE_1===>>>" + getDate(date, "dd/MM/yyyy"));
                }
                if (!validationTime(time)) {
                    return;
                }
                if (!validation(deliveryDateAndTime)) {
                    return;
                }
                insertOrderDetails.deliver_date = deliveryDateAndTime;
                Intent intent = new Intent(getApplicationContext(), OrderConfirmationActivity.class);
                intent.putExtra("orderDetails", insertOrderDetails);
                intent.putExtra("paymentDetails", paymentMethodDetails);
                startActivity(intent);
        }
    }

    public static String getDate(long milliSeconds, String dateFormat) {
        // Create a DateFormatter object for displaying date in specified format.
        SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);

        // Create a calendar object that will convert the date and time value in milliseconds to date.
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliSeconds);
        return formatter.format(calendar.getTime());
    }

    public static String getTime(int hourOfDay) {
        String AM_PM;
        if (hourOfDay < 12) {
            AM_PM = "AM";
        } else {
            AM_PM = "PM";
        }
        return AM_PM;
    }

    private boolean validationTime(String time) {
        boolean check = true;
        if (time.equalsIgnoreCase("")) {
            showMessage("Please Select Valid Time...");
            check = false;
        }
        return check;
    }

    private boolean validation(String deliveryDateAndTime) {
        boolean check = true;
        if (deliveryDateAndTime.equalsIgnoreCase("")) {
            showMessage("Please Select Valid Date...");
            check = false;
        }
        return check;
    }
}
