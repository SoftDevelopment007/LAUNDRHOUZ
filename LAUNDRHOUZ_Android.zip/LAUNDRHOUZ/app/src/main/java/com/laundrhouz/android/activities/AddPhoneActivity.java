package com.laundrhouz.android.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.laundrhouz.android.R;

import java.util.Map;

import modules.app.AppController;
import modules.base.ActivityBase;
import modules.base.LogUtil;
import modules.bean.PhoneNumberDetails;
import modules.blu.ServerHelper;
import modules.deserializer.BaseDeserializer;
import modules.http.BaseHttpRequest;
import modules.http.ResponseData;
import modules.validation.Validation;

public class AddPhoneActivity extends ActivityBase implements View.OnClickListener {

    EditText editTextPlaceType, editTextPhoneNumber;
    Button buttonAddPhone, buttonUpdatePhone;
    PhoneNumberDetails phoneDetails = new PhoneNumberDetails();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_phone);
        setToolbar();
        initComponent();
    }

    private void initComponent() {
        editTextPlaceType = findViewById(R.id.editTextPlaceType);
        editTextPhoneNumber = findViewById(R.id.editTextPhoneNumber);
        buttonAddPhone = findViewById(R.id.buttonAddPhone);
        buttonUpdatePhone = findViewById(R.id.buttonUpdatePhone);
        editTextPhoneNumber.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        editTextPlaceType.setBackgroundResource(R.drawable.edittext_credentials_back_white);

        buttonAddPhone.setOnClickListener(this);
        buttonUpdatePhone.setOnClickListener(this);

        if (getIntent().hasExtra("forUpdate")) {
            phoneDetails = (PhoneNumberDetails) getIntent().getSerializableExtra("phoneDetails");

            buttonAddPhone.setVisibility(View.GONE);
            buttonUpdatePhone.setVisibility(View.VISIBLE);

            editTextPlaceType.setText(phoneDetails.place_type);
            editTextPhoneNumber.setText(phoneDetails.phone);
            LogUtil.debug("here====>>>>");

        } else {
            buttonAddPhone.setVisibility(View.VISIBLE);
            buttonUpdatePhone.setVisibility(View.GONE);
            LogUtil.debug("here====>>>>ELSE");
        }
    }

    private void setToolbar() {
        TextView textViewToolbarTitle = findViewById(R.id.textViewToolbarTitle);
        textViewToolbarTitle.setText(getResources().getString(R.string.phone));
        TextView textViewStart = findViewById(R.id.textViewStart);
        textViewStart.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.textViewStart:
                onBackPressed();
                break;
            case R.id.buttonAddPhone:
                if (isOnline())
                    processToInsertAddPhoneNumber();
                break;

            case R.id.buttonUpdatePhone:
                if (isOnline())
                    processToUpdatePhoneNumber();
                break;
        }
    }

    private void processToInsertAddPhoneNumber() {

        if (!validation()) {
            return;
        }
        Map<String, String> param = getParam();
        param.put("user_id", prefs.getUserId());
        param.put("place_type", editTextPlaceType.getText().toString());
        param.put("phone", editTextPhoneNumber.getText().toString());

        showProgressDialog();
        LogUtil.debug("PARAMETER====>>>>>" + param);
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.INSERT_PHONE, ResponseData.class, param, new Response.Listener<ResponseData>() {
            @Override
            public void onResponse(ResponseData response) {
                dismissProgressDialog();
                if (response.getResult()) {
                    showMessage(response.getMessage());
                    Intent intent = new Intent();
                    setResult(1, intent);
                    finish();

                } else {
                    showMessage(response.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                dismissProgressDialog();
                showErrorMessage(volleyError);
            }
        }, new BaseDeserializer<>(ResponseData.class));
        baseHttpRequest.setToken(prefs.getAccessTocken());
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

    private void processToUpdatePhoneNumber() {

        if (!validation()) {
            return;
        }
        Map<String, String> param = getParam();
        param.put("user_id", prefs.getUserId());
        param.put("phone_id", phoneDetails.id);
        param.put("place_type", editTextPlaceType.getText().toString());
        param.put("phone", editTextPhoneNumber.getText().toString());

        showProgressDialog();
        LogUtil.debug("PARAMETER====>>>>>" + param);
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.EDIT_PHONE, ResponseData.class, param, new Response.Listener<ResponseData>() {
            @Override
            public void onResponse(ResponseData response) {
                dismissProgressDialog();
                if (response.getResult()) {
                    showMessage(response.getMessage());
                    Intent intent = new Intent();
                    setResult(1, intent);
                    finish();

                } else {
                    showMessage(response.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                dismissProgressDialog();
                showErrorMessage(volleyError);
            }
        }, new BaseDeserializer<>(ResponseData.class));
        baseHttpRequest.setToken(prefs.getAccessTocken());
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

    private boolean validation() {
        boolean check = true;
        if (!Validation.hasText(editTextPlaceType)) check = false;
        if (!Validation.isPhoneNumber(editTextPhoneNumber, true)) check = false;
        return check;
    }
}
