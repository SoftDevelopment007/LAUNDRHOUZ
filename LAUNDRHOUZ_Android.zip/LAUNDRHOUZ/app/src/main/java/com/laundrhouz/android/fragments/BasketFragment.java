package com.laundrhouz.android.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.laundrhouz.android.R;
import com.laundrhouz.android.activities.DeliveryMethodActivity;
import com.laundrhouz.android.activities.HomeActivity;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import modules.adapter.BasketItemAdapter;
import modules.base.FragmentBase;
import modules.bean.InsertOrderDetails;
import modules.room_db.dao.CartDetails;


public class BasketFragment extends FragmentBase implements View.OnClickListener {

    private Button buttonAddCloths;
    private RecyclerView recyclerViewItems;
    private BasketItemAdapter basketItemAdapter;
    private List<CartDetails> cartDetailsList;
    private TextView textViewTotalItems, textViewTotalPrice;
    private CardView cardViewTotal;
    private InsertOrderDetails insertOrderDetails;
    private LinearLayout linearLayoutEmpty;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_basket, container, false);

        initComponent(view);
        itemClickListner();
        return view;
    }

    private void initComponent(View view) {
        buttonAddCloths = view.findViewById(R.id.buttonAddCloths);
        recyclerViewItems = view.findViewById(R.id.recyclerViewItems);
        textViewTotalItems = view.findViewById(R.id.textViewTotalItems);
        textViewTotalPrice = view.findViewById(R.id.textViewTotalPrice);
        cardViewTotal = view.findViewById(R.id.cardViewTotal);
        linearLayoutEmpty = view.findViewById(R.id.linearLayoutEmpty);

        insertOrderDetails = new InsertOrderDetails();
        cartDetailsList = new ArrayList<>();
        setData();
    }

    private void itemClickListner() {
        buttonAddCloths.setOnClickListener(this);
        cardViewTotal.setOnClickListener(this);
    }

    private void setData() {
        cartDetailsList.addAll(appDatabase.cartDetailsDao().getAll());

        basketItemAdapter = new BasketItemAdapter(getActivity(), cartDetailsList);
        recyclerViewItems.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerViewItems.setAdapter(basketItemAdapter);

        setTotalItemAndAmount();

        setLayoutData();

    }

    private void setLayoutData() {
        if (cartDetailsList.isEmpty()) {
            linearLayoutEmpty.setVisibility(View.VISIBLE);
            recyclerViewItems.setVisibility(View.GONE);
            cardViewTotal.setVisibility(View.GONE);
        } else {
            linearLayoutEmpty.setVisibility(View.GONE);
            recyclerViewItems.setVisibility(View.VISIBLE);
            cardViewTotal.setVisibility(View.VISIBLE);

        }
    }

    private void setTotalItemAndAmount() {

        if (prefs.isPromocodeApplied() && prefs.isPromocodeAmountApplied()) {

            double total_promo_amount = (basketItemAdapter.getTotalAmount() * (Integer.parseInt(prefs.getPromoCodeAmount()))) / 100;
            double totalAmount = basketItemAdapter.getTotalAmount() - total_promo_amount;
            textViewTotalPrice.setText("$" + new DecimalFormat("#.##").format(totalAmount));

        } else {
            textViewTotalPrice.setText("$" + basketItemAdapter.getTotalAmount());
        }


        textViewTotalItems.setText(String.valueOf(basketItemAdapter.getTotalItem()));
//        textViewTotalPrice.setText("$" + basketItemAdapter.getTotalAmount());
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.buttonAddCloths:
//                loadFragment(new HomeFragment());
                ((HomeActivity) this.getActivity()).bottomNavigationViewHome.setSelectedItemId(R.id.nav_home);
                break;
            case R.id.cardViewTotal:
                insertOrderDetails = ((HomeActivity) this.getActivity()).mainInsertOrderDetails;
                Intent intent = new Intent(getContext(), DeliveryMethodActivity.class);
                intent.putExtra("orederDetails", insertOrderDetails);
                startActivity(intent);
                break;
        }
    }
}
