package com.laundrhouz.android.activities;

import android.content.Intent;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.laundrhouz.android.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import modules.adapter.OrderItemsAdapter;
import modules.app.AppController;
import modules.base.ActivityBase;
import modules.base.LogUtil;
import modules.bean.InsertOrderDetails;
import modules.bean.PaymentMethodDetails;
import modules.bean.PickupDetails;
import modules.blu.ServerHelper;
import modules.deserializer.BaseDeserializer;
import modules.http.BaseHttpRequest;
import modules.room_db.dao.CartDetails;

public class OrderConfirmationActivity extends ActivityBase implements View.OnClickListener {

    RecyclerView recyclerViewItems;
    OrderItemsAdapter orderItemsAdapter;
    Button buttonConfirmOrder;
    private List<CartDetails> cartDetailsList;
    TextView textViewSubTotal, textViewCouponTotal, textViewSubTotalCoupon, textViewPickupCharge, textViewTotalAmount;
    TextView textViewOrderAddress, textViewInformation;
    InsertOrderDetails insertOrderDetails;
    PaymentMethodDetails paymentMethodDetails;
    int pickUpCharge = 0, pickupLimit = 0;
    double total_Amount, promoCode_amount, sub_total_amount;
    int totalPickupCharge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_confirmation);
        if (getIntent().hasExtra("orderDetails")) {
            insertOrderDetails = (InsertOrderDetails) getIntent().getSerializableExtra("orderDetails");
            paymentMethodDetails = (PaymentMethodDetails) getIntent().getSerializableExtra("paymentDetails");
        }
        setToolbar();
        initComponent();
    }

    private void initComponent() {
        recyclerViewItems = findViewById(R.id.recyclerViewItems);
        buttonConfirmOrder = findViewById(R.id.buttonConfirmOrder);
        textViewSubTotal = findViewById(R.id.textViewSubTotal);
        textViewCouponTotal = findViewById(R.id.textViewCouponTotal);
        textViewSubTotalCoupon = findViewById(R.id.textViewSubTotalCoupon);
        textViewPickupCharge = findViewById(R.id.textViewPickupCharge);
        textViewTotalAmount = findViewById(R.id.textViewTotalAmount);
        textViewOrderAddress = findViewById(R.id.textViewOrderAddress);
        textViewInformation = findViewById(R.id.textViewInformation);

        buttonConfirmOrder.setOnClickListener(this);
        cartDetailsList = new ArrayList<>();

        setData();
    }

    private void setData() {

        cartDetailsList.addAll(appDatabase.cartDetailsDao().getAll());


        orderItemsAdapter = new OrderItemsAdapter(OrderConfirmationActivity.this, cartDetailsList);
        recyclerViewItems.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerViewItems.setAdapter(orderItemsAdapter);

        textViewSubTotal.setText("$" + orderItemsAdapter.getTotalAmount());
        if (getIntent().hasExtra("orderDetails")) {

            textViewOrderAddress.setText(insertOrderDetails.address);
        }

        if (prefs.isPromocodeApplied() && prefs.isPromocodeAmountApplied()) {
            double total_promo_amount = (orderItemsAdapter.getTotalAmount() * (Integer.parseInt(prefs.getPromoCodeAmount()))) / 100;
            double totalAmount = orderItemsAdapter.getTotalAmount() - total_promo_amount;
            textViewSubTotalCoupon.setText("$" + totalAmount);
            textViewCouponTotal.setText("$" + total_promo_amount);
            sub_total_amount = totalAmount;
            total_Amount = totalAmount;
            promoCode_amount = total_promo_amount;
        } else {
            textViewSubTotalCoupon.setText("$" + orderItemsAdapter.getTotalAmount());
            textViewCouponTotal.setText("$" + 0);
            promoCode_amount = 0;
            sub_total_amount = orderItemsAdapter.getTotalAmount();
            total_Amount = orderItemsAdapter.getTotalAmount();
        }


        if (isOnline())
            processToCheckPickupDetails();
    }

    private void setToolbar() {
        TextView textViewToolbarTitle = findViewById(R.id.textViewToolbarTitle);
        textViewToolbarTitle.setText(getResources().getString(R.string.order_confirmation));
        TextView textViewStart = findViewById(R.id.textViewStart);
        textViewStart.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.textViewStart:
                onBackPressed();
                break;
            case R.id.buttonConfirmOrder:

                if (isOnline())
                    processToInsertOrder();
        }
    }

    private void processToCheckPickupDetails() {

        Map<String, String> param = getParam();
        param.put("user_id", prefs.getUserId());

        showProgressDialog();
        LogUtil.debug("PARAMETER====>>>>>" + param);
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.FETCH_PICKUP_DATA, PickupDetails.class, param, new Response.Listener<PickupDetails>() {
            @Override
            public void onResponse(PickupDetails pickupDetails) {
                dismissProgressDialog();
                if (pickupDetails.getResult()) {
                    pickUpCharge = Integer.parseInt(pickupDetails.pickup_charge);
                    pickupLimit = Integer.parseInt(pickupDetails.pickup_limit);

                    if (total_Amount < pickupLimit) {
                        total_Amount = total_Amount + pickUpCharge;
                        textViewPickupCharge.setText("$" + pickUpCharge);
                        textViewTotalAmount.setText("$" + total_Amount);
                        totalPickupCharge = pickUpCharge;
                    } else {
                        textViewPickupCharge.setText("$" + 0);
                        textViewTotalAmount.setText("$" + total_Amount);
                        totalPickupCharge = 0;
                    }

                    textViewInformation.setText("Any order less then $" + pickupLimit + " has a pickup charge for $" + pickUpCharge);
                } else {
                    pickUpCharge = 0;
                    pickupLimit = 0;
                    totalPickupCharge = 0;
                    textViewPickupCharge.setText("$" + 0);
                    textViewTotalAmount.setText("$" + total_Amount);
                    textViewInformation.setText("Any order less then $" + pickupLimit + " has a pickup charge for $" + pickUpCharge);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                dismissProgressDialog();
                showErrorMessage(volleyError);
            }
        }, new BaseDeserializer<>(PickupDetails.class));
        baseHttpRequest.setToken(prefs.getAccessTocken());
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

    private void processToInsertOrder() {

        cartDetailsList = appDatabase.cartDetailsDao().getAll();

        if (cartDetailsList.isEmpty()) {
            showMessage("Please Selct Some Services First");
            return;
        }

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JSONObject jsonParams = getServiceParam();
        final String requestBody = jsonParams.toString();
        LogUtil.debug("JSONObject requestBody====>>>>" + requestBody);
        showProgressDialog();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, ServerHelper.ORDER_INSERT, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i("VOLLEY", response);
                try {
                    LogUtil.debug("JSONObject response====>>>>" + response);
                    JSONObject obj = new JSONObject(response);
                    if (obj.getString("status").equalsIgnoreCase("true")) {
                        LogUtil.debug("JSONObject====>>>>" + obj);
                        showMessage(obj.getString("message"));
                        JSONObject data = obj.getJSONObject("data");
                        appDatabase.cartDetailsDao().deleteAll();
                        Intent intent = new Intent(getApplicationContext(), ThankYouActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);

                    } else if (obj.getString("status").equalsIgnoreCase("false")) {
                        showMessage(obj.getString("message"));
                    }
                    dismissProgressDialog();
                } catch (JSONException e) {
                    e.printStackTrace();
                    dismissProgressDialog();
                }
                dismissProgressDialog();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("VOLLEY", error.toString());
                showErrorMessage(error);
                dismissProgressDialog();
            }
        }) {
            @Override
            public String getBodyContentType() {
                return "application/json; charset=utf-8";
            }

            @Override
            public byte[] getBody() {
                return requestBody.getBytes(StandardCharsets.UTF_8);
            }

            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();

                if (hashData(prefs.getAccessTocken()))
                    headers.put("Authorization", prefs.getAccessTocken());

                LogUtil.debug("Authorization_TOCKEN====>>>>" + headers);
                return headers;
            }
        };
        int socketTimeout = 30000; // 30 seconds. You can change it
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(policy);
        requestQueue.add(stringRequest);
    }

    private JSONObject getServiceParam() {

        cartDetailsList = appDatabase.cartDetailsDao().getAll();
        JSONArray selectedServices = new JSONArray();
        for (CartDetails cart : cartDetailsList) {
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("item_id", cart.product_id);
                jsonObject.put("item_name", cart.product_name);
                jsonObject.put("item_qty", cart.quantity);
                jsonObject.put("item_unitprice", cart.discount_price);
                double totalPrice = cart.quantity * cart.discount_price;
                jsonObject.put("item_totalprice", totalPrice);

                selectedServices.put(jsonObject);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        JSONObject jsonParams = new JSONObject();
        try {
            jsonParams.put("cust_id", prefs.getUserId());
            jsonParams.put("address_id", insertOrderDetails.address_id);
            jsonParams.put("promocode_amount", promoCode_amount);
            jsonParams.put("subtotal_amount", orderItemsAdapter.getTotalAmount());
            jsonParams.put("final_subtotal", sub_total_amount);
            jsonParams.put("payment_status", "Complete");
            jsonParams.put("payment_id", paymentMethodDetails.id);

            jsonParams.put("pickup_charge", totalPickupCharge);
            jsonParams.put("pickup_time", insertOrderDetails.pickup_time);
            jsonParams.put("pickup_date", insertOrderDetails.pickup_date);
            jsonParams.put("item_qty", orderItemsAdapter.getTotalItem());
            jsonParams.put("total_amount", total_Amount);
            if (insertOrderDetails.instruction != null) {
                jsonParams.put("instruction", insertOrderDetails.instruction);
            } else {
                jsonParams.put("instruction", "");
            }
            jsonParams.put("deliver_date", insertOrderDetails.deliver_date);

            jsonParams.put("OrderDetails", selectedServices);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonParams;
    }
}
