package com.laundrhouz.android.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.laundrhouz.android.R;
import com.laundrhouz.android.activities.AddItemActivity;
import com.laundrhouz.android.activities.EnterPromoCodeActivity;
import com.laundrhouz.android.activities.HomeActivity;
import com.laundrhouz.android.activities.LoginActivity;
import com.laundrhouz.android.activities.OTPVerifyActivity;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import modules.adapter.CartItemsAdapter;
import modules.base.FragmentBase;
import modules.base.LogUtil;
import modules.bean.InsertOrderDetails;
import modules.room_db.dao.CartDetails;

public class CartFragment extends FragmentBase implements View.OnClickListener, BottomNavigationView.OnNavigationItemSelectedListener {

    private RecyclerView recyclerViewItems;
    private CartItemsAdapter cartItemsAdapter;
    private TextView textViewProceed;
    private RelativeLayout relativeLayoutApplyCoupon, relativeLayoutTotal;
    private List<CartDetails> cartDetailsList;
    private TextView textViewTotalItems, textViewTotalPrice;
    private RelativeLayout relativeLayoutAddItem, relativeLayoutCleaningInstruction;
    private EditText editTextCleaningInstruction;
    private TextView textViewAppliedCouponCode;
    private int For_Search = 2;
    private String promocode, offer_per;
    private InsertOrderDetails insertOrderDetails;

    private double promocode_amount = 0, subtotal_amount, final_subtotal;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_cart, container, false);
        initComponent(view);
        itemClickListner();
        return view;
    }

    private void initComponent(View view) {
        recyclerViewItems = view.findViewById(R.id.recyclerViewItems);
        textViewProceed = view.findViewById(R.id.textViewProceed);
        relativeLayoutApplyCoupon = view.findViewById(R.id.relativeLayoutApplyCoupon);
        relativeLayoutTotal = view.findViewById(R.id.relativeLayoutTotal);
        textViewTotalItems = view.findViewById(R.id.textViewTotalItems);
        textViewTotalPrice = view.findViewById(R.id.textViewTotalPrice);
        relativeLayoutAddItem = view.findViewById(R.id.relativeLayoutAddItem);
        relativeLayoutCleaningInstruction = view.findViewById(R.id.relativeLayoutCleaningInstruction);
        editTextCleaningInstruction = view.findViewById(R.id.editTextCleaningInstruction);
        textViewAppliedCouponCode = view.findViewById(R.id.textViewAppliedCouponCode);

        cartDetailsList = new ArrayList<>();
        insertOrderDetails = new InsertOrderDetails();


        setData();
    }

    private void setPromocodeLayoutData() {

        if (prefs.isPromocodeApplied() && prefs.isPromocodeAmountApplied()) {
            textViewAppliedCouponCode.setVisibility(View.VISIBLE);
        } else {
            textViewAppliedCouponCode.setVisibility(View.GONE);
        }
        setTotalItemAndAmount(null);
    }

    private void setData() {

        cartDetailsList.clear();
        cartDetailsList.addAll(appDatabase.cartDetailsDao().getAll());

        cartItemsAdapter = new CartItemsAdapter(getActivity(), cartDetailsList);
        cartItemsAdapter.setItemRemoveFromCart(new CartItemsAdapter.ItemRemoveFromCart() {
            @Override
            public void itemRemove(int position, String id) {
                int qty = appDatabase.cartDetailsDao().getQuantity(id);
                if (qty > 1) {
                    qty--;
                    appDatabase.cartDetailsDao().update(qty, id);
                    cartDetailsList.get(position).quantity = qty;
                } else {
                    appDatabase.cartDetailsDao().delete(id);
                    cartDetailsList.remove(position);
                }

                cartItemsAdapter.notifyDataSetChanged();
                setTotalItemAndAmount(null);
            }

            @Override
            public void itemAdd(int position, String id) {
                int qty = appDatabase.cartDetailsDao().getQuantity(id);
                qty++;
                appDatabase.cartDetailsDao().update(qty, id);
                cartDetailsList.get(position).quantity = qty;
                cartItemsAdapter.notifyDataSetChanged();
                setTotalItemAndAmount(null);
            }
        });
        recyclerViewItems.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerViewItems.setAdapter(cartItemsAdapter);


        setPromocodeLayoutData();
//        setTotalItemAndAmount(null);

    }

    private void setTotalItemAndAmount(String offer_per) {
        if (prefs.isPromocodeApplied() && prefs.isPromocodeAmountApplied()) {

            double total_promo_amount = (cartItemsAdapter.getTotalAmount() * (Integer.parseInt(prefs.getPromoCodeAmount()))) / 100;
            double totalAmount = cartItemsAdapter.getTotalAmount() - total_promo_amount;
            textViewTotalPrice.setText("$" + new DecimalFormat("#.##").format(totalAmount));
            promocode_amount = total_promo_amount;
            subtotal_amount = cartItemsAdapter.getTotalAmount();
            final_subtotal = totalAmount;

        } else {
            promocode_amount = 0;
            textViewTotalPrice.setText("$" + new DecimalFormat("#.##").format(cartItemsAdapter.getTotalAmount()));
            subtotal_amount = cartItemsAdapter.getTotalAmount();
            final_subtotal = cartItemsAdapter.getTotalAmount();
        }

        textViewTotalItems.setText(String.valueOf(cartItemsAdapter.getTotalItem()));
    }

    private void itemClickListner() {
        Objects.requireNonNull(getActivity()).findViewById(R.id.textViewEnd).setOnClickListener(this);
        Objects.requireNonNull(getActivity()).findViewById(R.id.textViewStart).setOnClickListener(this);

        relativeLayoutTotal.setOnClickListener(this);
        relativeLayoutApplyCoupon.setOnClickListener(this);
        relativeLayoutAddItem.setOnClickListener(this);
        relativeLayoutCleaningInstruction.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent intent;
        switch (view.getId()) {
            case R.id.textViewEnd:

                for (int i = 0; i < cartDetailsList.size(); i++) {
                    cartDetailsList.get(i).isEdit = true;
                }

                Objects.requireNonNull(getActivity()).findViewById(R.id.textViewEnd).setVisibility(View.GONE);
                TextView textViewStart = getActivity().findViewById(R.id.textViewStart);
                textViewStart.setVisibility(View.VISIBLE);
                textViewStart.setBackground(null);
                textViewStart.setText(getResources().getString(R.string.cancel));
                textViewProceed.setText(getResources().getString(R.string.place_order));
                cartItemsAdapter.notifyDataSetChanged();
                relativeLayoutApplyCoupon.setVisibility(View.VISIBLE);
                break;
            case R.id.textViewStart:

                for (int i = 0; i < cartDetailsList.size(); i++) {
                    cartDetailsList.get(i).isEdit = false;
                }
                Objects.requireNonNull(getActivity()).findViewById(R.id.textViewEnd).setVisibility(View.VISIBLE);
                getActivity().findViewById(R.id.textViewStart).setVisibility(View.GONE);
                textViewProceed.setText(getResources().getString(R.string.proceed));
                cartItemsAdapter.notifyDataSetChanged();
                relativeLayoutApplyCoupon.setVisibility(View.GONE);
                break;

            case R.id.relativeLayoutTotal:
                if (prefs.isLogin()) {
                    if (prefs.getIsVerify().equalsIgnoreCase("1")) {
                        if (!cartDetailsList.isEmpty()) {
                            if (promocode_amount > 0) {
                                insertOrderDetails.promocode_amount = promocode_amount;
                                insertOrderDetails.subtotal_amount = subtotal_amount;
                                insertOrderDetails.final_subtotal = final_subtotal;
                            } else {
                                insertOrderDetails.subtotal_amount = subtotal_amount;
                                insertOrderDetails.final_subtotal = final_subtotal;
                            }

                            if (!editTextCleaningInstruction.getText().toString().equalsIgnoreCase("")) {
                                insertOrderDetails.instruction = editTextCleaningInstruction.getText().toString();
                            }

                            ((HomeActivity) this.getActivity()).mainInsertOrderDetails = insertOrderDetails;
                            ((HomeActivity) this.getActivity()).bottomNavigationViewHome.setSelectedItemId(R.id.nav_basket);

                        } else {
                            showMessage("Cart is Empty. Please Select Any one Product For Service.");
                        }
                    } else {
                        intent = new Intent(getContext(), OTPVerifyActivity.class);
                        intent.putExtra("fromCart", "fromCart");
                        startActivity(intent);
                    }
                } else {
                    intent = new Intent(getContext(), LoginActivity.class);
                    intent.putExtra("fromCart", "fromCart");
                    startActivity(intent);
                }
                break;

            case R.id.relativeLayoutApplyCoupon:
                intent = new Intent(getContext(), EnterPromoCodeActivity.class);
                if (promocode != null) {
                    intent.putExtra("promocode", promocode);
                }
                startActivityForResult(intent, 1);
                break;

            case R.id.relativeLayoutCleaningInstruction:
                if (editTextCleaningInstruction.isShown()) {
                    editTextCleaningInstruction.setVisibility(View.GONE);
                } else {
                    editTextCleaningInstruction.setVisibility(View.VISIBLE);
                }
                break;

            case R.id.relativeLayoutAddItem:
                if (prefs.isLogin()) {
                    intent = new Intent(getActivity(), AddItemActivity.class);
                    startActivityForResult(intent, For_Search);
                } else {
                    intent = new Intent(getContext(), LoginActivity.class);
                    intent.putExtra("fromCart", "fromCart");
                    startActivity(intent);
                }
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // check if the request code is same as what is passed  here it is 2
        if (requestCode == 1) {
            if (data != null) {
                promocode = data.getStringExtra("promoCode");
                offer_per = data.getStringExtra("offer_per");

                prefs.setPromoCode(promocode);
                prefs.setPromoCodeAmount(offer_per);
                textViewAppliedCouponCode.setVisibility(View.VISIBLE);

            } else {
                promocode = null;
                offer_per = null;

                prefs.setPromoCode(promocode);
                prefs.setPromoCodeAmount(offer_per);
                textViewAppliedCouponCode.setVisibility(View.GONE);
            }
            LogUtil.debug("PROMOCODE====>>>>" + promocode);
            LogUtil.debug("PROMOCODE_OFFER====>>>>" + offer_per);


            setPromocodeLayoutData();
        } else if (requestCode == For_Search) {
            cartDetailsList.clear();
            cartDetailsList.addAll(appDatabase.cartDetailsDao().getAll());
            cartItemsAdapter.notifyDataSetChanged();
            setTotalItemAndAmount(null);
        }

    }

    public void loadFragment(Fragment fragment) {
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.slide_in_left, R.anim.slide_out_right, R.anim.slide_in_right, R.anim.slide_out_left);
        transaction.replace(R.id.frame_container, fragment);
        transaction.commit();
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {


        }
        return false;
    }
}
