package com.laundrhouz.android.activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.laundrhouz.android.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import modules.adapter.AddressAdapter;
import modules.customeviews.RecyclerItemTouchHelper;
import modules.app.AppController;
import modules.base.ActivityBase;
import modules.base.LogUtil;
import modules.bean.AddressDetails;
import modules.blu.ServerHelper;
import modules.deserializer.BaseDeserializer;
import modules.deserializer.BaseDeserializerList;
import modules.http.BaseHttpRequest;
import modules.http.ResponseData;
import modules.utils.AppConstants;

public class ChooseDefaultAddressActivity extends ActivityBase implements View.OnClickListener {

    RecyclerView recyclerViewAddress;
    AddressAdapter addressAdapter;
    List<AddressDetails> addressDetailsList;
    RelativeLayout relativeLayoutAddNewAddress;
    int height;
    boolean isLoaded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_default_address);
        setToolbar();
        initComponent();
    }

    private void initComponent() {
        addressDetailsList = new ArrayList<>();

        relativeLayoutAddNewAddress = findViewById(R.id.relativeLayoutAddNewAddress);
        relativeLayoutAddNewAddress.setOnClickListener(this);
        recyclerViewAddress = findViewById(R.id.recyclerViewAddress);
        RecyclerView.LayoutManager recyclerViewAddressLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerViewAddress.setLayoutManager(recyclerViewAddressLayoutManager);
        addressAdapter = new AddressAdapter(ChooseDefaultAddressActivity.this, addressDetailsList);
        recyclerViewAddress.setAdapter(addressAdapter);

        addressAdapter.setOnClick(new AddressAdapter.onClick() {
            @Override
            public void sendHeight(int h) {
                height = h;
            }
        });
        final Bitmap delete = BitmapFactory.decodeResource(getResources(), R.drawable.basket);
        final Bitmap edit = BitmapFactory.decodeResource(getResources(), R.drawable.edit2);
        new RecyclerItemTouchHelper(this, this, recyclerViewAddress, height) {
            @Override
            public void instantiateUnderlayButton(RecyclerView.ViewHolder viewHolder, List<UnderlayButton> underlayButtons) {
                underlayButtons.add(new RecyclerItemTouchHelper.UnderlayButton(Color.parseColor("#FFFFFF"), delete, Color.parseColor("#C82C4D"),
                        new RecyclerItemTouchHelper.UnderlayButtonClickListener() {
                            @Override
                            public void onClick(int pos) {
//                                Toast.makeText(ChooseDefaultAddressActivity.this, "Delete" + pos, Toast.LENGTH_SHORT).show();
                                processToDeleteAddress(addressDetailsList.get(pos).add_id);
                            }
                        }
                ));
                underlayButtons.add(new RecyclerItemTouchHelper.UnderlayButton(Color.parseColor("#000000"), edit, Color.parseColor("#D1D8E4"),
                        new RecyclerItemTouchHelper.UnderlayButtonClickListener() {
                            @Override
                            public void onClick(int pos) {
                                Intent intent = new Intent(ChooseDefaultAddressActivity.this, EditAddressActivity.class);
                                intent.putExtra("addressDetails", addressDetailsList.get(pos));
                                startActivityForResult(intent, 1);
                            }
                        }
                ));
            }
        };

        if (isOnline())
            processToLoadAddress();
    }

    private void setToolbar() {
        TextView textViewToolbarTitle = findViewById(R.id.textViewToolbarTitle);
        textViewToolbarTitle.setText(getResources().getString(R.string.pick_up_address));
        TextView textViewStart = findViewById(R.id.textViewStart);
        textViewStart.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.textViewStart:
                onBackPressed();
                break;

            case R.id.relativeLayoutAddNewAddress:
                Intent intent = new Intent(ChooseDefaultAddressActivity.this, AddAnotherAddressActivity.class);
                startActivityForResult(intent, AppConstants.ACTIVITY_FOR_RESULT_ADDRESS_DATA);
                break;
        }
    }

    private void processToLoadAddress() {
        Map<String, String> param = new HashMap<>();
        param.put("user_id", prefs.getUserId());
        showProgressDialog();
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.FETCH_ADDRESS, ResponseData.class, param, new Response.Listener<ResponseData>() {
            @Override
            public void onResponse(ResponseData response) {
                dismissProgressDialog();
                addressDetailsList.clear();
                if (response.getResult()) {
                    List<AddressDetails> tempList = (List<AddressDetails>) response.getData();
                    addressDetailsList.addAll(tempList);
                    LogUtil.debug("LIST=====>>>>>" + addressDetailsList.size());
                } else {
                    showMessage(response.getMessage());
                }
                addressAdapter.notifyDataSetChanged();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dismissProgressDialog();
                showErrorMessage(error);
            }
        }, new BaseDeserializerList<>(ResponseData.class, AddressDetails.class));
        baseHttpRequest.setToken(prefs.getAccessTocken());
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

   /* @Override
    protected void onResume() {
        super.onResume();
        if (isLoaded) {
            if (isOnline())
                processToLoadAddress();
        }
    }


    @Override
    protected void onPause() {
        super.onPause();
        isLoaded = true;
    }*/

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data != null && resultCode == RESULT_OK) {
            if (isOnline())
                processToLoadAddress();
        }
    }

    private void processToDeleteAddress(String add_id) {


        Map<String, String> param = getParam();
        param.put("user_id", prefs.getUserId());
        param.put("add_id", add_id);


        showProgressDialog();
        LogUtil.debug("PARAMETER====>>>>>" + param);
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.DELETE_ADDRESS, AddressDetails.class, param, new Response.Listener<AddressDetails>() {
            @Override
            public void onResponse(AddressDetails addressDetails) {
                dismissProgressDialog();
                if (addressDetails.getResult()) {
                    LogUtil.debug("SUCCESSSS=====>>>" + addressDetails.getMessage());
                    showMessage(addressDetails.getMessage());
                    processToLoadAddress();

                } else {
                    showMessage(addressDetails.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                dismissProgressDialog();
                showErrorMessage(volleyError);
            }
        }, new BaseDeserializer<>(AddressDetails.class));
        baseHttpRequest.setToken(prefs.getAccessTocken());
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }
}
