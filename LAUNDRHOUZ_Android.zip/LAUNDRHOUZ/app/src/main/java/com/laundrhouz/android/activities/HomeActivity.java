package com.laundrhouz.android.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.laundrhouz.android.R;
import com.laundrhouz.android.fragments.BasketFragment;
import com.laundrhouz.android.fragments.CartFragment;
import com.laundrhouz.android.fragments.HomeFragment;
import com.laundrhouz.android.fragments.ProfileFragment;

import modules.base.ActivityBase;
import modules.bean.InsertOrderDetails;

public class HomeActivity extends ActivityBase implements BottomNavigationView.OnNavigationItemSelectedListener {

    public BottomNavigationView bottomNavigationViewHome;
    public InsertOrderDetails mainInsertOrderDetails;
    boolean forCart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        setToolbar("Home", true, false);
        findViewById(R.id.textViewEnd).setScaleX(Float.parseFloat("0.5"));
        findViewById(R.id.textViewEnd).setScaleY(Float.parseFloat("0.5"));

        initComponent();

    }

    private void initComponent() {
        bottomNavigationViewHome = findViewById(R.id.bottomNavigationViewHome);
        bottomNavigationViewHome.setOnNavigationItemSelectedListener(this);

        mainInsertOrderDetails = new InsertOrderDetails();

        if (getIntent().hasExtra("forCart")) {
            forCart = getIntent().getBooleanExtra("forCart", false);
            if (forCart) {
                bottomNavigationViewHome.setSelectedItemId(R.id.nav_cart);
            }
        } else if (getIntent().hasExtra("fromNotification")) {
            bottomNavigationViewHome.setSelectedItemId(R.id.nav_profile);
        } else {
            loadFragment(new HomeFragment());
        }
    }

    private void setToolbar(String title, boolean textViewEnd, boolean textViewStart) {
        TextView textViewToolbarTitle = findViewById(R.id.textViewToolbarTitle);
        textViewToolbarTitle.setText(title);
        if (textViewStart)
            findViewById(R.id.textViewStart).setVisibility(View.VISIBLE);
        else
            findViewById(R.id.textViewStart).setVisibility(View.GONE);
        if (textViewEnd)
            findViewById(R.id.textViewEnd).setVisibility(View.VISIBLE);
        else
            findViewById(R.id.textViewEnd).setVisibility(View.GONE);
    }

    private void loadFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.slide_in_left, R.anim.slide_out_right, R.anim.slide_in_right, R.anim.slide_out_left);
        transaction.replace(R.id.frame_container, fragment);
        transaction.commit();
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Fragment fragment;
        switch (item.getItemId()) {
            case R.id.nav_home:
                if (getSelectedItem(bottomNavigationViewHome) != R.id.nav_home) {
                    setToolbar("Home", true, false);
                    findViewById(R.id.textViewEnd).setBackgroundResource(R.drawable.notification);
                    findViewById(R.id.textViewEnd).setScaleX(Float.parseFloat("0.5"));
                    findViewById(R.id.textViewEnd).setScaleY(Float.parseFloat("0.5"));
                    fragment = new HomeFragment();
                    loadFragment(fragment);
                }

                return true;
            case R.id.nav_cart:
                if (getSelectedItem(bottomNavigationViewHome) != R.id.nav_cart) {
                    setToolbar("Cart", true, false);
                    findViewById(R.id.textViewEnd).setBackgroundResource(R.drawable.edit2);
                    findViewById(R.id.textViewEnd).setScaleX(Float.parseFloat("1.0"));
                    findViewById(R.id.textViewEnd).setScaleY(Float.parseFloat("1.0"));
                    fragment = new CartFragment();
                    loadFragment(fragment);
                }
                return true;
            case R.id.nav_basket:
                if (getSelectedItem(bottomNavigationViewHome) != R.id.nav_basket) {
                    setToolbar("Basket", false, false);
                    fragment = new BasketFragment();
                    loadFragment(fragment);
                }
                return true;
            case R.id.nav_profile:
                if (getSelectedItem(bottomNavigationViewHome) != R.id.nav_profile) {
                    if (prefs.isLogin()) {
                        if (prefs.getIsVerify().equalsIgnoreCase("1")) {
                            setToolbar("Profile", false, true);
                            findViewById(R.id.textViewStart).setBackground(null);
                            TextView textViewStart = findViewById(R.id.textViewStart);
                            textViewStart.setText(getResources().getString(R.string.logout));
                            fragment = new ProfileFragment();
                            loadFragment(fragment);
                        } else {
                            Intent i = new Intent(HomeActivity.this, OTPVerifyActivity.class);
                            startActivity(i);
                        }
                    } else {
                        Intent i = new Intent(HomeActivity.this, LoginActivity.class);
                        startActivity(i);
                    }
                }
                return true;
        }
        return false;
    }


    private int getSelectedItem(BottomNavigationView bottomNavigationView) {
        Menu menu = bottomNavigationView.getMenu();
        for (int i = 0; i < bottomNavigationView.getMenu().size(); i++) {
            MenuItem menuItem = menu.getItem(i);
            if (menuItem.isChecked()) {
                return menuItem.getItemId();
            }
        }
        return 0;
    }
}
