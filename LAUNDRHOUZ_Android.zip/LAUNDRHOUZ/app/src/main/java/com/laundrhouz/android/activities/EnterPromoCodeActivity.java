package com.laundrhouz.android.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.laundrhouz.android.R;

import java.util.Map;
import java.util.Objects;

import modules.app.AppController;
import modules.base.ActivityBase;
import modules.base.LogUtil;
import modules.bean.PromocodeDetails;
import modules.blu.ServerHelper;
import modules.deserializer.BaseDeserializer;
import modules.http.BaseHttpRequest;
import modules.validation.Validation;

public class EnterPromoCodeActivity extends ActivityBase implements View.OnClickListener {

    EditText editTextPromoCode;
    ImageView imageViewClose;
    Button buttonOk;
    TextView textViewInvalidPromoCode;
    String promocode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_promo_code);

        initComponent();
        itemClickListner();
    }

    private void itemClickListner() {

        editTextPromoCode.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    InputMethodManager inputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    inputManager.hideSoftInputFromWindow(Objects.requireNonNull(getCurrentFocus()).getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                    if (isOnline())
                        processToVerifyPromoCode();
                    return true;
                }
                return false;
            }
        });


        imageViewClose.setOnClickListener(this);
        buttonOk.setOnClickListener(this);
    }

    private void initComponent() {
        editTextPromoCode = findViewById(R.id.editTextPromoCode);
        imageViewClose = findViewById(R.id.imageViewClose);
        buttonOk = findViewById(R.id.buttonOk);
        textViewInvalidPromoCode = findViewById(R.id.textViewInvalidPromoCode);

        if (prefs.isPromocodeApplied() && prefs.isPromocodeAmountApplied()) {
            editTextPromoCode.setText(prefs.getPromoCode());
        }

    }


    private void processToVerifyPromoCode() {

        if (!validation()) {
            return;
        }
        Map<String, String> param = getParam();
        param.put("user_id", prefs.getUserId());
        param.put("promocode", editTextPromoCode.getText().toString());

        showProgressDialog();
        LogUtil.debug("PARAMETER====>>>>>" + param);
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.CHECK_PROMOM_CODE, PromocodeDetails.class, param, new Response.Listener<PromocodeDetails>() {
            @Override
            public void onResponse(PromocodeDetails promocodeDetails) {
                dismissProgressDialog();
                if (promocodeDetails.getResult()) {
                    prefs.setPromoCode(editTextPromoCode.getText().toString());
                    prefs.setPromoCodeAmount(promocodeDetails.amount);

                    Intent intent = new Intent();
                    intent.putExtra("promoCode", editTextPromoCode.getText().toString());
                    intent.putExtra("offer_per", promocodeDetails.amount);
                    setResult(1, intent);
                    onBackPressed();
                } else {
                    prefs.setPromoCode(null);
                    prefs.setPromoCodeAmount(null);

                    textViewInvalidPromoCode.setVisibility(View.VISIBLE);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                dismissProgressDialog();
                showErrorMessage(volleyError);
            }
        }, new BaseDeserializer<>(PromocodeDetails.class));
        baseHttpRequest.setToken(prefs.getAccessTocken());
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

    private boolean validation() {
        boolean check = true;
        if (!Validation.hasText(editTextPromoCode)) check = false;
        return check;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.imageViewClose:
                finish();
                break;
            case R.id.buttonOk:
                if (isOnline())
                    processToVerifyPromoCode();
                break;
        }
    }
}
