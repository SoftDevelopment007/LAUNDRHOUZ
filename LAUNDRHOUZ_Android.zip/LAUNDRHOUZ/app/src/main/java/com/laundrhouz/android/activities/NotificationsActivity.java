package com.laundrhouz.android.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.laundrhouz.android.R;

import java.util.ArrayList;
import java.util.List;

import modules.adapter.NotificationsAdapter;
import modules.base.ActivityBase;
import modules.room_db.dao.NotificationDetails;

public class NotificationsActivity extends ActivityBase implements View.OnClickListener {

    RecyclerView recyclerViewNotifications;
    NotificationsAdapter notificationsAdapter;
    List<NotificationDetails> notificationDetailsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);
        setToolbar();
        initComponent();
    }

    private void initComponent() {
        recyclerViewNotifications = findViewById(R.id.recyclerViewNotifications);
        notificationDetailsList = new ArrayList<>();

        notificationDetailsList.addAll(appDatabase.notificationDao().getAll());

        notificationsAdapter = new NotificationsAdapter(NotificationsActivity.this, notificationDetailsList);
        recyclerViewNotifications.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerViewNotifications.setAdapter(notificationsAdapter);
    }

    private void setToolbar() {
        TextView textViewToolbarTitle = findViewById(R.id.textViewToolbarTitle);
        textViewToolbarTitle.setText(getResources().getString(R.string.notifications));
        TextView textViewStart = findViewById(R.id.textViewStart);
        textViewStart.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.textViewStart:
                onBackPressed();
                break;
        }
    }
}
