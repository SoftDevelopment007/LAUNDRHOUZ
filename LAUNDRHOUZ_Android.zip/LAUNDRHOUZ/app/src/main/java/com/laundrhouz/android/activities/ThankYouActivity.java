package com.laundrhouz.android.activities;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.laundrhouz.android.R;

import modules.base.ActivityBase;

public class ThankYouActivity extends ActivityBase implements View.OnClickListener {

    Button buttonConfirmOrder;
    TextView textViewRateUs;
    public static final int OPEN_NEW_ACTIVITY = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thank_you);

        initComponant();
        itemClickListner();
    }

    private void initComponant() {
        buttonConfirmOrder = findViewById(R.id.buttonConfirmOrder);
        textViewRateUs = findViewById(R.id.textViewRateUs);
    }

    private void itemClickListner() {
        buttonConfirmOrder.setOnClickListener(this);
        textViewRateUs.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.buttonConfirmOrder:
                Intent intent = new Intent(ThankYouActivity.this, HomeActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                break;
            case R.id.textViewRateUs:
                Uri uri = Uri.parse("market://details?id=" + context.getPackageName());
                Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_NEW_DOCUMENT | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
                }
                try {
                    startActivityForResult(goToMarket, OPEN_NEW_ACTIVITY);
                } catch (ActivityNotFoundException e) {
                    startActivityForResult(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + context.getPackageName())), OPEN_NEW_ACTIVITY);
                }
                break;
        }
    }
}
