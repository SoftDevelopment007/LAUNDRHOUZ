package com.laundrhouz.android.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.laundrhouz.android.R;

import modules.base.ActivityBase;

public class SignedIn extends ActivityBase {

    TextView tvPhoneNumber;
    Button btnSignOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signed_in);
        findViews();
        setPhoneNumber();
        btnSignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(SignedIn.this, OTPVerifyActivity.class));
                finish();
            }
        });
    }

    private void findViews() {
        tvPhoneNumber = findViewById(R.id.tv_phone_number);
        btnSignOut = findViewById(R.id.btn_sign_out);
    }

    private void setPhoneNumber() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        try {
            if (user.getEmail() != null) {
                tvPhoneNumber.setText(user.getEmail());
            } else {
                tvPhoneNumber.setText(user.getPhoneNumber());
            }
        } catch (Exception e) {
            Toast.makeText(this, "Phone number not found", Toast.LENGTH_SHORT).show();
        }
    }
}
