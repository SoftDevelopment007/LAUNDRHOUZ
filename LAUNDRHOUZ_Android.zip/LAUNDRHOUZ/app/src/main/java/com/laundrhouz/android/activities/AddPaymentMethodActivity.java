package com.laundrhouz.android.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.laundrhouz.android.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Map;

import modules.app.AppController;
import modules.base.ActivityBase;
import modules.base.LogUtil;
import modules.bean.UserDetails;
import modules.blu.ServerHelper;
import modules.deserializer.BaseDeserializer;
import modules.http.BaseHttpRequest;
import modules.validation.Validation;

public class AddPaymentMethodActivity extends ActivityBase implements View.OnClickListener {

    EditText editTextCardHolder, editTextCardNumber, editTextExpiryDate, editTextPostCode;
    Button buttonAddCard;
    RadioGroup radioGroupPaymentMethod;
    RadioButton radioButtonPaymentMethod1, radioButtonPaymentMethod2;
    UserDetails userDetails;
    String password;

    //Make sure for mExpiryDate to be accepting Numbers only
    boolean isSlash = false; //class level initialization

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_payment_method);
        setToolbar();
        initComponent();
        clickListner();

        if (getIntent() != null) {
            if (getIntent().hasExtra("userDetails")) {
                userDetails = (UserDetails) getIntent().getSerializableExtra("userDetails");
                password = getIntent().getStringExtra("password");
            }
        }
    }


    private void initComponent() {
        editTextCardHolder = findViewById(R.id.editTextCardHolder);
        editTextCardHolder.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        editTextCardNumber = findViewById(R.id.editTextCardNumber);
        editTextCardNumber.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        editTextExpiryDate = findViewById(R.id.editTextExpiryDate);
        editTextExpiryDate.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        editTextPostCode = findViewById(R.id.editTextPostCode);
        editTextPostCode.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        buttonAddCard = findViewById(R.id.buttonAddCard);
        buttonAddCard.setOnClickListener(this);

        radioGroupPaymentMethod = findViewById(R.id.radioGroupPaymentMethod);
        radioButtonPaymentMethod1 = findViewById(R.id.radioButtonPaymentMethod1);
        radioButtonPaymentMethod2 = findViewById(R.id.radioButtonPaymentMethod2);

    }

    private void setToolbar() {
        TextView textViewToolbarTitle = findViewById(R.id.textViewToolbarTitle);
        textViewToolbarTitle.setText(getResources().getString(R.string.add_payment_method));
        TextView textViewStart = findViewById(R.id.textViewStart);
        textViewStart.setOnClickListener(this);
    }

    private void clickListner() {
        radioGroupPaymentMethod.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                hideKeyBoard();
                editTextCardNumber.setError(null);
                editTextCardHolder.setError(null);
                editTextExpiryDate.setError(null);
                editTextPostCode.setError(null);

                editTextCardNumber.clearFocus();
                editTextCardHolder.clearFocus();
                editTextExpiryDate.clearFocus();
                editTextPostCode.clearFocus();

                editTextCardNumber.setText("");
                editTextCardHolder.setText("");
                editTextExpiryDate.setText("");
                editTextPostCode.setText("");


                if (i == R.id.radioButtonPaymentMethod1) {

                    editTextCardNumber.setInputType(InputType.TYPE_CLASS_TEXT);


                    editTextCardHolder.setVisibility(View.GONE);
                    editTextExpiryDate.setVisibility(View.GONE);
                    editTextPostCode.setVisibility(View.GONE);

                    editTextCardNumber.setHint("Paypal Uniq Id");
                    buttonAddCard.setText("Add Paypal");
                } else if (i == R.id.radioButtonPaymentMethod2) {

                    editTextCardNumber.setInputType(InputType.TYPE_CLASS_NUMBER);

                    editTextCardHolder.setHint("Card Holder");
                    editTextCardNumber.setHint("Card Number");
                    editTextCardHolder.setVisibility(View.VISIBLE);
                    editTextExpiryDate.setVisibility(View.VISIBLE);
                    editTextPostCode.setVisibility(View.VISIBLE);
                    buttonAddCard.setText("Add Card");
                }


            }
        });


        editTextExpiryDate.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                try {
                    formatCardExpiringDate(editable);
                } catch (NumberFormatException e) {
                    editable.clear();

                }


            }
        });


    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.textViewStart:
                onBackPressed();
                break;
            case R.id.buttonAddCard:
               /* Intent intent = new Intent(getApplicationContext(), AddPhoneActivity.class);
                startActivity(intent);*/

                if (getIntent().hasExtra("fromCart")) {
                    LogUtil.debug("FROMCART=====>>>>>");
                    if (isOnline())
                        processToAddPayment();
                } else {
                    if (isOnline())
                        processToRegister();
                }
                break;
        }
    }

    private void processToAddPayment() {

        if (!validation()) {
            return;
        }

        Map<String, String> param = getParam();
        param.put("user_id", prefs.getUserId());

        if (radioButtonPaymentMethod1.isChecked()) {
            param.put("payment_method", "paypal");
        } else {
            param.put("payment_method", "card");
        }

        param.put("payment_uniqid", editTextCardNumber.getText().toString());
        param.put("mm_yy", editTextExpiryDate.getText().toString());
        param.put("postcode", editTextPostCode.getText().toString());

        showProgressDialog();
        LogUtil.debug("PARAMETER====>>>>>" + param);
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.INSERT_PAYMENT_METHOD, UserDetails.class, param, new Response.Listener<UserDetails>() {
            @Override
            public void onResponse(UserDetails userDetails) {
                dismissProgressDialog();
                if (userDetails.getResult()) {
                    LogUtil.debug("SUCCESSSS=====>>>" + userDetails.getMessage());
                    showMessage(userDetails.getMessage());
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Intent intent = new Intent();
                            intent.putExtra("refresh", true);
                            setResult(1, intent);
                            onBackPressed();
                        }
                    }, 1000);

                } else {
                    showMessage(userDetails.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                dismissProgressDialog();
                showErrorMessage(volleyError);
            }
        }, new BaseDeserializer<>(UserDetails.class));
        baseHttpRequest.setToken(prefs.getAccessTocken());
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }


    private void processToRegister() {

        if (!validation()) {
            return;
        }

        userDetails.payment_method = radioButtonPaymentMethod1.isChecked() ? "paypal" : "card";
        userDetails.payment_uniqid = editTextCardNumber.getText().toString();
        userDetails.mm_yy = editTextExpiryDate.getText().toString();
        userDetails.post_code = editTextPostCode.getText().toString();

        Intent intent = new Intent(this, MyCleanBagPlanActivity.class);
        intent.putExtra("from", "AddPaymentMethodActivity");
        intent.putExtra("user", userDetails);
        intent.putExtra("password", password);
        startActivity(intent);


//        Long timeStamp = System.currentTimeMillis() / 1000L;

       /* Map<String, String> param = getParam();
        param.put("fname", userDetails.fname);
        param.put("lname", userDetails.lname);
        param.put("email", userDetails.email);
        param.put("password", password);
        param.put("gender", userDetails.gender);

        param.put("dob", userDetails.dob);
        param.put("mobile_number", userDetails.mobile_no);
        param.put("gcm_id", prefs.getGcmToken());
        param.put("timestamp", String.valueOf(timeStamp).trim());
        param.put("user_role", "Customer");
        param.put("post_code", userDetails.post_code);
        param.put("country", userDetails.country);
        param.put("city", userDetails.city);
        param.put("useraddress", userDetails.address);
        param.put("latitude", userDetails.latitude);
        param.put("logitude", userDetails.longitude);

        if (radioButtonPaymentMethod1.isChecked()) {
            param.put("payment_method", "paypal");
        } else {
            param.put("payment_method", "card");
        }

        param.put("payment_uniqid", editTextCardNumber.getText().toString());
        param.put("mm_yy", editTextExpiryDate.getText().toString());
        param.put("postcode", editTextPostCode.getText().toString());

        showProgressDialog();
        LogUtil.debug("PARAMETER====>>>>>" + param);
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.USER_REGISTER, UserDetails.class, param, new Response.Listener<UserDetails>() {
            @Override
            public void onResponse(UserDetails userDetails) {
                dismissProgressDialog();
                if (userDetails.getResult()) {
                    LogUtil.debug("SUCCESSSS=====>>>" + userDetails.getMessage());
                    showMessage(userDetails.getMessage());

                    Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();

                } else {
                    showMessage(userDetails.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                dismissProgressDialog();
                showErrorMessage(volleyError);
            }
        }, new BaseDeserializer<>(UserDetails.class));
        AppController.getInstance().addToRequestQueue(baseHttpRequest);*/
    }

    private boolean validation() {
        boolean check = true;

        if (radioButtonPaymentMethod1.isChecked()) {
            if (!Validation.hasText(editTextCardNumber)) check = false;
        } else {
            if (!Validation.hasText(editTextCardHolder)) check = false;
            if (!Validation.isCardNumber(editTextCardNumber, true)) check = false;
            if (!Validation.isCard(editTextExpiryDate, true)) check = false;
            if (!Validation.isZipCode(editTextPostCode, true)) check = false;
        }

        return check;
    }

    private void formatCardExpiringDate(Editable s) {
        String input = s.toString();
        String mLastInput = "";

        SimpleDateFormat formatter = new SimpleDateFormat("MM/yy", Locale.ENGLISH);
        Calendar expiryDateDate = Calendar.getInstance();

        try {
            expiryDateDate.setTime(formatter.parse(input));
        } catch (java.text.ParseException e) {
            if (s.length() == 2 && !mLastInput.endsWith("/") && isSlash) {
                isSlash = false;
                int month = Integer.parseInt(input);
                if (month <= 12) {
                    editTextExpiryDate.setText(editTextExpiryDate.getText().toString().substring(0, 1));
                    editTextExpiryDate.setSelection(editTextExpiryDate.getText().toString().length());
                } else {
                    s.clear();
                    editTextExpiryDate.setText("");
                    editTextExpiryDate.setSelection(editTextExpiryDate.getText().toString().length());
                    Toast.makeText(context.getApplicationContext(), "Enter a valid month", Toast.LENGTH_LONG).show();
                }
            } else if (s.length() == 2 && !mLastInput.endsWith("/") && !isSlash) {
                isSlash = true;
                int month = Integer.parseInt(input);
                if (month <= 12) {
                    editTextExpiryDate.setText(editTextExpiryDate.getText().toString() + "/");
                    editTextExpiryDate.setSelection(editTextExpiryDate.getText().toString().length());
                } else if (month > 12) {
                    editTextExpiryDate.setSelection(editTextExpiryDate.getText().toString().length());
                    s.clear();
                    showMessage("invalid month");
                }


            } else if (s.length() == 1) {

                int month = Integer.parseInt(input);
                if (month > 1 && month < 12) {
                    isSlash = true;
                    editTextExpiryDate.setText("0" + editTextExpiryDate.getText().toString() + "/");
                    editTextExpiryDate.setSelection(editTextExpiryDate.getText().toString().length());
                }
            }

            mLastInput = editTextExpiryDate.getText().toString();
            return;
        }
    }

}
