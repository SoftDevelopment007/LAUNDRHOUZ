package com.laundrhouz.android.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.braintreepayments.api.dropin.DropInActivity;
import com.braintreepayments.api.dropin.DropInRequest;
import com.braintreepayments.api.dropin.DropInResult;
import com.laundrhouz.android.R;

import java.util.HashMap;

import modules.base.ActivityBase;
import modules.base.LogUtil;

public class CheckoutActivity extends ActivityBase {

    EditText edtTextAmount;
    Button btnPay;
    int DROP_IN_REQUEST = 100;

    String API_GET_TOCKEN = "";
    String API_CHECK_OUT = "";

    String tocken, amount;
    HashMap<String, String> paramHash;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);
        initComponant();
        itemClickListner();
    }

    private void initComponant() {
        btnPay = findViewById(R.id.btnPay);
        edtTextAmount = findViewById(R.id.edtTextAmount);

    }

    private void setData() {
        DropInRequest dropInRequest = new DropInRequest()
                .clientToken("123");
        startActivityForResult(dropInRequest.getIntent(context), DROP_IN_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == DROP_IN_REQUEST) {
            if (resultCode == RESULT_OK) {
                DropInResult result = data.getParcelableExtra(DropInResult.EXTRA_DROP_IN_RESULT);
                String paymentMethodNonce = result.getPaymentMethodNonce().getNonce();
                // send paymentMethodNonce to your server
                LogUtil.debug("PAYMENT===>>>" + paymentMethodNonce);
            } else if (resultCode == RESULT_CANCELED) {
                LogUtil.debug("PAYMENT===>>>" + "Cancled");
                // canceled
            } else {
                // an error occurred, checked the returned exception
                Exception exception = (Exception) data.getSerializableExtra(DropInActivity.EXTRA_ERROR);
                exception.printStackTrace();
            }
        }
    }

    private void itemClickListner() {
        btnPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setData();
            }
        });
    }
}
