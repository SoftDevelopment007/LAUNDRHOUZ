package com.laundrhouz.android.fragments;


import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.google.android.material.tabs.TabLayout;
import com.laundrhouz.android.R;
import com.laundrhouz.android.activities.ItemDetailActivity;
import com.laundrhouz.android.activities.LoginActivity;
import com.laundrhouz.android.activities.NotificationsActivity;
import com.laundrhouz.android.activities.OTPVerifyActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import modules.adapter.ViewPagerAdapter;
import modules.app.AppController;
import modules.base.FragmentBase;
import modules.base.LogUtil;
import modules.bean.CategoryDetails;
import modules.blu.ServerHelper;
import modules.deserializer.BaseDeserializerList;
import modules.http.BaseHttpRequest;
import modules.http.ResponseData;
import modules.utils.SnappingLinearLayoutManager;

public class HomeFragment extends FragmentBase implements View.OnClickListener {

    private TextView textViewStrikePrice;
    private CardView cardViewOffer;
    private ViewPager viewpager_subCategory;
    private List<CategoryDetails> categoryDetailsList;
    private ViewPagerAdapter adapter;
    private int categoryPosition = 0;
    private SnappingLinearLayoutManager snappingLinearLayoutManager;
    TabLayout tabLayoutCategory;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        Objects.requireNonNull(getActivity()).findViewById(R.id.textViewEnd).setOnClickListener(this);
        initComponent(view);
        itemClickListner();
        return view;
    }

    private void initComponent(View view) {
        tabLayoutCategory = view.findViewById(R.id.tabLayoutCategory);
        viewpager_subCategory = view.findViewById(R.id.viewpager_subCategory);
        textViewStrikePrice = view.findViewById(R.id.textViewStrikePrice);
        textViewStrikePrice.setPaintFlags(textViewStrikePrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        cardViewOffer = view.findViewById(R.id.cardViewOffer);

        adapter = new ViewPagerAdapter(getFragmentManager());

        categoryDetailsList = new ArrayList<>();
        snappingLinearLayoutManager = new SnappingLinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);

        setData();
    }

    private void setData() {

        if (isOnline())
            processToLoadCategory();
    }

    private void processToLoadCategory() {
        Map<String, String> param = new HashMap<>();
//        param.put("user_id", "1");
        showProgressDialog();
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.FETCH_CATEGORY, ResponseData.class, param, new Response.Listener<ResponseData>() {
            @Override
            public void onResponse(ResponseData response) {
                dismissProgressDialog();
                categoryDetailsList.clear();
                if (response.getResult()) {
                    List<CategoryDetails> tempList = (List<CategoryDetails>) response.getData();
                    categoryDetailsList.addAll(tempList);
                    LogUtil.debug("LIST=====>>>>>" + categoryDetailsList.size());
                    addTabs();
                } else {
                    showMessage(response.getMessage());
                    LogUtil.debug("RESPONSE_CATEGORY========>>>>" + response.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dismissProgressDialog();
                showErrorMessage(error);
            }
        }, new BaseDeserializerList<>(ResponseData.class, CategoryDetails.class));
//        baseHttpRequest.setToken("MTVmOTA1M2It");
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

    private void addTabs() {

        adapter = new ViewPagerAdapter(getFragmentManager());
        for (int i = 0; i < categoryDetailsList.size(); i++) {
            adapter.addFrag(FragmentTabLayout.getInstance(categoryDetailsList.get(i), i), categoryDetailsList.get(i).name);
        }
        viewpager_subCategory.setAdapter(adapter);
        LayoutInflater inflator = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        tabLayoutCategory.setupWithViewPager(viewpager_subCategory);
//        int icons[] = {R.drawable.address,R.drawable.address,R.drawable.address,R.drawable.address};
        for (int i = 0; i < categoryDetailsList.size(); i++) {

            TabLayout.Tab tab = tabLayoutCategory.getTabAt(i);
            View v = inflator.from(getActivity()).inflate(R.layout.tabs, null, false);
            TextView tv = v.findViewById(R.id.title);
            tv.setText(categoryDetailsList.get(i).name);
            ImageView img = v.findViewById(R.id.icon);
            final ImageView imageViewLoadingIcon = v.findViewById(R.id.imageViewLoadingIcon);

            imageViewLoadingIcon.setVisibility(View.VISIBLE);
            Glide.with(context)
                    .load(ServerHelper.IMAGE_PATH + categoryDetailsList.get(i).image)
                    .listener(new RequestListener<Drawable>() {
                        @Override
                        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                            imageViewLoadingIcon.setVisibility(View.GONE);
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                            imageViewLoadingIcon.setVisibility(View.GONE);
                            return false;
                        }
                    })
                    .apply(new RequestOptions().error(R.drawable.no_image_found))
                    .into(img);

            tab.setCustomView(v);
        }
    }

    private void itemClickListner() {
        cardViewOffer.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent intent;
        switch (view.getId()) {
            case R.id.cardViewOffer:
                intent = new Intent(getContext(), ItemDetailActivity.class);
                startActivityForResult(intent, 1);
                break;
            case R.id.textViewEnd:
                if (prefs.isLogin()) {
                    if (prefs.getIsVerify().equalsIgnoreCase("1")) {
                        intent = new Intent(getContext(), NotificationsActivity.class);
                        startActivity(intent);
                    } else {
                        intent = new Intent(getContext(), OTPVerifyActivity.class);
                        startActivity(intent);
                    }
                } else {
                    intent = new Intent(getContext(), LoginActivity.class);
                    startActivity(intent);
                }
                break;
        }
    }


}
