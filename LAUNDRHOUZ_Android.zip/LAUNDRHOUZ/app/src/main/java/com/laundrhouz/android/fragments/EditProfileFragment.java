package com.laundrhouz.android.fragments;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.laundrhouz.android.R;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import modules.app.AppController;
import modules.base.FragmentBase;
import modules.base.LogUtil;
import modules.bean.UserDetails;
import modules.blu.ServerHelper;
import modules.deserializer.BaseDeserializer;
import modules.http.BaseHttpRequest;
import modules.http.BaseUploadHttpRequest;
import modules.validation.Validation;

import static android.app.Activity.RESULT_OK;

public class EditProfileFragment extends FragmentBase implements View.OnClickListener {
    private EditText editTextFirstName, editTextLastName, editTextDOB, editTextGender;
    private Button buttonUpdateProfile;
    ImageView imageViewUser, imageViewLoadingIcon;
    private Map<String, File> uploadFiles = new HashMap<>();
    private int selectedImageNumber;
    Activity activity;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_edit_profile, container, false);
        this.activity = viewContext;
        initComponant(view);
        itemClickListner();
        return view;
    }

    private void initComponant(View view) {
        editTextFirstName = view.findViewById(R.id.editTextFirstName);
        editTextLastName = view.findViewById(R.id.editTextLastName);
        editTextDOB = view.findViewById(R.id.editTextDOB);
        editTextGender = view.findViewById(R.id.editTextGender);
        buttonUpdateProfile = view.findViewById(R.id.buttonUpdateProfile);
        imageViewUser = view.findViewById(R.id.imageViewUser);
        imageViewLoadingIcon = view.findViewById(R.id.imageViewLoadingIcon);

        editTextFirstName.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        editTextLastName.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        editTextDOB.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        editTextGender.setBackgroundResource(R.drawable.edittext_credentials_back_white);

        setData();
    }

    private void setData() {
        editTextFirstName.setText(prefs.getFirstName());
        editTextLastName.setText(prefs.getLastName());
        editTextDOB.setText(prefs.getDob());

        if (prefs.getGender().equalsIgnoreCase("1")) {
            editTextGender.setText("Male");
            editTextGender.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.male, 0);
        } else {
            editTextGender.setText("Female");
            editTextGender.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.female, 0);
        }

        imageViewLoadingIcon.setVisibility(View.VISIBLE);
        if (prefs.getUserImage().contains("http")) {
            Glide.with(context)
                    .load(prefs.getUserImage())
                    .listener(new RequestListener<Drawable>() {
                        @Override
                        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                            imageViewLoadingIcon.setVisibility(View.GONE);
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                            imageViewLoadingIcon.setVisibility(View.GONE);
                            return false;
                        }
                    })
                    .apply(new RequestOptions().error(R.drawable.user))
                    .into(imageViewUser);
        } else {
            Glide.with(context)
                    .load(ServerHelper.IMAGE_PATH + prefs.getUserImage())
                    .listener(new RequestListener<Drawable>() {
                        @Override
                        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                            imageViewLoadingIcon.setVisibility(View.GONE);
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                            imageViewLoadingIcon.setVisibility(View.GONE);
                            return false;
                        }
                    })
                    .apply(new RequestOptions().error(R.drawable.user))
                    .into(imageViewUser);
        }
    }

    private void itemClickListner() {
        editTextGender.setOnClickListener(this);
        editTextDOB.setOnClickListener(this);
        buttonUpdateProfile.setOnClickListener(this);
        imageViewUser.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.editTextGender:
                if (editTextGender.getText().toString().equalsIgnoreCase("Male")) {
                    editTextGender.setText("Female");
                    editTextGender.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.female, 0);
                } else {
                    editTextGender.setText("Male");
                    editTextGender.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.male, 0);
                }
                break;
            case R.id.editTextDOB:
                setDateTimeField(editTextDOB);
                break;
            case R.id.buttonUpdateProfile:
                if (isOnline())
                    processToUpdateProfile();
                break;
            case R.id.imageViewUser:
                Intent intent = CropImage.activity()
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .getIntent(getActivity());

                startActivityForResult(intent, CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE);
              /*  if (PermissionManager.checkStoragePermission(getActivity())) {
                    CropImage.activity()
                            .setGuidelines(CropImageView.Guidelines.ON)
                            .start(getContext(), this);
                }*/
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {
                Uri resultUri = result.getUri();
                Bitmap bitmap;
                try {
                    bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), resultUri);
                    uploadFiles.put("profile_image", new File(getRealPathFromURI(resultUri)));
                    LogUtil.debug("PROFILE_IMAGE====>>>" + resultUri);
                    imageViewUser.setImageBitmap(bitmap);
                } catch (IOException e) {
                    e.printStackTrace();
                    showMessage("Error in selecting image" + e.getLocalizedMessage());
                }
            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
                showMessage("Error in selecting image " + error.getLocalizedMessage());
            }
        }
    }

    private String getRealPathFromURI(Uri contentURI) {
        String result;
        Cursor cursor = getActivity().getContentResolver().query(contentURI, null, null, null, null);
        if (cursor == null) { // Source is Dropbox or other similar local file path
            result = contentURI.getPath();
        } else {
            cursor.moveToFirst();
            int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            result = cursor.getString(idx);
            cursor.close();
        }
        return result;
    }

    private void setDateTimeField(final EditText editText) {

        Calendar newCalendar = Calendar.getInstance();
        DatePickerDialog mDatePickerDialog = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                @SuppressLint("SimpleDateFormat") SimpleDateFormat sd = new SimpleDateFormat("dd-MM-yyyy");
                final Date startDate = newDate.getTime();
                String fdate = sd.format(startDate);

                editText.setText(fdate);

            }
        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
        mDatePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        mDatePickerDialog.show();
    }

    private void processToUpdateProfile_Old() {
        if (!validate()) return;

        Map<String, String> param = getParam();
        param.put("user_id", prefs.getUserId());
        param.put("fname", editTextFirstName.getText().toString());
        param.put("lname", editTextLastName.getText().toString());
        if (editTextGender.getText().toString().trim().equalsIgnoreCase("Male")) {
            param.put("gender", "1");
        } else {
            param.put("gender", "2");
        }
        param.put("dob", editTextDOB.getText().toString());

        LogUtil.debug("PARAMETER====>>>>>" + param);
        showProgressDialog();
        BaseUploadHttpRequest baseHttpRequest = new BaseUploadHttpRequest<>(ServerHelper.UPDATE_PROFILE, UserDetails.class, param, uploadFiles, new Response.Listener<UserDetails>() {
            @Override
            public void onResponse(UserDetails userDetails) {
                dismissProgressDialog();
                if (userDetails.getResult()) {
                    saveDataToLocal(userDetails);
                    showMessage(userDetails.getMessage());
                } else {
                    showMessage(userDetails.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                dismissProgressDialog();
                showErrorMessage(volleyError);
                volleyError.printStackTrace();
            }
        }, new BaseDeserializer<>(UserDetails.class));
        baseHttpRequest.setToken(prefs.getAccessTocken());
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }


    private void processToUpdateProfile() {

        if (!validate()) return;

        Map<String, String> param = getParam();
        param.put("user_id", prefs.getUserId());
        param.put("fname", editTextFirstName.getText().toString());
        param.put("lname", editTextLastName.getText().toString());
        if (editTextGender.getText().toString().trim().equalsIgnoreCase("Male")) {
            param.put("gender", "1");
        } else {
            param.put("gender", "2");
        }
        param.put("dob", editTextDOB.getText().toString());

        LogUtil.debug("PARAMETER====>>>>>" + param);
        LogUtil.debug("PARAMETER_UPLOAD====>>>>>" + uploadFiles);
        showProgressDialog();
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.UPDATE_PROFILE, UserDetails.class, param, new Response.Listener<UserDetails>() {
            @Override
            public void onResponse(UserDetails userDetails) {
                dismissProgressDialog();
                if (userDetails.getResult()) {
                    saveDataToLocal(userDetails);
                    showMessage(userDetails.getMessage());
                    getActivity().finish();
                } else {
                    showMessage(userDetails.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                dismissProgressDialog();
                showErrorMessage(volleyError);
            }
        }, new BaseDeserializer<>(UserDetails.class));
        baseHttpRequest.setToken(prefs.getAccessTocken());
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

    private void saveDataToLocal(UserDetails userDetails) {
        prefs.setFirstName(userDetails.fname);
        prefs.setLastName(userDetails.lname);
        prefs.setDob(userDetails.dob);
        prefs.setGender(userDetails.gender);
        prefs.setUserImage(userDetails.logo);
    }

    private boolean validate() {

        boolean check = true;
        if (!Validation.hasText(editTextFirstName)) check = false;
        if (!Validation.hasText(editTextLastName)) check = false;

        return check;
    }
}
