package com.laundrhouz.android.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.laundrhouz.android.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import modules.adapter.MyOrdersAdapter;
import modules.app.AppController;
import modules.base.ActivityBase;
import modules.base.LogUtil;
import modules.bean.MasterOrderDetails;
import modules.blu.ServerHelper;
import modules.deserializer.BaseDeserializerList;
import modules.http.BaseHttpRequest;
import modules.http.ResponseData;

public class MyOrdersActivity extends ActivityBase implements View.OnClickListener {

    RecyclerView recyclerViewMyOrders;
    MyOrdersAdapter myOrdersAdapter;
    List<String> stringList;
    List<MasterOrderDetails> masterOrderDetailsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_orders);
        setToolbar();
        initComponent();
    }

    private void setToolbar() {
        TextView textViewToolbarTitle = findViewById(R.id.textViewToolbarTitle);
        textViewToolbarTitle.setText(getResources().getString(R.string.my_orders));
        TextView textViewStart = findViewById(R.id.textViewStart);
        textViewStart.setOnClickListener(this);
    }

    private void initComponent() {
        recyclerViewMyOrders = findViewById(R.id.recyclerViewMyOrders);

        stringList = new ArrayList<>();
        masterOrderDetailsList = new ArrayList<>();

        setData();

    }

    private void setData() {

        myOrdersAdapter = new MyOrdersAdapter(MyOrdersActivity.this, masterOrderDetailsList, stringList);
        recyclerViewMyOrders.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerViewMyOrders.setAdapter(myOrdersAdapter);

        stringList.add("Delivered");
        stringList.add("Pending");
        stringList.add("Canceled");
        stringList.add("Delivered");
        stringList.add("Pending");
        stringList.add("Canceled");
        stringList.add("Delivered");
        stringList.add("Pending");
        stringList.add("Canceled");

        if (isOnline())
            processToLoadOrder();
    }

    private void processToLoadOrder() {
        Map<String, String> param = new HashMap<>();
        param.put("user_id", prefs.getUserId());
        showProgressDialog();
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.FETCH_MASTER_ORDER_HISTORY, ResponseData.class, param, new Response.Listener<ResponseData>() {
            @Override
            public void onResponse(ResponseData response) {
                dismissProgressDialog();
                masterOrderDetailsList.clear();
                if (response.getResult()) {
                    masterOrderDetailsList.addAll((List<MasterOrderDetails>) response.getData());
                    LogUtil.debug("LIST=====>>>>>" + masterOrderDetailsList.size());
                } else {
                    showMessage(response.getMessage());
                }
                myOrdersAdapter.notifyDataSetChanged();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dismissProgressDialog();
                showErrorMessage(error);
            }
        }, new BaseDeserializerList<>(ResponseData.class, MasterOrderDetails.class));
        baseHttpRequest.setToken(prefs.getAccessTocken());
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.textViewStart:
                onBackPressed();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        if (getIntent().hasExtra("fromNotification")) {
            Intent intent = new Intent(MyOrdersActivity.this, HomeActivity.class);
            intent.putExtra("fromNotification", "fromNotification");
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        } else {
            super.onBackPressed();
        }
    }
}
