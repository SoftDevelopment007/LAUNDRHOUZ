package com.laundrhouz.android.activities;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.laundrhouz.android.R;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import modules.base.ActivityBaseLocation;
import modules.download.PermissionManager;

public class CheckLocationActivity extends ActivityBaseLocation implements View.OnClickListener {

    Button buttonCheckAvailability;
    TextView buttonEnterLocation;
    ImageButton imageViewCurrentLocation;
    RelativeLayout relativeLayoutCurrentLocation;
    Geocoder geocoder;
    List<Address> addresses;
    double latitude, longitude;
    private FusedLocationProviderClient fusedLocationProviderClient;
    boolean isForReuest = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_location);
        initComponent();
        itemClickListner();
    }

    @Override
    public void updatedLocation(Location location) {
        latitude = location.getLatitude();
        longitude = location.getLongitude();
        dismissProgressDialog();
        if (isForReuest) {
            setData();
        }

    }

    private void initComponent() {
        buttonCheckAvailability = findViewById(R.id.buttonCheckAvailability);
        buttonEnterLocation = findViewById(R.id.buttonEnterLocation);
        imageViewCurrentLocation = findViewById(R.id.imageViewCurrentLocation);
        relativeLayoutCurrentLocation = findViewById(R.id.relativeLayoutCurrentLocation);

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        geocoder = new Geocoder(this, Locale.getDefault());

        setData();
    }

    private void itemClickListner() {
        buttonCheckAvailability.setOnClickListener(this);
//        imageViewCurrentLocation.setOnClickListener(this);
        relativeLayoutCurrentLocation.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.buttonCheckAvailability:
                if (isOnline())
                    setLocation();
                break;


            case R.id.relativeLayoutCurrentLocation:
                if (isOnline())
                    setLocation();
                break;

        }
    }

    private void setLocation() {
        if (isLocationEnable()) {
            if (latitude != 0 && longitude != 0) {
                setData();
            } else {
                isForReuest = true;
                requestForLocationFromActivity();
            }
        } else {
            isForReuest = true;
            setUpdateLocation();
        }
    }

    private void fetchLastLocation() {

        if (PermissionManager.checkLocationPermission(CheckLocationActivity.this)) {
            Task<Location> task = fusedLocationProviderClient.getLastLocation();
            task.addOnSuccessListener(new OnSuccessListener<Location>() {
                @Override
                public void onSuccess(Location location) {
                    if (location != null) {
                        latitude = location.getLatitude();
                        longitude = location.getLongitude();
                        setData();
                    } else {
                        Toast.makeText(CheckLocationActivity.this, "No Location recorded", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

   /* @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            LogUtil.debug("GRANTED=======>>>>>>>>>>");
            isForReuest = true;
            requestForLocationFromActivity();
        }

    }*/

    private void setData() {
//        if (PermissionManager.checkLocationPermission(CheckLocationActivity.this)) {
        if (latitude != 0 && longitude != 0) {
            try {
                addresses = geocoder.getFromLocation(latitude, longitude, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
            } catch (IOException e) {
                e.printStackTrace();
            }

            final String postalCode = addresses.get(0).getPostalCode();
            buttonEnterLocation.setText(postalCode);

            showProgressDialog();

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    dismissProgressDialog();
                    Intent intent = new Intent(CheckLocationActivity.this, ComingSoonActivity.class);
                    intent.putExtra("postalCode", postalCode);
                    startActivity(intent);
//                    finish();
                }
            }, 1000);
//            }
        }
    }

}
