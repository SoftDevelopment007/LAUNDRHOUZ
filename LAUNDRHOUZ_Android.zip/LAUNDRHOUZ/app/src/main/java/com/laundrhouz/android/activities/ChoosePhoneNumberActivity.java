package com.laundrhouz.android.activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.laundrhouz.android.R;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import modules.adapter.PhoneNumberAdapter;
import modules.customeviews.RecyclerItemTouchHelper;
import modules.app.AppController;
import modules.base.ActivityBase;
import modules.bean.PhoneNumberDetails;
import modules.blu.ServerHelper;
import modules.deserializer.BaseDeserializerList;
import modules.http.BaseHttpRequest;
import modules.http.ResponseData;

public class ChoosePhoneNumberActivity extends ActivityBase implements View.OnClickListener {

    RecyclerView recyclerViewPhoneNumber;
    PhoneNumberAdapter phoneNumberAdapter;
    List<PhoneNumberDetails> phoneNumberDetailsList;
    RelativeLayout relativeLayoutAddNewPhoneNumber;
    int height;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_phone_number);
        setToolbar();
        initComponent();
    }

    private void initComponent() {
        recyclerViewPhoneNumber = findViewById(R.id.recyclerViewPhoneNumber);
        relativeLayoutAddNewPhoneNumber = findViewById(R.id.relativeLayoutAddNewPhoneNumber);

        phoneNumberDetailsList = new ArrayList<>();

        relativeLayoutAddNewPhoneNumber.setOnClickListener(this);

        setData();
    }

    private void setData() {

        phoneNumberAdapter = new PhoneNumberAdapter(ChoosePhoneNumberActivity.this, phoneNumberDetailsList);
        recyclerViewPhoneNumber.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerViewPhoneNumber.setAdapter(phoneNumberAdapter);
        phoneNumberAdapter.setOnClick(new PhoneNumberAdapter.onClick() {
            @Override
            public void sendHeight(int h) {
                height = h;
            }
        });


        final Bitmap delete = BitmapFactory.decodeResource(getResources(), R.drawable.basket);
        final Bitmap edit = BitmapFactory.decodeResource(getResources(), R.drawable.edit2);

        new RecyclerItemTouchHelper(this, this, recyclerViewPhoneNumber, height) {
            @Override
            public void instantiateUnderlayButton(RecyclerView.ViewHolder viewHolder, List<UnderlayButton> underlayButtons) {
                underlayButtons.add(new RecyclerItemTouchHelper.UnderlayButton(Color.parseColor("#FFFFFF"), delete, Color.parseColor("#C82C4D"),
                        new RecyclerItemTouchHelper.UnderlayButtonClickListener() {
                            @Override
                            public void onClick(int pos) {

                                if (isOnline())
                                    processToDeletePhoneNumber(phoneNumberDetailsList.get(pos).id);

                                phoneNumberAdapter.removeItem(pos);
                            }
                        }
                ));
                underlayButtons.add(new RecyclerItemTouchHelper.UnderlayButton(Color.parseColor("#000000"), edit, Color.parseColor("#D1D8E4"),
                        new RecyclerItemTouchHelper.UnderlayButtonClickListener() {
                            @Override
                            public void onClick(int pos) {
                                Intent intent = new Intent(ChoosePhoneNumberActivity.this, AddPhoneActivity.class);
                                intent.putExtra("forUpdate", true);
                                intent.putExtra("phoneDetails", phoneNumberDetailsList.get(pos));

                                startActivityForResult(intent, 1);

                            }
                        }
                ));
            }
        };


        processToLoadPhoneNumber();
    }

    private void setToolbar() {
        TextView textViewToolbarTitle = findViewById(R.id.textViewToolbarTitle);
        textViewToolbarTitle.setText(getResources().getString(R.string.phone));
        TextView textViewStart = findViewById(R.id.textViewStart);
        textViewStart.setOnClickListener(this);
    }

    private void processToLoadPhoneNumber() {
        Map<String, String> param = new HashMap<>();
        param.put("user_id", prefs.getUserId());
        showProgressDialog();
        phoneNumberDetailsList.clear();
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.FETCH_USER_PHONE, ResponseData.class, param, new Response.Listener<ResponseData>() {
            @Override
            public void onResponse(ResponseData response) {
                dismissProgressDialog();
                if (response.getResult()) {
                    phoneNumberDetailsList.addAll((Collection<? extends PhoneNumberDetails>) response.getData());
                } else {
                    showMessage(response.getMessage());
                }
                phoneNumberAdapter.notifyDataSetChanged();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dismissProgressDialog();
                showErrorMessage(error);
            }
        }, new BaseDeserializerList<>(ResponseData.class, PhoneNumberDetails.class));
        baseHttpRequest.setToken(prefs.getAccessTocken());
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

    private void processToDeletePhoneNumber(String phone_id) {
        Map<String, String> param = new HashMap<>();
        param.put("user_id", prefs.getUserId());
        param.put("phone_id", phone_id);
        showProgressDialog();
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.DELETE_PHONE, ResponseData.class, param, new Response.Listener<ResponseData>() {
            @Override
            public void onResponse(ResponseData response) {
                dismissProgressDialog();
                if (response.getResult()) {

                    showMessage(response.getMessage());
                    processToLoadPhoneNumber();

                } else {
                    showMessage(response.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dismissProgressDialog();
                showErrorMessage(error);
            }
        }, new BaseDeserializerList<>(ResponseData.class, PhoneNumberDetails.class));
        baseHttpRequest.setToken(prefs.getAccessTocken());
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.textViewStart:
                onBackPressed();
                break;
            case R.id.relativeLayoutAddNewPhoneNumber:
                Intent intent = new Intent(ChoosePhoneNumberActivity.this, AddPhoneActivity.class);
                startActivityForResult(intent, 1);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (data != null) {
                if (isOnline())
                    processToLoadPhoneNumber();
            }
        }
    }
}
