package com.laundrhouz.android.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.laundrhouz.android.R;

import java.util.Map;

import modules.app.AppController;
import modules.base.FragmentBase;
import modules.base.LogUtil;
import modules.blu.ServerHelper;
import modules.deserializer.BaseDeserializer;
import modules.http.BaseHttpRequest;
import modules.http.ResponseData;
import modules.validation.Validation;

public class ChangePasswordFragment extends FragmentBase implements View.OnClickListener {

    private EditText editTextOldPassword, editTextNewPassword, editTextConfirmPassword;
    private Button buttonChangePassword;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_change_password, container, false);
        initComponant(view);
        itemClickListner();
        return view;
    }

    private void initComponant(View view) {
        editTextOldPassword = view.findViewById(R.id.editTextOldPassword);
        editTextNewPassword = view.findViewById(R.id.editTextNewPassword);
        editTextConfirmPassword = view.findViewById(R.id.editTextConfirmPassword);
        buttonChangePassword = view.findViewById(R.id.buttonChangePassword);

        editTextOldPassword.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        editTextNewPassword.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        editTextConfirmPassword.setBackgroundResource(R.drawable.edittext_credentials_back_white);
    }


    private void itemClickListner() {
        buttonChangePassword.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.buttonChangePassword:
                if (isOnline())
                    processToChangePassword();
                break;
        }
    }

    private void processToChangePassword() {

        if (!validationForPassword()) {
            return;
        }
        Map<String, String> param = getParam();
        param.put("user_id", prefs.getUserId());
        param.put("oldpass", editTextOldPassword.getText().toString());
        param.put("newpass", editTextNewPassword.getText().toString());

        showProgressDialog();
        LogUtil.debug("PARAMETER====>>>>>" + param);
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.CHANGE_PASSWORD, ResponseData.class, param, new Response.Listener<ResponseData>() {
            @Override
            public void onResponse(ResponseData userDetails) {
                dismissProgressDialog();
                if (userDetails.getResult()) {
                    editTextOldPassword.setText("");
                    editTextNewPassword.setText("");
                    editTextConfirmPassword.setText("");
                    getActivity().finish();
                    showMessage(userDetails.getMessage());
                } else {
                    showMessage(userDetails.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                dismissProgressDialog();
                showErrorMessage(volleyError);
            }
        }, new BaseDeserializer<>(ResponseData.class));
        baseHttpRequest.setToken(prefs.getAccessTocken());
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

    private boolean validationForPassword() {
        boolean check = true;
        if (!Validation.hasText(editTextOldPassword)) check = false;
        if (!Validation.hasText(editTextNewPassword)) check = false;
        if (!Validation.isConfirmPassword(editTextNewPassword, editTextConfirmPassword))
            check = false;
        return check;
    }
}
