package com.laundrhouz.android.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.laundrhouz.android.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import modules.app.AppController;
import modules.base.ActivityBase;
import modules.base.LogUtil;
import modules.bean.CityDetails;
import modules.bean.CountryDetails;
import modules.bean.UserDetails;
import modules.blu.ServerHelper;
import modules.customeviews.SearchableSpinner;
import modules.deserializer.BaseDeserializerList;
import modules.http.BaseHttpRequest;
import modules.http.ResponseData;
import modules.validation.Validation;

public class AddAddressActivity extends ActivityBase implements View.OnClickListener {

    Button buttonAddAddress;
    EditText editTextAddress, editTextCity, editTextPostCode, editTextCountry;
    UserDetails userDetails;
    String password;
    List<CountryDetails> countryDetailsList;
    List<CityDetails> cityDetailsList;
    String countryId, cityId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_address);
        setToolbar();
        initComponent();

        if (getIntent() != null) {
            userDetails = (UserDetails) getIntent().getSerializableExtra("userDetails");
            password = getIntent().getStringExtra("password");
        }
    }

    private void setToolbar() {
        TextView textViewToolbarTitle = findViewById(R.id.textViewToolbarTitle);
        textViewToolbarTitle.setText(getResources().getString(R.string.address));
        TextView textViewStart = findViewById(R.id.textViewStart);
        textViewStart.setOnClickListener(this);
    }

    private void initComponent() {
        buttonAddAddress = findViewById(R.id.buttonAddAddress);
        editTextAddress = findViewById(R.id.editTextAddress);
        editTextAddress.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        editTextCity = findViewById(R.id.editTextCity);
        editTextCity.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        editTextPostCode = findViewById(R.id.editTextPostCode);
        editTextPostCode.setBackgroundResource(R.drawable.edittext_credentials_back_white);
        editTextCountry = findViewById(R.id.editTextCountry);
        editTextCountry.setBackgroundResource(R.drawable.edittext_credentials_back_white);

        countryDetailsList = new ArrayList<>();
        cityDetailsList = new ArrayList<>();

        buttonAddAddress.setOnClickListener(this);
        editTextCountry.setOnClickListener(this);
        editTextCity.setOnClickListener(this);

        if (isOnline())
            processToLoadCountry();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.buttonAddAddress:

                if (!validation()) {
                    return;
                }
                userDetails.address = editTextAddress.getText().toString();
                userDetails.country = countryId;
                userDetails.city = cityId;
                userDetails.post_code = editTextPostCode.getText().toString();

                Intent intent = new Intent(getApplicationContext(), AddPaymentMethodActivity.class);
                intent.putExtra("userDetails", userDetails);
                intent.putExtra("password", password);
                startActivity(intent);
                break;
            case R.id.textViewStart:
                onBackPressed();
                break;

            case R.id.editTextCountry:
                countryDialog();
                break;
            case R.id.editTextCity:
                CityDialog();
                break;
        }
    }

    private void countryDialog() {
        SearchableSpinner searchableSpinner = new SearchableSpinner(AddAddressActivity.this, R.style.DBTheme, countryDetailsList,
                "Select Country", new SearchableSpinner.OnSelectItem() {
            @Override
            public void selectItem(Object item) {
                editTextCountry.setText(((CountryDetails) item).name);
                LogUtil.debug("NAME==>>" + ((CountryDetails) item).name);
                LogUtil.debug("IDDDDD==>>" + ((CountryDetails) item).id);
                editTextCity.setText("");
                editTextCity.setHint("City");
                countryId = ((CountryDetails) item).id;
                processToLoadCity(((CountryDetails) item).id);
            }
        });
        searchableSpinner.show();
    }

    private void CityDialog() {
        SearchableSpinner searchableSpinner = new SearchableSpinner(AddAddressActivity.this, R.style.DBTheme, cityDetailsList,
                "Select City", new SearchableSpinner.OnSelectItem() {
            @Override
            public void selectItem(Object item) {
                editTextCity.setText(((CityDetails) item).name);
                cityId = ((CityDetails) item).id;


            }
        });
        searchableSpinner.show();


    }

    private void processToLoadCountry() {
        Map<String, String> param = new HashMap<>();

        showProgressDialog();
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.FETCH_COUNTRY, ResponseData.class, param, new Response.Listener<ResponseData>() {
            @Override
            public void onResponse(ResponseData response) {
                dismissProgressDialog();
                countryDetailsList.clear();
                if (response.getResult()) {
                    List<CountryDetails> tempList = (List<CountryDetails>) response.getData();
                    countryDetailsList.addAll(tempList);
                    LogUtil.debug("LIST=====>>>>>" + countryDetailsList.size());
                } else {
                    showMessage(response.getMessage());
                    LogUtil.debug("RESPONSE_CATEGORY========>>>>" + response.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dismissProgressDialog();
                showErrorMessage(error);
            }
        }, new BaseDeserializerList<>(ResponseData.class, CountryDetails.class));
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

    private void processToLoadCity(String id) {
        Map<String, String> param = new HashMap<>();
        param.put("country_id", id);

        showProgressDialog();
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.FETCH_CITY, ResponseData.class, param, new Response.Listener<ResponseData>() {
            @Override
            public void onResponse(ResponseData response) {
                dismissProgressDialog();
                cityDetailsList.clear();
                if (response.getResult()) {
                    List<CityDetails> tempList = (List<CityDetails>) response.getData();
                    cityDetailsList.addAll(tempList);
                    LogUtil.debug("LIST=====>>>>>" + cityDetailsList.size());
                } else {
                    showMessage(response.getMessage());
                    LogUtil.debug("RESPONSE_CATEGORY========>>>>" + response.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dismissProgressDialog();
                showErrorMessage(error);
            }
        }, new BaseDeserializerList<>(ResponseData.class, CityDetails.class));
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

    private boolean validation() {
        boolean check = true;
        if (!Validation.hasText(editTextAddress)) check = false;
        if (!Validation.hasText(editTextCity)) check = false;
//        if (!Validation.isZipCode(editTextPostCode, true)) check = false;
        if (!Validation.hasText(editTextPostCode)) check = false;
        if (!Validation.hasText(editTextCountry)) check = false;
        /*if (countryId == null) {
            showMessage("Please Select Country");
            check = false;
        }else if(cityId == null){
            showMessage("Please Select Country");
            check = false;
        }*/
        return check;
    }
}
