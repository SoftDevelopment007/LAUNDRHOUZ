package com.laundrhouz.android.activities;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.laundrhouz.android.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import modules.adapter.CardAdapter;
import modules.app.AppController;
import modules.base.ActivityBase;
import modules.base.LogUtil;
import modules.bean.InsertOrderDetails;
import modules.bean.PaymentMethodDetails;
import modules.blu.ServerHelper;
import modules.deserializer.BaseDeserializerList;
import modules.http.BaseHttpRequest;
import modules.http.ResponseData;

public class PaymentMethodActivity extends ActivityBase implements View.OnClickListener {

    RecyclerView recyclerViewCards;
    CardAdapter cardAdapter;
    RelativeLayout relativeLayoutAddNewCard;
    List<PaymentMethodDetails> paymentMethodDetailsList;
    InsertOrderDetails insertOrderDetails;
    PaymentMethodDetails paymentMethodDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_method);
        setToolbar();
        if (getIntent().hasExtra("orederDetails")) {
            insertOrderDetails = (InsertOrderDetails) getIntent().getSerializableExtra("orederDetails");
        }
        initComponent();
        itemClickListner();
    }

    private void setToolbar() {
        TextView textViewToolbarTitle = findViewById(R.id.textViewToolbarTitle);
        textViewToolbarTitle.setText(getResources().getString(R.string.add_payment_method));
        TextView textViewStart = findViewById(R.id.textViewStart);
        textViewStart.setOnClickListener(this);
    }

    private void initComponent() {
        relativeLayoutAddNewCard = findViewById(R.id.relativeLayoutAddNewCard);
        recyclerViewCards = findViewById(R.id.recyclerViewCards);

        paymentMethodDetailsList = new ArrayList<>();

        setData();
    }

    private void setData() {
        recyclerViewCards.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        cardAdapter = new CardAdapter(PaymentMethodActivity.this, paymentMethodDetailsList);
        cardAdapter.setItemSelect(new CardAdapter.ItemSelect() {
            @Override
            public void onSelect(int position) {
                paymentMethodDetails = new PaymentMethodDetails();

                paymentMethodDetails = paymentMethodDetailsList.get(position);

                /*for (int i = 0; i < paymentMethodDetailsList.size(); i++) {
                    if (paymentMethodDetailsList.get(i).isChecked) {
                        paymentMethodDetails = paymentMethodDetailsList.get(i);
                        break;
                    }
                }*/
                Intent intent = new Intent(PaymentMethodActivity.this, CollectionDateActivity.class);
                intent.putExtra("orederDetails", insertOrderDetails);
                intent.putExtra("paymentDetails", paymentMethodDetails);
                startActivity(intent);
            }
        });
        recyclerViewCards.setAdapter(cardAdapter);

        if (isOnline())
            processToLoadPaymentMethod();
    }

    private void itemClickListner() {
        relativeLayoutAddNewCard.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.textViewStart:
                onBackPressed();
                break;
            case R.id.relativeLayoutAddNewCard:
                Intent intent = new Intent(getApplicationContext(), AddPaymentMethodActivity.class);
                intent.putExtra("fromCart", "fromCart");
                startActivityForResult(intent, 1);
                break;
        }
    }

    private void processToLoadPaymentMethod() {
        Map<String, String> param = new HashMap<>();
        param.put("user_id", prefs.getUserId());
        showProgressDialog();
        BaseHttpRequest baseHttpRequest = new BaseHttpRequest<>(ServerHelper.FETCH_PAYMENT_METHOD, ResponseData.class, param, new Response.Listener<ResponseData>() {
            @Override
            public void onResponse(ResponseData response) {
                dismissProgressDialog();
                paymentMethodDetailsList.clear();
                if (response.getResult()) {
                    List<PaymentMethodDetails> tempList = (List<PaymentMethodDetails>) response.getData();
                    paymentMethodDetailsList.addAll(tempList);
                    LogUtil.debug("LIST=====>>>>>" + paymentMethodDetailsList.size());
                } else {
                    showMessage(response.getMessage());
                }
                cardAdapter.notifyDataSetChanged();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dismissProgressDialog();
                showErrorMessage(error);
            }
        }, new BaseDeserializerList<>(ResponseData.class, PaymentMethodDetails.class));
        baseHttpRequest.setToken(prefs.getAccessTocken());
        LogUtil.debug("ACCESS_TOCKEN===>>>" + prefs.getAccessTocken());
        AppController.getInstance().addToRequestQueue(baseHttpRequest);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (data != null) {
                if (isOnline())
                    processToLoadPaymentMethod();
            }
        }
    }


}
