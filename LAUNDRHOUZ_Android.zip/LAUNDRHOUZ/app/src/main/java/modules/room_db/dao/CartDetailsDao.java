package modules.room_db.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface CartDetailsDao {

    @Query("SELECT * FROM cart_details")
    List<CartDetails> getAll();

    @Query("SELECT * FROM cart_details where id=:otherUserId")
    CartDetails getUserDetails(String otherUserId);

    @Query("SELECT count(*)>0 FROM cart_details where product_id=:productId")
    boolean isExist(String productId);

    @Insert
    void insert(List<CartDetails> details);

    @Insert
    void insert(CartDetails... details);

    @Insert
    void insert(CartDetails details);

    @Update
    void update(CartDetails details);

    @Delete
    void delete(CartDetails user);

    @Query("DELETE FROM cart_details where product_id=:id")
    void delete(String id);

    @Query("DELETE FROM cart_details")
    void deleteAll();

    @Query("SELECT  quantity FROM cart_details where product_id=:itemId")
    int getQuantity(String itemId);

    @Query("UPDATE cart_details set quantity=:quantity where product_id=:id")
    void update(int quantity, String id);
}
