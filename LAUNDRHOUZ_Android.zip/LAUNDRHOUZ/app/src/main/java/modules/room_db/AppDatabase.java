package modules.room_db;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import android.content.Context;

import modules.room_db.dao.CartDetails;
import modules.room_db.dao.CartDetailsDao;
import modules.room_db.dao.NotificationDao;
import modules.room_db.dao.NotificationDetails;

@Database(entities = {CartDetails.class, NotificationDetails.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    private static final String DATABASE_NAME = "my_clean_bag_room_db";


    public abstract CartDetailsDao cartDetailsDao();

    public abstract NotificationDao notificationDao();


    private static AppDatabase INSTANCE;

    public static AppDatabase getAppDatabase(Context context) {
        if (INSTANCE == null) {
            INSTANCE =
                    Room.databaseBuilder(context.getApplicationContext(), AppDatabase.class, DATABASE_NAME)
                            .allowMainThreadQueries()
                            .build();
        }
        return INSTANCE;
    }

    public static void destroyInstance() {
        INSTANCE = null;
    }
}