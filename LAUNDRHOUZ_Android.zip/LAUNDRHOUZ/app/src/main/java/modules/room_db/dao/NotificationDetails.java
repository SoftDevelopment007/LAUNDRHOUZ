package modules.room_db.dao;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.google.gson.annotations.SerializedName;

import modules.http.ResponseData;

@Entity(tableName = "noticication_details")
public class NotificationDetails extends ResponseData {

    @PrimaryKey(autoGenerate = true)
    public int id;

    @SerializedName("notification_id")
    public int notification_id;
    @SerializedName("notification_type")
    public String notification_type;
    @SerializedName("title")
    public String title;
    @SerializedName("message")
    public String message;
    @SerializedName("notifaiction_date")
    public String notifaiction_date;
    @SerializedName("image")
    public String image;
    @SerializedName("is_read")
    public boolean is_read;
}
