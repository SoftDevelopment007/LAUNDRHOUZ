package modules.room_db.dao;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.google.gson.annotations.SerializedName;

import modules.http.ResponseData;

@Entity(tableName = "cart_details")
public class CartDetails extends ResponseData {

    @PrimaryKey(autoGenerate = true)
    public int id;

    @SerializedName("category_id")
    public String category_id;

    @SerializedName("sub_category_id")
    public String sub_category_id;

    @SerializedName("product_id")
    public String product_id;

    @SerializedName("product_name")
    public String product_name;

    @SerializedName("product_image")
    public String product_image;

    @SerializedName("quantity")
    public int quantity;

    @SerializedName("original_price")
    public double original_price;

    @SerializedName("discount_price")
    public double discount_price;

    @SerializedName("short_discription")
    public String short_discription;


    @Ignore
    public boolean isEdit = false;

    public CartDetails() {
    }


}
