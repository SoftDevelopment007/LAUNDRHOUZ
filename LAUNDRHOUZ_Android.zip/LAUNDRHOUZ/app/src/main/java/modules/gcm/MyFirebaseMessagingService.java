package modules.gcm;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.laundrhouz.android.R;
import com.laundrhouz.android.activities.CheckLocationActivity;
import com.laundrhouz.android.activities.CollectionDateStatusActivity;
import com.laundrhouz.android.activities.HomeActivity;
import com.laundrhouz.android.activities.OTPVerifyActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

import modules.base.ApplicationPrefs;
import modules.base.LogUtil;
import modules.bean.MasterOrderDetails;
import modules.room_db.AppDatabase;
import modules.room_db.dao.NotificationDetails;


public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = "MyFirebaseMsgService";
    boolean noti = true;


    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {

        if (remoteMessage.getData().size() > 0) {
            Log.d(TAG, "Message data payload: " + remoteMessage.getData());
            processToNotificationScreen(remoteMessage.getData());
        }
        if (remoteMessage.getNotification() != null) {
            Log.d(TAG, "Message Notification Body: " + remoteMessage.getNotification().getBody());
        }
    }


    public final static String KEY_NOTIFICATION_TYPE = "notification_type";
    public final static String KEY_DATE = "date";
    public final static String KEY_TITLE = "title";
    public final static String KEY_MESSAGE = "message";
    public final static String KEY_IMAGE = "image";
    public final static String KEY_USER_NAME = "user_name";

    public final static String KEY_TYPE_NEWS_POST = "NewsPost_Request";
    public final static String KEY_TYPE_ORDER_STATUS = "order_status";
    public final static String KEY_CATEGORY_ID = "cat_id";
    public final static String KEY_ORDER_DETAIL = "order_detail";


    private void processToNotificationScreen(Map<String, String> data) {
        ApplicationPrefs prefs = ApplicationPrefs.getInstance(getApplicationContext());

        LogUtil.debug("Notification Type==>" + data.get(KEY_NOTIFICATION_TYPE));
        String notification_type = data.get(KEY_NOTIFICATION_TYPE);
        Intent intent = new Intent();
        intent.putExtra("openFrom", "notification");
        AppDatabase appDatabase = AppDatabase.getAppDatabase(getApplicationContext());

        NotificationDetails notificationListDetails = new NotificationDetails();
        notificationListDetails.notification_type = data.get(KEY_NOTIFICATION_TYPE);
        notificationListDetails.title = data.get(KEY_TITLE);
        notificationListDetails.message = data.get(KEY_MESSAGE);
        notificationListDetails.notifaiction_date = dateFormator(data.get(KEY_DATE));
        notificationListDetails.is_read = false;

        if (prefs.isLogin()) {
            appDatabase.notificationDao().insert(notificationListDetails);
        }

        if (notification_type != null) {
            switch (notification_type) {
                case KEY_TYPE_ORDER_STATUS:


                    if (prefs.isLogin()) {
                        if (prefs.getIsVerify().equalsIgnoreCase("1")) {
                            MasterOrderDetails masterOrderDetails = new MasterOrderDetails();
                            JSONObject jsonObj = null;
                            try {
                                jsonObj = new JSONObject(data.get(KEY_ORDER_DETAIL));
                                masterOrderDetails.cust_id = jsonObj.getString("cust_id");
                                masterOrderDetails.address_id = jsonObj.getString("address_id");
                                masterOrderDetails.promocode_amount = jsonObj.getString("promocode_amount");
                                masterOrderDetails.subtotal_amount = jsonObj.getString("subtotal_amount");
                                masterOrderDetails.final_subtotal = jsonObj.getString("final_subtotal");
                                masterOrderDetails.payment_status = jsonObj.getString("payment_status");
                                masterOrderDetails.payment_id = jsonObj.getString("payment_id");
                                masterOrderDetails.pickup_charge = jsonObj.getString("pickup_charge");
                                masterOrderDetails.pickup_time = jsonObj.getString("pickup_time");
                                masterOrderDetails.pickup_date = jsonObj.getString("pickup_date");
                                masterOrderDetails.item_qty = jsonObj.getString("item_qty");
                                masterOrderDetails.total_amount = jsonObj.getString("total_amount");
                                masterOrderDetails.instruction = jsonObj.getString("instruction");
                                masterOrderDetails.deliver_date = jsonObj.getString("deliver_date");
                                masterOrderDetails.is_active = jsonObj.getString("is_active");
                                masterOrderDetails.created_dt = jsonObj.getString("created_dt");
                                masterOrderDetails.is_delete = jsonObj.getString("is_delete");
                                masterOrderDetails.order_date = jsonObj.getString("order_date");
                                masterOrderDetails.modified_dt = jsonObj.getString("modified_dt");
                                masterOrderDetails.order_id = jsonObj.getString("order_id");
                                masterOrderDetails.master_order_id = jsonObj.getString("master_order_id");
                                masterOrderDetails.master_order_status = jsonObj.getString("master_order_status");

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            intent.putExtra("fromNotification", "fromNotification");
                            intent.putExtra("message", KEY_MESSAGE);
                            intent.putExtra("masterOrderDetailsNoti", masterOrderDetails);
                            intent.setClass(getApplicationContext(), CollectionDateStatusActivity.class);
                        } else {
                            intent.setClass(getApplicationContext(), OTPVerifyActivity.class);
                        }
                    } else if (prefs.getPostCode() != null && !prefs.getPostCode().equalsIgnoreCase("")) {
                        intent.setClass(getApplicationContext(), HomeActivity.class);
                    } else {
                        intent.setClass(getApplicationContext(), CheckLocationActivity.class);
                    }
                    break;

                default:
                    if (prefs.isLogin()) {
                        if (prefs.getIsVerify().equalsIgnoreCase("1")) {
                            intent.setClass(getApplicationContext(), HomeActivity.class);
                        } else {
                            intent.setClass(getApplicationContext(), OTPVerifyActivity.class);
                        }
                    } else if (prefs.getPostCode() != null && !prefs.getPostCode().equalsIgnoreCase("")) {
                        intent.setClass(getApplicationContext(), HomeActivity.class);
                    } else {
                        intent.setClass(getApplicationContext(), CheckLocationActivity.class);
                    }
                   /* Class className;

                    className = HomeActivity.class;

                    intent.setClass(getApplicationContext(), className);*/
                    break;
            }

            if (intent == null) return;
            intent.putExtra("notification_id", new Random().nextInt());
            LogUtil.debug("KEY_IMAGEEEEE=====>>>>" + data.get(KEY_IMAGE));
            if (hashData(data.get(KEY_IMAGE))) {
                new GenerateNotificationWithImage(getApplicationContext(), data, intent).execute();
            } else {
                processToSendNormalNotification(intent, data);
            }
        }

    }

    private void processToSendNormalNotification(Intent intent, Map<String, String> data) {

        MyFirebaseMessagingService.createAChannelAndConfigureSound(getApplicationContext());
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0 /* Request code */, intent,
                PendingIntent.FLAG_ONE_SHOT);

        NotificationCompat.Builder notificationBuilder = getNotificationBuilder(getApplicationContext(), data);
        notificationBuilder.setContentTitle(data.get(KEY_USER_NAME))
                .setContentText(data.get(KEY_MESSAGE))
                .setContentIntent(pendingIntent);

        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        int notificationId = new Random().nextInt();
        notificationManager.notify(notificationId, notificationBuilder.build());
    }

    private boolean hashData(String data) {
        return data != null && data.trim().length() > 0;
    }


    @Override
    public void onNewToken(String token) {
        Log.d(TAG, "Refreshed token: " + token);
        ApplicationPrefs prefss = ApplicationPrefs.getInstance(getApplicationContext());
        prefss.setGcmToken(token);
    }


    protected static void createAChannelAndConfigureSound(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (notificationManager == null) return;


            AudioAttributes attributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build();

            String channelId = context.getString(R.string.default_notification_channel_id);
            NotificationChannel channel = new NotificationChannel(channelId,
                    context.getString(R.string.app_name),
                    NotificationManager.IMPORTANCE_HIGH);

            channel.enableLights(true);
            channel.enableVibration(true);
            channel.setSound(Settings.System.DEFAULT_NOTIFICATION_URI, attributes);
            notificationManager.createNotificationChannel(channel);

        }
    }

    public static NotificationCompat.Builder getNotificationBuilder(Context mContext, Map<String, String> data) {

        return new NotificationCompat.Builder(mContext, mContext.getString(R.string.default_notification_channel_id))
                .setContentTitle(data.get(KEY_MESSAGE))
                .setContentText(data.get(KEY_USER_NAME))
                .setSmallIcon(R.drawable.splash_logo)
                .setAutoCancel(true)
                .setVibrate(new long[]{100, 500, 500, 500})
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setSound(Settings.System.DEFAULT_NOTIFICATION_URI, AudioManager.STREAM_NOTIFICATION)
                ;
    }

    private String dateFormator(String dateString) {
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
        Date date = null;
        try {
            date = formatter.parse(dateString);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        SimpleDateFormat newFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        return newFormat.format(date);
    }

}
