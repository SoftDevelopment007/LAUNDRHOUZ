package modules.gcm;

import android.annotation.TargetApi;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Build;
import androidx.core.app.NotificationCompat;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import java.util.Random;

import modules.base.LogUtil;


public class GenerateNotificationWithImage extends AsyncTask<String, Void, Bitmap> {

    private static final String TAG = "MyFirebaseMsgServiceSync";

    private Context mContext;
    private Intent intent;
    Map<String, String> data;
    private String imageUrl;

    GenerateNotificationWithImage(Context context, Map<String, String> data, Intent intent) {
        super();
        LogUtil.debug(TAG + " GenerateNotificationWithImage ");

        this.mContext = context;
        this.data = data;
        this.intent = intent;
        if (data.get(MyFirebaseMessagingService.KEY_IMAGE).contains("http")) {
            this.imageUrl = data.get(MyFirebaseMessagingService.KEY_IMAGE);
        } else {
//            this.imageUrl = ServerHelper.IMAGE_PATH + data.get(MyFirebaseMessagingService.KEY_USER_IMAGE);
        }
    }

    @Override
    protected Bitmap doInBackground(String... params) {
        LogUtil.debug(TAG + " back");
        InputStream in;
        try {
            URL url = new URL(this.imageUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            in = connection.getInputStream();
            return BitmapFactory.decodeStream(in);
        } catch (IOException e) {
            LogUtil.debug(TAG + " error " + e.getLocalizedMessage());
            e.printStackTrace();
        }
        return null;
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onPostExecute(Bitmap result) {
        super.onPostExecute(result);
        LogUtil.debug(TAG + " onPostExecute ");

        MyFirebaseMessagingService.createAChannelAndConfigureSound(mContext);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pendingIntent = PendingIntent.getActivity(mContext, 0 /* Request code */, intent,
                PendingIntent.FLAG_ONE_SHOT);

        NotificationCompat.Builder notificationBuilder = MyFirebaseMessagingService.getNotificationBuilder(mContext, data);
        notificationBuilder
                .setLargeIcon(result)
                .setContentIntent(pendingIntent);

        NotificationManager notificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
        int notificationId = new Random().nextInt();
        notificationManager.notify(notificationId, notificationBuilder.build());
    }
}
