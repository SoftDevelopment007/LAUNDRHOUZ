package modules.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.laundrhouz.android.R;

import java.text.DecimalFormat;
import java.util.List;

import modules.bean.ItemDetails;
import modules.blu.ServerHelper;
import modules.room_db.AppDatabase;
import modules.room_db.dao.CartDetails;

public class SpecialOfferAdapter extends RecyclerView.Adapter<SpecialOfferAdapter.ViewHolder> {

    Context context;
    private List<ItemDetails> itemDetailsList;
    private AppDatabase appDatabase;
    private String product_image;

    public SpecialOfferAdapter(Context context, List<ItemDetails> itemDetailsList, String product_image) {
        this.context = context;
        this.itemDetailsList = itemDetailsList;
        this.product_image = product_image;
        appDatabase = AppDatabase.getAppDatabase(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_shirts, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int i) {
        ItemDetails itemDetails = itemDetailsList.get(holder.getAdapterPosition());
        holder.textViewItemName.setText(itemDetails.item_name);
        holder.textViewDescription.setText(itemDetails.short_desc);

        holder.textViewOriginalPrice.setText("$" + new DecimalFormat("#.##").format(itemDetails.item_originalprice));

        if (itemDetails.item_discprice > 0) {
            holder.textViewPrice.setText("$" + new DecimalFormat("#.##").format(itemDetails.item_discprice));
            holder.textViewOriginalPrice.setVisibility(View.VISIBLE);
            holder.textViewSlashSymbol.setVisibility(View.VISIBLE);
        } else {
            holder.textViewPrice.setText("$" + new DecimalFormat("#.##").format(itemDetails.item_originalprice));
            holder.textViewOriginalPrice.setVisibility(View.GONE);
            holder.textViewSlashSymbol.setVisibility(View.GONE);
        }

        if (appDatabase.cartDetailsDao().isExist(itemDetails.item_id)) {
            holder.textViewQuantity.setText("" + appDatabase.cartDetailsDao().getQuantity(itemDetails.item_id));
        } else {
            holder.textViewQuantity.setText(String.valueOf(itemDetails.quantity));
        }
    }

    @Override
    public int getItemCount() {
        return itemDetailsList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        TextView textViewItemName, textViewDescription, textViewPrice, textViewQuantity;
        TextView textViewAdd, textViewDelete, textViewOriginalPrice, textViewSlashSymbol;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewItemName = itemView.findViewById(R.id.textViewItemName);
            textViewDescription = itemView.findViewById(R.id.textViewDescription);
            textViewPrice = itemView.findViewById(R.id.textViewPrice);
            textViewQuantity = itemView.findViewById(R.id.textViewQuantity);
            textViewAdd = itemView.findViewById(R.id.textViewAdd);
            textViewDelete = itemView.findViewById(R.id.textViewDelete);
            textViewOriginalPrice = itemView.findViewById(R.id.textViewOriginalPrice);
            textViewSlashSymbol = itemView.findViewById(R.id.textViewSlashSymbol);

            textViewAdd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int sqty = Integer.parseInt(textViewQuantity.getText().toString());
                    sqty++;
                    textViewQuantity.setText(String.valueOf(sqty));

                    if (appDatabase.cartDetailsDao().isExist(itemDetailsList.get(getAdapterPosition()).item_id)) {
                        appDatabase.cartDetailsDao().update(sqty, itemDetailsList.get(getAdapterPosition()).item_id);
                    } else {

                        CartDetails cartDetails = new CartDetails();
                        cartDetails.product_id = itemDetailsList.get(getAdapterPosition()).item_id;
                        cartDetails.category_id = itemDetailsList.get(getAdapterPosition()).cat_id;
                        cartDetails.sub_category_id = itemDetailsList.get(getAdapterPosition()).subcat_id;
                        cartDetails.product_name = itemDetailsList.get(getAdapterPosition()).item_name;
                        cartDetails.product_image = ServerHelper.IMAGE_PATH + product_image;
                        cartDetails.original_price = itemDetailsList.get(getAdapterPosition()).item_originalprice;

                        if (itemDetailsList.get(getAdapterPosition()).item_discprice == 0) {
                            cartDetails.discount_price = itemDetailsList.get(getAdapterPosition()).item_originalprice;
                        } else {
                            cartDetails.discount_price = itemDetailsList.get(getAdapterPosition()).item_discprice;
                        }
//                        cartDetails.discount_price = itemDetailsList.get(getAdapterPosition()).item_discprice;
                        cartDetails.quantity = sqty;
                        cartDetails.short_discription = itemDetailsList.get(getAdapterPosition()).short_desc;
                        appDatabase.cartDetailsDao().insert(cartDetails);
                    }
                }
            });

            textViewDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int sqty = Integer.parseInt(textViewQuantity.getText().toString());
                    if (sqty > 0) {
                        sqty--;
                        textViewQuantity.setText(String.valueOf(sqty));
                        if (sqty == 0) {
                            appDatabase.cartDetailsDao().delete(itemDetailsList.get(getAdapterPosition()).item_id);

                        } else {
                            if (appDatabase.cartDetailsDao().isExist(itemDetailsList.get(getAdapterPosition()).item_id)) {
                                appDatabase.cartDetailsDao().update(sqty, itemDetailsList.get(getAdapterPosition()).item_id);
                            }
                        }
                    }
                }
            });

        }
    }
}
