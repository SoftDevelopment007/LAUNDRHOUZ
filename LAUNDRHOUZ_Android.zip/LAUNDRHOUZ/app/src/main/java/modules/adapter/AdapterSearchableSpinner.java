package modules.adapter;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.laundrhouz.android.R;

import java.util.ArrayList;
import java.util.List;

public class AdapterSearchableSpinner<T> extends RecyclerView.Adapter<AdapterSearchableSpinner.ViewHolder> implements Filterable {
    private List<T> list;
    private List<T> filteredList;
    private FilterSelectionInterface onClick;

    public void setOnClick(FilterSelectionInterface onClick) {
        this.onClick = onClick;
    }

    public AdapterSearchableSpinner(List<T> list) {
        this.list = list;
        this.filteredList = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_dialog_design, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterSearchableSpinner.ViewHolder holder, int position) {
        holder.textViewList.setText(filteredList.get(position).toString());
    }

    @Override
    public int getItemCount() {
        return filteredList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewList;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewList = itemView.findViewById(R.id.textViewList);
            textViewList.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (onClick != null) {
                        onClick.onSelected(filteredList.get(getAdapterPosition()));
                    }
                }
            });
        }
    }


    public interface FilterSelectionInterface<T> {
        void onSelected(T item);
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                List<T> filteredList = new ArrayList<>();
                if (charString.isEmpty()) {
                    filteredList = list;
                } else {

                    for (T row : list) {
                        if (row.toString().toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(row);
                        }
                    }
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = filteredList;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                filteredList = (List<T>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }
}
