package modules.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import com.laundrhouz.android.R;

import java.util.List;

import modules.bean.FaqListDetails;

public class FaqListAdapter extends BaseExpandableListAdapter {
    private List<FaqListDetails> faqList;
    private LayoutInflater inflater;
    private TextView textViewAnswer;


    public FaqListAdapter(Context context, List<FaqListDetails> faqList) {
        this.faqList = faqList;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getGroupCount() {
        return faqList.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return 1;
    }

    @Override
    public Object getGroup(int groupPosition) {
        return faqList.get(groupPosition).question;
    }

    @Override
    public Object getChild(int groupPosition, int childPosititon) {
        return faqList.get(groupPosition).description;
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosititon) {
        return childPosititon;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View view, ViewGroup viewGroup) {
        String headerText = getGroup(groupPosition).toString();
        if (view == null) {
            view = inflater.inflate(R.layout.item_faq_question, viewGroup, false);
        }
        TextView textViewQuestion = view.findViewById(R.id.textViewQuestion);
        textViewAnswer = view.findViewById(R.id.textViewAnswer);
        if (isExpanded) {
            textViewQuestion.setCompoundDrawablesWithIntrinsicBounds(R.drawable.faq_down, 0, 0, 0);
            textViewAnswer.setVisibility(View.VISIBLE);
        } else {
            textViewQuestion.setCompoundDrawablesWithIntrinsicBounds(R.drawable.faq_right, 0, 0, 0);
            textViewAnswer.setVisibility(View.GONE);
        }
        textViewQuestion.setText(headerText);
        return view;
    }

    @Override
    public View getChildView(int groupPosition, int childPosititon, boolean b, View view, ViewGroup viewGroup) {
        String childText = getChild(groupPosition, childPosititon).toString();
        if (view == null) {
            view = inflater.inflate(R.layout.item_faq_answer, viewGroup, false);
        }
        textViewAnswer.setText(childText);
        return view;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosititon) {
        return true;
    }


}
