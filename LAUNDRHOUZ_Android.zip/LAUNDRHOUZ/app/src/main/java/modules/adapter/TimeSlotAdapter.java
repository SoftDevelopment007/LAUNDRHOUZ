package modules.adapter;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.laundrhouz.android.R;

import java.util.List;

import modules.bean.TimeSlotDetails;

public class TimeSlotAdapter extends RecyclerView.Adapter<TimeSlotAdapter.ViewHolder> {

    private int lastCheckedPosition = -1;
    Context context;
    private List<TimeSlotDetails> timeSlotDetailsList;
    private ItemClick itemClick;


    public void setiItemClick(ItemClick itemClick) {
        this.itemClick = itemClick;
    }

    public TimeSlotAdapter(Context context, List<TimeSlotDetails> timeSlotDetailsList) {
        this.context = context;
        this.timeSlotDetailsList = timeSlotDetailsList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_time_slot, viewGroup, false);
        context = viewGroup.getContext();
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int i) {
        holder.radioButtonTime.setChecked(i == lastCheckedPosition);
        TimeSlotDetails timeSlotDetails = timeSlotDetailsList.get(holder.getAdapterPosition());

        if (timeSlotDetails.isValid) {
            holder.radioButtonTime.setChecked(true);
        } else {
            holder.radioButtonTime.setChecked(false);
        }
        holder.textViewTime.setText(timeSlotDetails.start_time + " - " + timeSlotDetails.end_time);
    }

    @Override
    public int getItemCount() {
        return timeSlotDetailsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        RadioButton radioButtonTime;
        RelativeLayout relativeLayoutTimeSlot;
        TextView textViewTime;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            radioButtonTime = itemView.findViewById(R.id.radioButtonTime);
            relativeLayoutTimeSlot = itemView.findViewById(R.id.relativeLayoutTimeSlot);
            textViewTime = itemView.findViewById(R.id.textViewTime);

            relativeLayoutTimeSlot.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    lastCheckedPosition = getAdapterPosition();
                    if (itemClick != null) {
                        itemClick.timeSelect(getAdapterPosition());
                    }
//                    notifyDataSetChanged();

                }
            });
            radioButtonTime.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    lastCheckedPosition = getAdapterPosition();
                    if (itemClick != null) {
                        itemClick.timeSelect(getAdapterPosition());
                    }
//                    notifyDataSetChanged();
                }
            });
        }
    }

    public interface ItemClick {
        void timeSelect(int position);
    }
}
