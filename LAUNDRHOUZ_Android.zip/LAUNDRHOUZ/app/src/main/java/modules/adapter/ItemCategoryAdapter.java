package modules.adapter;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.laundrhouz.android.R;

import java.util.List;

import modules.bean.SearchCategoryDetails;

public class ItemCategoryAdapter extends RecyclerView.Adapter<ItemCategoryAdapter.ViewHolder> {

    Context context;
    onClick onClick;
    private List<SearchCategoryDetails> categoryDetailsList;

    public ItemCategoryAdapter(Context context, List<SearchCategoryDetails> categoryDetailsList) {
        this.context = context;
        this.categoryDetailsList = categoryDetailsList;
    }

    public void setOnClick(ItemCategoryAdapter.onClick onClick) {
        this.onClick = onClick;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_category_name, viewGroup, false);
        context = viewGroup.getContext();
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int i) {
        SearchCategoryDetails categoryDetails = categoryDetailsList.get(holder.getAdapterPosition());
        holder.textViewCategoryName.setText(categoryDetails.category);

        SearchItemAdapter searchItemAdapter = new SearchItemAdapter(context, categoryDetails.itemlist,categoryDetails.image);
        holder.recyclerViewSearchItemList.setLayoutManager(new LinearLayoutManager(context));
        holder.recyclerViewSearchItemList.setAdapter(searchItemAdapter);



    }

    @Override
    public int getItemCount() {
        return categoryDetailsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewCategoryName;
        RecyclerView recyclerViewSearchItemList;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewCategoryName = itemView.findViewById(R.id.textViewCategoryName);
            recyclerViewSearchItemList = itemView.findViewById(R.id.recyclerViewSearchItemList);

        }
    }

    public interface onClick {
        void sendHeight(int h);

    }
}
