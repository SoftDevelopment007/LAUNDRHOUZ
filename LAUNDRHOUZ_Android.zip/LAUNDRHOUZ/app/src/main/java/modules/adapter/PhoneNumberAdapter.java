package modules.adapter;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.laundrhouz.android.R;
import com.laundrhouz.android.activities.ChoosePhoneNumberActivity;

import java.util.List;

import modules.bean.PhoneNumberDetails;

public class PhoneNumberAdapter extends RecyclerView.Adapter<PhoneNumberAdapter.ViewHolder> {

    private int lastCheckedPosition = -1;
    Context context;
    private List<PhoneNumberDetails> phoneNumberDetailsList;
    onClick onClick;

    public PhoneNumberAdapter(Context context, List<PhoneNumberDetails> phoneNumberDetailsList) {
        this.context = context;
        this.phoneNumberDetailsList = phoneNumberDetailsList;
    }

    public void setOnClick(onClick onClick) {
        this.onClick = onClick;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_phone_number, viewGroup, false);
        context = viewGroup.getContext();
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int i) {
        holder.radioButtonPhoneNumber.setChecked(i == lastCheckedPosition);
        PhoneNumberDetails phoneNumberDetails = phoneNumberDetailsList.get(holder.getAdapterPosition());
        holder.textViewPhoneNumber.setText(phoneNumberDetails.phone);
        holder.textViewPhoneNumberTitle.setText(phoneNumberDetails.place_type);

        int h = holder.relativeLayoutPhoneNumber.getMeasuredHeight();
        if (onClick != null) {
            onClick.sendHeight(h);
        }
    }

    @Override
    public int getItemCount() {
        return phoneNumberDetailsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        RadioButton radioButtonPhoneNumber;
        RelativeLayout relativeLayoutPhoneNumber;
        TextView textViewPhoneNumber,textViewPhoneNumberTitle;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewPhoneNumberTitle = itemView.findViewById(R.id.textViewPhoneNumberTitle);
            textViewPhoneNumber = itemView.findViewById(R.id.textViewPhoneNumber);
            radioButtonPhoneNumber = itemView.findViewById(R.id.radioButtonPhoneNumber);
            relativeLayoutPhoneNumber = itemView.findViewById(R.id.relativeLayoutPhoneNumber);
            relativeLayoutPhoneNumber.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    lastCheckedPosition = getAdapterPosition();
                    notifyDataSetChanged();
                    ((ChoosePhoneNumberActivity) context).onBackPressed();
                }
            });
            radioButtonPhoneNumber.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    lastCheckedPosition = getAdapterPosition();
                    notifyDataSetChanged();
                    ((ChoosePhoneNumberActivity) context).onBackPressed();
                }
            });
        }
    }

    public interface onClick {
        void sendHeight(int h);

    }

    public void removeItem(int position) {
        phoneNumberDetailsList.remove(position);
        // notify the item removed by position
        // to perform recycler view delete animations
        // NOTE: don't call notifyDataSetChanged()
        notifyItemRemoved(position);
    }
}
