package modules.adapter;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.laundrhouz.android.R;

import java.util.List;

import modules.room_db.dao.CartDetails;

public class OrderItemsAdapter extends RecyclerView.Adapter<OrderItemsAdapter.ViewHolder> {
    private List<CartDetails> cartDetailsList;
    Context context;

    public OrderItemsAdapter(Context context, List<CartDetails> cartDetailsList) {
        this.context = context;
        this.cartDetailsList = cartDetailsList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_order_items, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int i) {
        CartDetails cartDetails = cartDetailsList.get(holder.getAdapterPosition());
        holder.textViewQuantity.setText(cartDetails.quantity + "x");
        holder.textViewName.setText(cartDetails.product_name);
        holder.textViewPrice.setText("$" + cartDetails.quantity * cartDetails.discount_price);
    }

    @Override
    public int getItemCount() {
        return cartDetailsList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewQuantity, textViewName, textViewPrice;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewQuantity = itemView.findViewById(R.id.textViewQuantity);
            textViewName = itemView.findViewById(R.id.textViewName);
            textViewPrice = itemView.findViewById(R.id.textViewPrice);
        }
    }

    public int getTotalItem() {
        int count = 0;
        for (int i = 0; i < cartDetailsList.size(); i++) {
            count = count + cartDetailsList.get(i).quantity;
        }
        return count;
    }

    public double getTotalAmount() {
        double count = 0;
        for (int i = 0; i < cartDetailsList.size(); i++) {
            count = count + (cartDetailsList.get(i).quantity * cartDetailsList.get(i).discount_price);
        }
        return count;
    }
}
