package modules.adapter;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.laundrhouz.android.R;

import java.util.List;

import modules.base.ApplicationPrefs;
import modules.bean.PaymentMethodDetails;

public class CardAdapter extends RecyclerView.Adapter<CardAdapter.ViewHolder> {

    private int lastCheckedPosition = -1;
    Context context;
    private List<PaymentMethodDetails> paymentMethodDetailsList;
    private ApplicationPrefs prefs;
    ItemSelect itemSelect;

    public void setItemSelect(ItemSelect itemSelect) {
        this.itemSelect = itemSelect;
    }

    public CardAdapter(Context context, List<PaymentMethodDetails> paymentMethodDetailsList) {
        this.context = context;
        this.paymentMethodDetailsList = paymentMethodDetailsList;
        prefs = ApplicationPrefs.getInstance(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_card, viewGroup, false);
        context = viewGroup.getContext();
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int i) {
        holder.radioButtonCard.setChecked(i == lastCheckedPosition);
        PaymentMethodDetails paymentMethodDetails = paymentMethodDetailsList.get(holder.getAdapterPosition());

        /*if (prefs.getDefaultPaymentId().trim().equalsIgnoreCase(paymentMethodDetails.id)) {
            holder.radioButtonCard.setChecked(true);
            paymentMethodDetails.isChecked = true;
        } else {
            holder.radioButtonCard.setChecked(false);
            paymentMethodDetails.isChecked = false;
        }*/

        holder.textCardTitle.setText(paymentMethodDetails.payment_method);
        holder.textViewCardId.setText(paymentMethodDetails.payment_uniqid);
    }

    @Override
    public int getItemCount() {
        return paymentMethodDetailsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        RadioButton radioButtonCard;
        RelativeLayout relativeLayoutCard;
        TextView textCardTitle, textViewCardId;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textCardTitle = itemView.findViewById(R.id.textCardTitle);
            textViewCardId = itemView.findViewById(R.id.textViewCardId);

            radioButtonCard = itemView.findViewById(R.id.radioButtonCard);
            relativeLayoutCard = itemView.findViewById(R.id.relativeLayoutCard);
            relativeLayoutCard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    lastCheckedPosition = getAdapterPosition();
//                    prefs.setDefaultPaymentId(paymentMethodDetailsList.get(getAdapterPosition()).id);
                    if (itemSelect != null) {
                        itemSelect.onSelect(getAdapterPosition());
                    }
                    notifyDataSetChanged();
                }
            });
            radioButtonCard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    lastCheckedPosition = getAdapterPosition();
//                    prefs.setDefaultPaymentId(paymentMethodDetailsList.get(getAdapterPosition()).id);
                    if (itemSelect != null) {
                        itemSelect.onSelect(getAdapterPosition());
                    }
                    notifyDataSetChanged();

                }
            });
        }
    }

    public interface ItemSelect {

        void onSelect(int position);

    }
}
