package modules.adapter;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import com.laundrhouz.android.R;

import java.util.List;

import modules.base.ApplicationPrefs;
import modules.bean.AddressDetails;

public class DeliveryMethodAdapter extends RecyclerView.Adapter<DeliveryMethodAdapter.ViewHolder> {
    Context context;
    private List<AddressDetails> addressDetailsList;
    ApplicationPrefs prefs;

    public DeliveryMethodAdapter(Context context, List<AddressDetails> addressDetailsList) {
        this.context = context;
        this.addressDetailsList = addressDetailsList;
        prefs = ApplicationPrefs.getInstance(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_delivery_method, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int i) {
        AddressDetails addressDetails = addressDetailsList.get(holder.getAdapterPosition());
        holder.textViewAddressTitle.setText(addressDetails.add_type);
        holder.textViewAddress.setText(addressDetails.address
                + "\n" + addressDetails.city + "," + addressDetails.country + "," + addressDetails.post_code);

        if (prefs.getDefaultAddressId().trim().equalsIgnoreCase(addressDetails.add_id)) {
            holder.checkBoxDeliveryMethod.setChecked(true);
            addressDetails.isChecked = true;
        } else {
            holder.checkBoxDeliveryMethod.setChecked(false);
            addressDetails.isChecked = false;
        }

    }

    @Override
    public int getItemCount() {
        return addressDetailsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewAddressTitle, textViewAddress;
        CheckBox checkBoxDeliveryMethod;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewAddressTitle = itemView.findViewById(R.id.textViewAddressTitle);
            textViewAddress = itemView.findViewById(R.id.textViewAddress);
            checkBoxDeliveryMethod = itemView.findViewById(R.id.checkBoxDeliveryMethod);

            checkBoxDeliveryMethod.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    prefs.setDefaultAddressId(addressDetailsList.get(getAdapterPosition()).add_id);
                    notifyDataSetChanged();
                }
            });
        }
    }
}
