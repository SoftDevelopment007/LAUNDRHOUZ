package modules.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.laundrhouz.android.R;
import com.laundrhouz.android.activities.ItemDetailActivity;

import java.util.List;

import modules.bean.SubcategoryDetails;
import modules.blu.ServerHelper;

public class ItemsAdapter extends RecyclerView.Adapter<ItemsAdapter.ViewHolder> {

    Context context;
    List<SubcategoryDetails> subcategoryDetailsList;

    public ItemsAdapter(Context context, List<SubcategoryDetails> subcategoryDetailsList) {
        this.context = context;
        this.subcategoryDetailsList = subcategoryDetailsList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_items, viewGroup, false);
        context = viewGroup.getContext();
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int i) {
        SubcategoryDetails subcategoryDetails = subcategoryDetailsList.get(holder.getAdapterPosition());
        holder.textViewItemName.setText(subcategoryDetails.name);
        holder.textViewItemPrice.setText("From $"+subcategoryDetails.minvalue);

        holder.imageViewLoadingIcon.setVisibility(View.VISIBLE);
        Glide.with(context)
                .load(ServerHelper.IMAGE_PATH + subcategoryDetails.image)
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        holder.imageViewLoadingIcon.setVisibility(View.GONE);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        holder.imageViewLoadingIcon.setVisibility(View.GONE);
                        return false;
                    }
                })
                .apply(new RequestOptions().error(R.drawable.no_image_found))
                .into(holder.imageViewItem);

    }

    @Override
    public int getItemCount() {
        return subcategoryDetailsList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewItemName, textViewItemPrice;
        ImageView imageViewItem, imageViewLoadingIcon;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewItemName = itemView.findViewById(R.id.textViewItemName);
            textViewItemPrice = itemView.findViewById(R.id.textViewItemPrice);
            imageViewItem = itemView.findViewById(R.id.imageViewItem);
            imageViewLoadingIcon = itemView.findViewById(R.id.imageViewLoadingIcon);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(context, ItemDetailActivity.class);
                    intent.putExtra("subCategoryDetails", subcategoryDetailsList.get(getAdapterPosition()));
                    context.startActivity(intent);
                }
            });
        }
    }
}
