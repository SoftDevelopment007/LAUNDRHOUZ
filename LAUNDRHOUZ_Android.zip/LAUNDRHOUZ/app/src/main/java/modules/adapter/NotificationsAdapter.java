package modules.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.laundrhouz.android.R;

import java.util.List;

import modules.room_db.dao.NotificationDetails;

public class NotificationsAdapter extends RecyclerView.Adapter<NotificationsAdapter.ViewHolder> {
    Context context;
    List<NotificationDetails> notificationDetailsList;

    public NotificationsAdapter(Context context, List<NotificationDetails> notificationDetailsList) {
        this.context = context;
        this.notificationDetailsList = notificationDetailsList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_notifications, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int i) {
        NotificationDetails notificationDetails = notificationDetailsList.get(holder.getAdapterPosition());
        holder.textViewNotiTitle.setText(notificationDetails.title);
        holder.textViewNotiMessage.setText(notificationDetails.message);

    }

    @Override
    public int getItemCount() {
        return notificationDetailsList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewNotiTitle, textViewNotiMessage;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewNotiTitle = itemView.findViewById(R.id.textViewNotiTitle);
            textViewNotiMessage = itemView.findViewById(R.id.textViewNotiMessage);
        }
    }
}
