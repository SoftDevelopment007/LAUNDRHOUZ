package modules.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.laundrhouz.android.R;

import java.util.List;

import modules.bean.PlanDetails;

public class LaundryPlanAdapter extends RecyclerView.Adapter<LaundryPlanAdapter.ViewHolder> {

    List<PlanDetails> stringList;
    private int lastCheckedPosition = -1;
    Context context;
    Click click;

    public LaundryPlanAdapter(List<PlanDetails> stringList,Click click) {
        this.stringList = stringList;
        this.click = click;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_laundry_plan, viewGroup, false);
        context = viewGroup.getContext();
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        PlanDetails planDetails = stringList.get(i);
        String laundryPlan = planDetails.plan_name + " - " + planDetails.weight + "/month-$" + planDetails.amount + ".00";
        viewHolder.textViewLaundryPlan.setText(laundryPlan);
        viewHolder.radioButtonLaundryPlan.setChecked(i == lastCheckedPosition);
    }

    @Override
    public int getItemCount() {
        return stringList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        RadioButton radioButtonLaundryPlan;
        RelativeLayout relativeLayoutLaundryPlan;
        TextView textViewLaundryPlan;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewLaundryPlan = itemView.findViewById(R.id.textViewLaundryPlan);
            radioButtonLaundryPlan = itemView.findViewById(R.id.radioButtonLaundryPlan);
            relativeLayoutLaundryPlan = itemView.findViewById(R.id.relativeLayoutLaundryPlan);
            relativeLayoutLaundryPlan.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    lastCheckedPosition = getAdapterPosition();
                    if (click!=null) {
                        click.onClick(stringList.get(getAdapterPosition()));
                    }
                    notifyDataSetChanged();
                }
            });
        }
    }

    public interface Click{
        void onClick(PlanDetails planDetails);
    }
}
