package modules.adapter;

import android.content.Context;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.laundrhouz.android.R;
import com.laundrhouz.android.activities.HomeActivity;

import java.util.List;

import modules.base.ApplicationPrefs;
import modules.bean.AddressDetails;

public class AddressAdapter extends RecyclerView.Adapter<AddressAdapter.ViewHolder> {

    private int lastCheckedPosition = -1;
    Context context;
    onClick onClick;
    private List<AddressDetails> addressDetailsList;
    public ApplicationPrefs prefs;

    public AddressAdapter(Context context, List<AddressDetails> addressDetailsList) {
        this.context = context;
        this.addressDetailsList = addressDetailsList;
        prefs = ApplicationPrefs.getInstance(context);
    }

    public void setOnClick(AddressAdapter.onClick onClick) {
        this.onClick = onClick;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_address, viewGroup, false);
        context = viewGroup.getContext();
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int i) {
        holder.radioButtonAddress.setChecked(i == lastCheckedPosition);
        AddressDetails addressDetails = addressDetailsList.get(holder.getAdapterPosition());

        holder.textViewAddressTitle.setText(addressDetails.add_type);
        holder.textViewAddress.setText(addressDetails.address
                + "\n" + addressDetails.city + "," + addressDetails.country + "," + addressDetails.post_code);

        if (prefs.getDefaultAddressId().trim().equalsIgnoreCase(addressDetails.add_id.trim())) {
            holder.radioButtonAddress.setChecked(true);
        } else {
            holder.radioButtonAddress.setChecked(false);
        }

        int h = holder.relativeLayoutAddress.getMeasuredHeight();
        if (onClick != null) {
            onClick.sendHeight(h);
        }
    }

    @Override
    public int getItemCount() {
        return addressDetailsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        RadioButton radioButtonAddress;
        RelativeLayout relativeLayoutAddress;
        TextView textViewAddressTitle, textViewAddress;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewAddressTitle = itemView.findViewById(R.id.textViewAddressTitle);
            textViewAddress = itemView.findViewById(R.id.textViewAddress);

            radioButtonAddress = itemView.findViewById(R.id.radioButtonAddress);
            relativeLayoutAddress = itemView.findViewById(R.id.relativeLayoutAddress);
            relativeLayoutAddress.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    lastCheckedPosition = getAdapterPosition();
                    prefs.setDefaultAddressId(addressDetailsList.get(getAdapterPosition()).add_id);
                    notifyDataSetChanged();
                    Intent intent = new Intent(context, HomeActivity.class);
                    context.startActivity(intent);
                }
            });
            radioButtonAddress.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    lastCheckedPosition = getAdapterPosition();
                    prefs.setDefaultAddressId(addressDetailsList.get(getAdapterPosition()).add_id);
                    notifyDataSetChanged();
                    Intent intent = new Intent(context, HomeActivity.class);
                    context.startActivity(intent);
                }
            });
        }
    }

    public interface onClick {
        void sendHeight(int h);

    }
}
