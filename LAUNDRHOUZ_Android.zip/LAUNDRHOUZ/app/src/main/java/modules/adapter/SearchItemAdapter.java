package modules.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.laundrhouz.android.R;

import java.text.DecimalFormat;
import java.util.List;

import modules.bean.ItemDetails;
import modules.blu.ServerHelper;
import modules.room_db.AppDatabase;
import modules.room_db.dao.CartDetails;

public class SearchItemAdapter extends RecyclerView.Adapter<SearchItemAdapter.ViewHolder> {

    Context context;
    private List<ItemDetails> itemDetailsList;
    private AppDatabase appDatabase;
    private String image;

    SearchItemAdapter(Context context, List<ItemDetails> itemDetailsList, String image) {
        this.context = context;
        this.itemDetailsList = itemDetailsList;
        this.image = image;
        appDatabase = AppDatabase.getAppDatabase(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_search_product, viewGroup, false);
        context = viewGroup.getContext();
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int i) {
        ItemDetails itemDetails = itemDetailsList.get(holder.getAdapterPosition());

        if (appDatabase.cartDetailsDao().isExist(itemDetails.item_id)) {
            int quantity = appDatabase.cartDetailsDao().getQuantity(itemDetails.item_id);
            holder.textViewSearchQuantity.setVisibility(View.VISIBLE);
            holder.textViewXSymbol.setVisibility(View.VISIBLE);
            holder.textViewSearchQuantity.setText(String.valueOf(quantity));
        } else {
            holder.textViewXSymbol.setVisibility(View.GONE);
            holder.textViewSearchQuantity.setVisibility(View.GONE);
            holder.textViewSearchQuantity.setText(String.valueOf(itemDetails.quantity));
        }

        holder.textViewItemName.setText(itemDetails.item_name);
        holder.textViewDescription.setText(itemDetails.short_desc);

        if (itemDetails.item_discprice > 0) {
            holder.textViewItemPrice.setText("$" + new DecimalFormat("#.##").format(itemDetails.item_discprice));
        } else {
            holder.textViewItemPrice.setText("$" + new DecimalFormat("#.##").format(itemDetails.item_originalprice));
        }


        holder.imageViewLoadingIcon.setVisibility(View.VISIBLE);
        Glide.with(context)
                .load(ServerHelper.IMAGE_PATH + itemDetails.image)
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        holder.imageViewLoadingIcon.setVisibility(View.GONE);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        holder.imageViewLoadingIcon.setVisibility(View.GONE);
                        return false;
                    }
                })
                .apply(new RequestOptions().error(R.drawable.no_image_found))
                .into(holder.imageViewItem);
    }

    @Override
    public int getItemCount() {
        return itemDetailsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewItemName, textViewItemPrice, textViewDescription;
        TextView textViewSearchQuantity, textViewXSymbol;
        ImageView imageViewLoadingIcon, imageViewItem;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewItemName = itemView.findViewById(R.id.textViewItemName);
            textViewItemPrice = itemView.findViewById(R.id.textViewItemPrice);
            textViewDescription = itemView.findViewById(R.id.textViewDescription);
            textViewSearchQuantity = itemView.findViewById(R.id.textViewSearchQuantity);
            textViewXSymbol = itemView.findViewById(R.id.textViewXSymbol);
            imageViewLoadingIcon = itemView.findViewById(R.id.imageViewLoadingIcon);
            imageViewItem = itemView.findViewById(R.id.imageViewItem);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int sqty = Integer.parseInt(textViewSearchQuantity.getText().toString());
                    sqty++;
                    textViewSearchQuantity.setText(String.valueOf(sqty));

                    if (appDatabase.cartDetailsDao().isExist(itemDetailsList.get(getAdapterPosition()).item_id)) {
                        appDatabase.cartDetailsDao().update(sqty, itemDetailsList.get(getAdapterPosition()).item_id);
                    } else {
                        CartDetails cartDetails = new CartDetails();
                        cartDetails.product_id = itemDetailsList.get(getAdapterPosition()).item_id;
                        cartDetails.category_id = itemDetailsList.get(getAdapterPosition()).cat_id;
                        cartDetails.sub_category_id = itemDetailsList.get(getAdapterPosition()).subcat_id;
                        cartDetails.product_name = itemDetailsList.get(getAdapterPosition()).item_name;
                        cartDetails.product_image = ServerHelper.IMAGE_PATH + itemDetailsList.get(getAdapterPosition()).image;
                        cartDetails.original_price = itemDetailsList.get(getAdapterPosition()).item_originalprice;

                        if (itemDetailsList.get(getAdapterPosition()).item_discprice ==0 ) {
                            cartDetails.discount_price = itemDetailsList.get(getAdapterPosition()).item_originalprice;
                        } else {
                            cartDetails.discount_price = itemDetailsList.get(getAdapterPosition()).item_discprice;
                        }
//                        cartDetails.discount_price = itemDetailsList.get(getAdapterPosition()).item_discprice;
                        cartDetails.quantity = sqty;
                        cartDetails.short_discription = itemDetailsList.get(getAdapterPosition()).short_desc;
                        appDatabase.cartDetailsDao().insert(cartDetails);
                    }
                    notifyDataSetChanged();
                }
            });
        }
    }


}
