package modules.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.laundrhouz.android.R;
import com.laundrhouz.android.activities.CollectionDateStatusActivity;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import modules.bean.MasterOrderDetails;

public class MyOrdersAdapter extends RecyclerView.Adapter<MyOrdersAdapter.ViewHolder> {

    private List<String> stringList;
    private List<MasterOrderDetails> masterOrderDetailsList;
    Context context;

    public MyOrdersAdapter(Context context, List<MasterOrderDetails> masterOrderDetailsList, List<String> stringList) {
        this.context = context;
        this.masterOrderDetailsList = masterOrderDetailsList;
        this.stringList = stringList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_my_order, viewGroup, false);
        context = viewGroup.getContext();
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int i) {
//        String status = stringList.get(i);
        MasterOrderDetails masterOrderDetails = masterOrderDetailsList.get(holder.getAdapterPosition());
        holder.textViewQuantity.setText(masterOrderDetails.item_qty + " Quantity");
        holder.textViewTotal.setText("$" + masterOrderDetails.total_amount);
        holder.textViewDateTime.setText(setDeliveryTime(masterOrderDetails.order_date));
        holder.textViewStatus.setText(masterOrderDetails.master_order_status);

        if (masterOrderDetails.master_order_status.equalsIgnoreCase("Pending")) {
            holder.textViewTrackOrder.setVisibility(View.VISIBLE);
        } else {
            holder.textViewTrackOrder.setVisibility(View.GONE);
        }
        if (masterOrderDetails.master_order_status.equalsIgnoreCase("Pending")) {
            holder.textViewStatus.setTextColor(context.getResources().getColor(R.color.textviewoffer));
        } else if (masterOrderDetails.master_order_status.equalsIgnoreCase("Delivered")) {
            holder.textViewStatus.setTextColor(context.getResources().getColor(R.color.light_green));
        } else if (masterOrderDetails.master_order_status.equalsIgnoreCase("Complete")) {
            holder.textViewStatus.setTextColor(context.getResources().getColor(R.color.light_green));
        } else {
            holder.textViewStatus.setTextColor(context.getResources().getColor(R.color.black));
        }
        switch (masterOrderDetails.master_order_status) {
            case "Complete":
                break;
            case "Pending":
                break;
           /* case "Canceled":
                holder.textViewStatus.setTextColor(context.getResources().getColor(R.color.textColor));
                break;*/
        }
    }

    @Override
    public int getItemCount() {
        return masterOrderDetailsList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewDateTime, textViewTotal, textViewQuantity, textViewStatus, textViewTrackOrder;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewDateTime = itemView.findViewById(R.id.textViewDateTime);
            textViewTotal = itemView.findViewById(R.id.textViewTotal);
            textViewQuantity = itemView.findViewById(R.id.textViewQuantity);
            textViewStatus = itemView.findViewById(R.id.textViewStatus);
            textViewTrackOrder = itemView.findViewById(R.id.textViewTrackOrder);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(context, CollectionDateStatusActivity.class);
                    intent.putExtra("masterOrderDetails", masterOrderDetailsList.get(getAdapterPosition()));
                    context.startActivity(intent);
                }
            });
        }
    }

    private String setDeliveryTime(String orderdate) {

        @SuppressLint("SimpleDateFormat") SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date dt1 = null;
        try {
            dt1 = format1.parse(orderdate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        @SuppressLint("SimpleDateFormat") DateFormat format2 = new SimpleDateFormat("dd MMM yyyy, hh:mm a");
        String finalDate = format2.format(dt1);
        return finalDate;
    }
}
