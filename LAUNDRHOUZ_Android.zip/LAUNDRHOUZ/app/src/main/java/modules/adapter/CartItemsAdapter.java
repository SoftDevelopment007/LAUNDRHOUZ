package modules.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.laundrhouz.android.R;

import java.text.DecimalFormat;
import java.util.List;

import modules.room_db.dao.CartDetails;

public class CartItemsAdapter extends RecyclerView.Adapter<CartItemsAdapter.ViewHolder> {

    private List<CartDetails> cartDetailsList;
    Context context;
    private ItemRemoveFromCart itemRemoveFromCart;

    public CartItemsAdapter(Context context, List<CartDetails> cartDetailsList) {
        this.context = context;
        this.cartDetailsList = cartDetailsList;
    }


    public void setItemRemoveFromCart(ItemRemoveFromCart itemRemoveFromCart) {
        this.itemRemoveFromCart = itemRemoveFromCart;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_cart_items, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int i) {
        CartDetails cartDetails = cartDetailsList.get(holder.getAdapterPosition());
        holder.textViewItemName.setText(cartDetails.product_name);
        holder.textViewItemPrice.setText("$" + new DecimalFormat("#.##").format(cartDetails.discount_price));
        holder.textViewItemQuantity.setText("" + cartDetails.quantity);

        if (cartDetails.isEdit) holder.imageViewDelete.setVisibility(View.VISIBLE);
        else holder.imageViewDelete.setVisibility(View.GONE);

        holder.imageViewLoadingIcon.setVisibility(View.VISIBLE);
        Glide.with(context)
                .load(cartDetails.product_image)
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        holder.imageViewLoadingIcon.setVisibility(View.GONE);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        holder.imageViewLoadingIcon.setVisibility(View.GONE);
                        return false;
                    }
                })
                .apply(new RequestOptions().error(R.drawable.no_image_found))
                .into(holder.imageViewItem);
    }

    @Override
    public int getItemCount() {
        return cartDetailsList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageViewDelete, imageViewLoadingIcon, imageViewItem;
        TextView textViewItemQuantity, textViewItemName, textViewItemPrice;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewItemQuantity = itemView.findViewById(R.id.textViewItemQuantity);
            textViewItemName = itemView.findViewById(R.id.textViewItemName);
            textViewItemPrice = itemView.findViewById(R.id.textViewItemPrice);
            imageViewLoadingIcon = itemView.findViewById(R.id.imageViewLoadingIcon);
            imageViewItem = itemView.findViewById(R.id.imageViewItem);

            imageViewDelete = itemView.findViewById(R.id.imageViewDelete);
            imageViewDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (itemRemoveFromCart != null) {
                        itemRemoveFromCart.itemRemove(getAdapterPosition(), cartDetailsList.get(getAdapterPosition()).product_id);
                    }
                }
            });

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (itemRemoveFromCart != null) {
                        itemRemoveFromCart.itemAdd(getAdapterPosition(), cartDetailsList.get(getAdapterPosition()).product_id);
                    }
                }
            });
        }
    }

    public int getTotalItem() {
        int count = 0;
        for (int i = 0; i < cartDetailsList.size(); i++) {
            count = count + cartDetailsList.get(i).quantity;
        }
        return count;
    }

    public double getTotalAmount() {
        double count = 0;
        for (int i = 0; i < cartDetailsList.size(); i++) {
            count = count + (cartDetailsList.get(i).quantity * cartDetailsList.get(i).discount_price);
        }
        return count;
    }

    public interface ItemRemoveFromCart {
        void itemRemove(int position, String id);

        void itemAdd(int position, String product_id);
    }
}
