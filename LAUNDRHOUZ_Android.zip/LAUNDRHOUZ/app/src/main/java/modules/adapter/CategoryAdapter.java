package modules.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.laundrhouz.android.R;

import java.util.List;

import modules.base.LogUtil;
import modules.bean.CategoryDetails;
import modules.blu.ServerHelper;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolder> {

    private int lastCheckedCategory;
    List<CategoryDetails> categoryDetailsList;
    Context context;
    ItemSelection itemSelection;

    public CategoryAdapter(Context context, List<CategoryDetails> categoryDetailsList, int categoryPosition) {
        this.context = context;
        this.categoryDetailsList = categoryDetailsList;
        lastCheckedCategory = categoryPosition;
        LogUtil.debug("categoryPosition123====>>>" + categoryPosition);
    }

    public void setItemSelection(ItemSelection itemSelection) {
        this.itemSelection = itemSelection;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_category2, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int i) {
//        holder.radioButtonCategory.setChecked(i == lastCheckedCategory);
//        holder.radioButtonCategory.setText(categoryDetailsList.get(holder.getAdapterPosition()).name);
        CategoryDetails categoryDetails = categoryDetailsList.get(holder.getAdapterPosition());

        if (holder.getAdapterPosition() == lastCheckedCategory) {
            LogUtil.debug("LAST====>>>" + lastCheckedCategory);
            holder.realativeImageView.setBackground(context.getResources().getDrawable(R.drawable.category_border_selected));
        } else {
            holder.realativeImageView.setBackground(context.getResources().getDrawable(R.drawable.category_border_selector));
        }

        holder.textViewCategoryName.setText(categoryDetails.name);
        LogUtil.debug("IMAGE_PATH===>>>" + ServerHelper.IMAGE_PATH + categoryDetails.image);

        holder.imageViewLoadingIcon.setVisibility(View.VISIBLE);
        Glide.with(context)
                .load(ServerHelper.IMAGE_PATH + categoryDetails.image)
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        holder.imageViewLoadingIcon.setVisibility(View.GONE);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        holder.imageViewLoadingIcon.setVisibility(View.GONE);
                        return false;
                    }
                })
                .apply(new RequestOptions().error(R.drawable.no_image_found))
                .into(holder.imageViewCategory);
    }

    @Override
    public int getItemCount() {
        return categoryDetailsList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout realativeImageView;
        ImageView imageViewCategory, imageViewLoadingIcon;
        TextView textViewCategoryName;

        ViewHolder(@NonNull View itemView) {
            super(itemView);

            imageViewCategory = itemView.findViewById(R.id.imageViewCategory);
            textViewCategoryName = itemView.findViewById(R.id.textViewCategoryName);
            imageViewLoadingIcon = itemView.findViewById(R.id.imageViewLoadingIcon);
            realativeImageView = itemView.findViewById(R.id.realativeImageView);

            realativeImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    lastCheckedCategory = getAdapterPosition();
                    if (itemSelection != null) {
                        itemSelection.onClick(getAdapterPosition());
                    }
                    notifyDataSetChanged();
                }
            });
        }
    }

    public interface ItemSelection {
        void onClick(int position);
    }
}
