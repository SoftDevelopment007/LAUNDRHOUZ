package modules.customeviews;

import android.app.Dialog;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.SearchView;
import android.view.View;
import android.widget.TextView;

import com.laundrhouz.android.R;

import java.util.List;

import modules.adapter.AdapterSearchableSpinner;

public class SearchableSpinner extends Dialog {

    private String title;
    private Context context;
    private List<?> list;
    private AdapterSearchableSpinner adapterSearchableSpinner;
    private OnSelectItem onSelectItem;

    public SearchableSpinner(@NonNull Context context, int themeResId, List<?> list, String title, OnSelectItem onSelectItem) {
        super(context, themeResId);
        setContentView(R.layout.dialog_spinner);
        this.title = title;
        this.context = context;
        this.list = list;
        this.onSelectItem = onSelectItem;
        initializeAllView();
    }

    private void initializeAllView() {
        TextView textViewTitle = findViewById(R.id.textViewTitle);
        SearchView searchViewList = findViewById(R.id.searchViewList);
        RecyclerView recyclerViewList = findViewById(R.id.recyclerViewList);
        recyclerViewList.setLayoutManager(new LinearLayoutManager(context));
        findViewById(R.id.imageViewClose).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });
        textViewTitle.setText(title);
        adapterSearchableSpinner = new AdapterSearchableSpinner(list);
        recyclerViewList.setAdapter(adapterSearchableSpinner);
        adapterSearchableSpinner.setOnClick(new AdapterSearchableSpinner.FilterSelectionInterface() {
            @Override
            public void onSelected(Object item) {
                if (onSelectItem != null) {
                    onSelectItem.selectItem(item);
                    dismiss();
                }
            }
        });
        searchViewList.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                adapterSearchableSpinner.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapterSearchableSpinner.getFilter().filter(newText);
                return false;
            }
        });
    }

    public interface OnSelectItem {
        void selectItem(Object item);
    }
}
