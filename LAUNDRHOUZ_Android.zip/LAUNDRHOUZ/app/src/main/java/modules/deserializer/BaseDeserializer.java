package modules.deserializer;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import java.lang.reflect.Type;

import modules.http.ResponseData;


public class BaseDeserializer<T extends ResponseData> implements JsonDeserializer {

    final Class<T> typeParameterClass;

    public BaseDeserializer(Class<T> typeParameterClass) {
        this.typeParameterClass = typeParameterClass;
    }

    @Override
    public T deserialize(final JsonElement json, final Type typeOfT, final JsonDeserializationContext context)
            throws JsonParseException {
        final JsonObject jsonObject = json.getAsJsonObject();

        final boolean result = jsonObject.get("status").getAsBoolean();
        final String message = jsonObject.get("message").getAsString();
        JsonObject data = null;

        if (jsonObject.has("data") && !jsonObject.get("data").isJsonNull() && jsonObject.get("data").isJsonObject()) {
            data = jsonObject.get("data").getAsJsonObject();
        }

        // Delegate the deserialization to the context
        //Author[] authors = context.deserialize(jsonObject.get("authors"), Author[].class);
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();

        T dataObj = null;
        try {
            dataObj = typeParameterClass.newInstance();
        } catch (InstantiationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        if (data != null) {
            dataObj = gson.fromJson(data, typeParameterClass);
        }

        dataObj.setResult(result);
        dataObj.setMessage(message);

        return dataObj;
    }
}

