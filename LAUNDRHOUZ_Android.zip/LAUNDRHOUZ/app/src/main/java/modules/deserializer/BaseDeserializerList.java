package modules.deserializer;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import java.lang.reflect.Type;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import modules.http.ResponseData;


public class BaseDeserializerList<T extends ResponseData, U> implements JsonDeserializer {

    final Class<T> typeParameterClass;
    final Class<U> st;

    public BaseDeserializerList(Class<T> typeParameterClass, Class<U> s) {
        this.typeParameterClass = typeParameterClass;
        st = s;
    }

    @Override
    public T deserialize(final JsonElement json, final Type typeOfT, final JsonDeserializationContext context)
            throws JsonParseException {
        final JsonObject jsonObject = json.getAsJsonObject();

        final boolean result = jsonObject.get("status").getAsBoolean();
        final String message = jsonObject.get("message").getAsString();
        // JsonObject data = null;
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();

        U dataObj = null;
        try {
            dataObj = st.newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

        T tObj = null;
        try {
            tObj = typeParameterClass.newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

        SortedMap<Integer, U> mapValues = new TreeMap<Integer, U>();
        if (jsonObject.has("data") && !jsonObject.get("data").isJsonNull()) {

            if (jsonObject.get("data").isJsonArray()) {

                JsonArray arrayJson = jsonObject.get("data").getAsJsonArray();

                for (int j = 0; j < arrayJson.size(); j++) {

                    JsonElement itemData = arrayJson.get(j);
                    dataObj = gson.fromJson(itemData.getAsJsonObject(), st);
                    mapValues.put(j, dataObj);
                }
            } else {

                Set<Entry<String, JsonElement>> entries = jsonObject.getAsJsonObject("data").entrySet();

                for (Entry<String, JsonElement> iter : entries) {

                    String key = iter.getKey();
                    JsonElement itemData = iter.getValue();

                    dataObj = gson.fromJson(itemData.getAsJsonObject(), st);
                    mapValues.put(Integer.parseInt(key), dataObj);
                }
            }
            tObj.setResult(result);
            tObj.setMessage(message);
            tObj.setData(new LinkedList<U>(mapValues.values()));

        } else {
            mapValues.put(1, dataObj);
            tObj.setResult(result);
            tObj.setMessage(message);
            tObj.setData(new LinkedList<U>(mapValues.values()));
        }
        return tObj;
    }

}

