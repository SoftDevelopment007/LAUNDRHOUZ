package modules.deserializer;

import java.io.Serializable;

public interface DataInterface extends Serializable {

}
