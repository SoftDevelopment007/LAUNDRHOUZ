package modules.blu;


public class ServerHelper {

//    public static final String server = "http://rajeshwersoftsolution.com/mycleanbag/public/api/";

//    public static final String IMAGE_PATH = "http://rajeshwersoftsolution.com/mycleanbag/public/";

    public static final String server = "http://laundrhouz.com/laundrhouz/public/api/";

    public static final String IMAGE_PATH = "http://laundrhouz.com/laundrhouz/public/";

    public static final String VERIFY_EMAIL_MOBILE = server + "verify_emailmno";

    public static final String USER_REGISTER = server + "userregister";

    public static final String UPDATE_PROFILE = server + "updateprofiles";

    public static final String FETCH_COUNTRY = server + "fetch_country";

    public static final String FETCH_CITY = server + "fetch_city";

    public static final String CHECK_LOGIN = server + "checklogin";

    public static final String FETCH_CATEGORY = server + "fetchcat";

    public static final String FETCH_ADDRESS = server + "fetch_address";

    public static final String INSERT_ADDRESS = server + "insert_address";

    public static final String UPDATE_ADDRESS = server + "update_address";

    public static final String DELETE_ADDRESS = server + "delete_address";

    public static final String FETCH_SUB_CATEGORY = server + "fetchsubcat";

    public static final String FETCH_PAYMENT_METHOD = server + "fetch_payment_method";

    public static final String FETCH_ITEM_FILTER = server + "fetch_itemfilter";

    public static final String CHECK_PROMOM_CODE = server + "check_promocode";

    public static final String INSERT_PAYMENT_METHOD = server + "insert_payment_method";

    public static final String FETCH_PICKUP_DATA = server + "fetch_pickupdata";

    public static final String ORDER_INSERT = server + "order_insert";

    public static final String FETCH_USER_PHONE = server + "fetch_user_phone";

    public static final String FETCH_PLAN = server + "fetch_membership_plan";

    public static final String INSERT_PHONE = server + "insert_phone";

    public static final String EDIT_PHONE = server + "edit_phone";

    public static final String DELETE_PHONE = server + "delete_phone";

    public static final String SEND_OTP_ON_MAIL = server + "verify_email";

    public static final String CHECK_OTP_EMAIL = server + "verifyotp";

    public static final String VERIFY_PHONE_OTP = server + "verifyphoneotp";

    public static final String FETCH_MASTER_ORDER_HISTORY = server + "fetch_masterorder_histroy";

    public static final String CHANGE_PASSWORD = server + "changepass";

}
