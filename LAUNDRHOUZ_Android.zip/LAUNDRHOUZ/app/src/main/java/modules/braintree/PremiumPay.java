package modules.braintree;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

import static android.content.Context.MODE_PRIVATE;

public class PremiumPay extends AsyncTask<String, Void, String> {
    Context context;
    Integer position;
    String premiumId;
    String premiumPrice, nonce, currencyCode;
    ProgressDialog progressDialog;
    String TAG = "PremiumDialog";
    SharedPreferences pref;
    SharedPreferences.Editor editor;

    public PremiumPay(Context context, String premiumId, String premiumPrice, String nonce, String currencyCode) {
        this.context = context;
        this.premiumId = premiumId;
        this.premiumPrice = premiumPrice;
        this.currencyCode = currencyCode;
        this.nonce = nonce;
        pref = context.getSharedPreferences("ChatPref",
                MODE_PRIVATE);
        editor = pref.edit();
    }

    @Override
    protected void onPreExecute() {
        progressDialog = new ProgressDialog(context);
        progressDialog.setTitle("Subcribe");
        progressDialog.setMessage("Please wait...");
        progressDialog.show();
    }

    @Override
    protected String doInBackground(String... param) {
        String jsonData = null;
        okhttp3.Response response = null;
        String url = "";
        Log.v("paynonce", "paynonce" + nonce);
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build();
        ;
        RequestBody body = new FormBody.Builder()
                .add("user_id", "123")
                .add("premium_id", premiumId)
                .add("price", premiumPrice)
                .add("pay_nonce", nonce)
                .add("", currencyCode)
                .build();
        okhttp3.Request request = new Request.Builder()
                .url(url)
                .addHeader("Authorization", pref.getString("Authorization", ""))
                .post(body)
                .build();
        Call call = client.newCall(request);
        try {
            response = call.execute();

            if (response.isSuccessful()) {
                jsonData = response.body().string();
            } else {
                jsonData = null;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        Log.v("resoibse", "issuccess" + jsonData);
        return jsonData;

    }

    @Override
    protected void onPostExecute(String res) {
        super.onPostExecute(res);
        try {
            Log.v(TAG, "payBraintreeRes=" + res);
            JSONObject json = new JSONObject(res);
            if (DefensiveClass.optString(json, "status").equalsIgnoreCase("true")) {
               /* GetSet.setPremium(true);
                editor.putBoolean(Constants.TAG_PREMIUM_MEMBER, true);
                editor.commit();
                MainScreenActivity.batch.setVisibility(View.VISIBLE);
                PremiumSuccess premiumSuccess = new PremiumSuccess(context);
                premiumSuccess.show();*/
            } else if (DefensiveClass.optString(json, "status").equalsIgnoreCase("error")) {
//                CommonFunctions.disabledialog(context, "Error", json.getString("message"));
            }
        } catch (NullPointerException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
