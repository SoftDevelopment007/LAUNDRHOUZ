package modules.app;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.laundrhouz.android.R;

public class MyProgressDialog extends Dialog {

    private ImageView imageViewLoading;

    public MyProgressDialog(Context context) {
        super(context);
        setContentView(R.layout.loading_design);
        imageViewLoading = findViewById(R.id.imageViewLoading);
        Glide.with(context).load(R.drawable.loading_icon_gif).into(imageViewLoading);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
    }
}
