package modules.bean;

import com.google.gson.annotations.SerializedName;

import modules.http.ResponseData;

public class FaqListDetails extends ResponseData {

    @SerializedName("faq_id")
    public String faq_id;
    @SerializedName("subcat_id")
    public String subcat_id;
    @SerializedName("question")
    public String question;
    @SerializedName("description")
    public String description;
}
