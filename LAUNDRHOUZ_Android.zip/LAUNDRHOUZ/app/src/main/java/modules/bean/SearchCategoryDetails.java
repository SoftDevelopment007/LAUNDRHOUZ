package modules.bean;

import com.google.gson.annotations.SerializedName;

import java.util.List;

import modules.http.ResponseData;

public class SearchCategoryDetails extends ResponseData {

    @SerializedName("category")
    public String category;

    @SerializedName("image")
    public String image;

    @SerializedName("itemlist")
    public List<ItemDetails> itemlist;

    boolean isSelected = false;

}
