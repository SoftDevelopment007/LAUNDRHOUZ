package modules.bean;

import com.google.gson.annotations.SerializedName;

import modules.http.ResponseData;

public class PaymentMethodDetails extends ResponseData {

    @SerializedName("id")
    public String id;

    @SerializedName("payment_method")
    public String payment_method;

    @SerializedName("payment_uniqid")
    public String payment_uniqid;

    @SerializedName("mm_yy")
    public String mm_yy;

    @SerializedName("postcode")
    public String postcode;

    @SerializedName("user_id")
    public String user_id;

    @SerializedName("isChecked")
    public boolean isChecked = false;


}
