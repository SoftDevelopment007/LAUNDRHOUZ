package modules.bean;

import com.google.gson.annotations.SerializedName;

import modules.http.ResponseData;

public class PhoneNumberDetails extends ResponseData {

    @SerializedName("id")
    public String id;
    @SerializedName("phone")
    public String phone;
    @SerializedName("place_type")
    public String place_type;
    @SerializedName("user_id")
    public String user_id;
    @SerializedName("is_active")
    public String is_active;
    @SerializedName("created_dt")
    public String created_dt;
    @SerializedName("modified_dt")
    public String modified_dt;

}
