package modules.bean;

import com.google.gson.annotations.SerializedName;

import modules.http.ResponseData;

public class AddressDetails extends ResponseData {

    @SerializedName("add_id")
    public String add_id;
    @SerializedName("add_type")
    public String add_type;
    @SerializedName("address")
    public String address;
    @SerializedName("city")
    public String city;
    @SerializedName("post_code")
    public String post_code;
    @SerializedName("country")
    public String country;
    @SerializedName("latitude")
    public String latitude;
    @SerializedName("logitude")
    public String logitude;
    @SerializedName("created_dt")
    public String created_dt;
    @SerializedName("modified_dt")
    public String modified_dt;

    @SerializedName("isChecked")
    public boolean isChecked = false;

}
