package modules.bean;

import com.google.gson.annotations.SerializedName;

import modules.http.ResponseData;

public class PlanDetails extends ResponseData {

    @SerializedName("plan_id")
    public String plan_id;

    @SerializedName("plan_name")
    public String plan_name;

    @SerializedName("amount")
    public String amount;

    @SerializedName("weight")
    public String weight;

    @SerializedName("membership_type")
    public String membership_type;

    @SerializedName("membership_mode")
    public String membership_mode;
}
