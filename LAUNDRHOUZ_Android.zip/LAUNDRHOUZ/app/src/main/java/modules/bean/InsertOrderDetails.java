package modules.bean;

import com.google.gson.annotations.SerializedName;

import java.util.List;

import modules.http.ResponseData;

public class InsertOrderDetails extends ResponseData {

    @SerializedName("cust_id")
    public String cust_id;

    @SerializedName("address_id")
    public String address_id;
    @SerializedName("address")
    public String address;
    @SerializedName("promocode_amount")
    public double promocode_amount;
    @SerializedName("subtotal_amount")
    public double subtotal_amount;
    @SerializedName("final_subtotal")
    public double final_subtotal;
    @SerializedName("payment_status")
    public String payment_status;
    @SerializedName("payment_id")
    public String payment_id;
    @SerializedName("pickup_charge")
    public String pickup_charge;
    @SerializedName("pickup_date")
    public String pickup_date;
    @SerializedName("pickup_time")
    public String pickup_time;
    @SerializedName("item_qty")
    public String item_qty;

    @SerializedName("total_amount")
    public double total_amount;

    @SerializedName("instruction")
    public String instruction;

    @SerializedName("deliver_date")
    public String deliver_date;

    @SerializedName("OrderDetails")
    public List<OrderDetails> OrderDetails;

}
