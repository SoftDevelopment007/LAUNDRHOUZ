package modules.bean;

import com.google.gson.annotations.SerializedName;

import modules.http.ResponseData;

public class ItemDetails extends ResponseData {

    @SerializedName("item_id")
    public String item_id;
    @SerializedName("item_name")
    public String item_name;
    @SerializedName("cat_id")
    public String cat_id;
    @SerializedName("subcat_id")
    public String subcat_id;
    @SerializedName("subtype_id")
    public String subtype_id;
    @SerializedName("item_originalprice")
    public double item_originalprice;
    @SerializedName("item_discprice")
    public double item_discprice;
    @SerializedName("short_desc")
    public String short_desc;
    @SerializedName("is_offer")
    public String is_offer;
    @SerializedName("offer_id")
    public String offer_id;
    @SerializedName("is_active")
    public String is_active;
    @SerializedName("is_delete")
    public String is_delete;
    @SerializedName("created_dt")
    public String created_dt;
    @SerializedName("modified_dt")
    public String modified_dt;
    @SerializedName("image")
    public String image;


    @SerializedName("quantiy")
    public int quantity=0;
}
