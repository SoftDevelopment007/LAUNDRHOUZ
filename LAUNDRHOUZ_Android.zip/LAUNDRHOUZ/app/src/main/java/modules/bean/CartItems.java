package modules.bean;

public class CartItems {
    boolean isEdit;

    public CartItems(boolean isEdit) {
        this.isEdit = isEdit;
    }

    public void setEdit(boolean edit) {
        isEdit = edit;
    }

    public boolean isEdit() {
        return isEdit;
    }
}
