package modules.bean;

import com.google.gson.annotations.SerializedName;

import modules.http.ResponseData;

public class CountryDetails extends ResponseData {

    @SerializedName("id")
    public String id;
    @SerializedName("name")
    public String name;

    @Override
    public String toString() {
        return name;
    }
}
