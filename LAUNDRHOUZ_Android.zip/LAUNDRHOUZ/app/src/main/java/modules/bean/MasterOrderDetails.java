package modules.bean;

import com.google.gson.annotations.SerializedName;

import modules.http.ResponseData;

public class MasterOrderDetails extends ResponseData {

    @SerializedName("order_id")
    public String order_id;
    @SerializedName("master_order_id")
    public String master_order_id;
    @SerializedName("cust_id")
    public String cust_id;
    @SerializedName("address_id")
    public String address_id;
    @SerializedName("subtotal_amount")
    public String subtotal_amount;
    @SerializedName("promocode_amount")
    public String promocode_amount;
    @SerializedName("final_subtotal")
    public String final_subtotal;
    @SerializedName("pickup_date")
    public String pickup_date;
    @SerializedName("pickup_time")
    public String pickup_time;
    @SerializedName("pickup_charge")
    public String pickup_charge;
    @SerializedName("total_amount")
    public String total_amount;
    @SerializedName("item_qty")
    public String item_qty;
    @SerializedName("master_order_status")
    public String master_order_status;
    @SerializedName("order_date")
    public String order_date;
    @SerializedName("deliver_date")
    public String deliver_date;
    @SerializedName("instruction")
    public String instruction;
    @SerializedName("payment_status")
    public String payment_status;
    @SerializedName("payment_id")
    public String payment_id;
    @SerializedName("is_active")
    public String is_active;
    @SerializedName("is_delete")
    public String is_delete;
    @SerializedName("created_dt")
    public String created_dt;
    @SerializedName("modified_dt")
    public String modified_dt;
}
