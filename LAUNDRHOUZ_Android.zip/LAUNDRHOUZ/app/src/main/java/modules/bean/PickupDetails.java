package modules.bean;

import com.google.gson.annotations.SerializedName;

import modules.http.ResponseData;

public class PickupDetails extends ResponseData {

    @SerializedName("pickup_charge")
    public String pickup_charge;
    @SerializedName("pickup_limit")
    public String pickup_limit;

}
