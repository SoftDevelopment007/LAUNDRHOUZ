package modules.bean;

import com.google.gson.annotations.SerializedName;

import modules.http.ResponseData;

public class UserDetails extends ResponseData {

    @SerializedName("id")
    public String id;
    @SerializedName("fname")
    public String fname;
    @SerializedName("lname")
    public String lname;
    @SerializedName("email")
    public String email;
    @SerializedName("email_verified_at")
    public String email_verified_at;
    @SerializedName("mobile_no")
    public String mobile_no;
    @SerializedName("dob")
    public String dob;
    @SerializedName("gender")
    public String gender;
    @SerializedName("logo")
    public String logo;
    @SerializedName("latitude")
    public String latitude;
    @SerializedName("longitude")
    public String longitude;
    @SerializedName("device_type")
    public String device_type;
    @SerializedName("device_id_1")
    public String device_id_1;
    @SerializedName("gcm_id")
    public String gcm_id;
    @SerializedName("user_role")
    public String user_role;
    @SerializedName("token")
    public String token;
    @SerializedName("access_token")
    public String access_token;
    @SerializedName("is_verify")
    public String is_verify;
    @SerializedName("is_active")
    public String is_active;
    @SerializedName("is_delete")
    public String is_delete;
    @SerializedName("timestamp")
    public String timestamp;
    @SerializedName("created_at")
    public String created_at;
    @SerializedName("updated_at")
    public String updated_at;

    @SerializedName("add_id")
    public String add_id;
    @SerializedName("add_type")
    public String add_type;
    @SerializedName("address")
    public String address;
    @SerializedName("city")
    public String city;
    @SerializedName("post_code")
    public String post_code;
    @SerializedName("country")
    public String country;

    @SerializedName("payment_id")
    public String payment_id;
    @SerializedName("payment_method")
    public String payment_method;
    @SerializedName("payment_uniqid")
    public String payment_uniqid;
    @SerializedName("postcode")
    public String postcode;
    @SerializedName("my_referral_code")
    public String my_referral_code;
    @SerializedName("mm_yy")
    public String mm_yy;

    @SerializedName("plan_id")
    public String plan_id;


    /*@SerializedName("useraddress")
    public List<AddressDetails> useraddress;*/

}
