package modules.bean;

import com.google.gson.annotations.SerializedName;

import modules.http.ResponseData;

public class OrderDetails extends ResponseData {

    @SerializedName("item_id")
    public String item_id;
    @SerializedName("item_name")
    public String item_name;
    @SerializedName("item_qty")
    public int item_qty;
    @SerializedName("item_unitprice")
    public int item_unitprice;
    @SerializedName("item_totalprice")
    public int item_totalprice;





}
