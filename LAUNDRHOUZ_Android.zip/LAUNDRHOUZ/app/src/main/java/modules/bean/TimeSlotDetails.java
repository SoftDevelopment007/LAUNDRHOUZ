package modules.bean;

import com.google.gson.annotations.SerializedName;

import modules.http.ResponseData;

public class TimeSlotDetails extends ResponseData {

    @SerializedName("start_time")
    public String start_time;
    @SerializedName("end_time")
    public String end_time;

    @SerializedName("isValid")
    public boolean isValid = false;


    public TimeSlotDetails(String start_time, String end_time) {
        this.start_time = start_time;
        this.end_time = end_time;
    }
}
