package modules.bean;

import com.google.gson.annotations.SerializedName;

import modules.http.ResponseData;

public class PromocodeDetails extends ResponseData {

    @SerializedName("promo_id")
    public String promo_id;
    @SerializedName("promo_code")
    public String promo_code;
    @SerializedName("amount")
    public String amount;
    @SerializedName("app_no_of_time")
    public String app_no_of_time;
    @SerializedName("is_cashback")
    public String is_cashback;
    @SerializedName("is_active")
    public String is_active;
    @SerializedName("is_delete")
    public String is_delete;
    @SerializedName("created_dt")
    public String created_dt;
    @SerializedName("modified_dt")
    public String modified_dt;

}
