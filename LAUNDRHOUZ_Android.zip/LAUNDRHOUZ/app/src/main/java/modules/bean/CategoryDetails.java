package modules.bean;

import com.google.gson.annotations.SerializedName;

import java.util.List;

import modules.http.ResponseData;

public class CategoryDetails extends ResponseData {

    @SerializedName("category_id")
    public String category_id;
    @SerializedName("name")
    public String name;
    @SerializedName("image")
    public String image;
    @SerializedName("is_multiple")
    public String is_multiple;
    @SerializedName("itemlist")
    public List<ItemDetails> itemlist;

    boolean isSelected = false;

}
