package modules.bean;

import com.google.gson.annotations.SerializedName;

import java.util.List;

import modules.http.ResponseData;

public class SubcategoryDetails extends ResponseData {

    @SerializedName("category_id")
    public String category_id;
    @SerializedName("name")
    public String name;
    @SerializedName("image")
    public String image;
    @SerializedName("description")
    public String description;
    @SerializedName("minvalue")
    public String minvalue;

    @SerializedName("faqlist")
    public List<FaqListDetails> faqlist;

    @SerializedName("itemlist")
    public List<ItemDetails> itemlist;

}
