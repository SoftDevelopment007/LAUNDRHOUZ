package modules.http;

import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyLog;

import org.apache.http.HttpEntity;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Map;


public class MultipartRequest extends Request<String> {

    MultipartEntityBuilder entity = MultipartEntityBuilder.create();
    HttpEntity httpentity;
    private String FILE_PART_NAME;

    private final Response.Listener<String> mListener;
    private final File mFilePart;
    private final Map<String, String> mStringPart;

    MultipartProgressListener multipartProgressListener;
    long fileLength;

    public MultipartRequest(String url, Response.ErrorListener errorListener, Response.Listener<String> listener,
                            File file, String filename, Map<String, String> mStringPart,
                            MultipartProgressListener multipartProgressListener2) {

        super(Method.POST, url, errorListener);

        mListener = listener;

        if (file != null) {
            mFilePart = file;
            this.fileLength = file.length();
        } else {
            mFilePart = null;
        }

        this.mStringPart = mStringPart;
        this.multipartProgressListener = multipartProgressListener2;
        entity.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
        this.FILE_PART_NAME = filename;
        if (file != null) {
            buildMultipartEntity();
        } else {

        }
    }

    public void addStringBody(String param, String value) {
        mStringPart.put(param, value);
    }

    private void buildMultipartEntity() {
        if (mFilePart != null) {
            entity.addPart(FILE_PART_NAME, new FileBody(mFilePart));
            System.out.println("file Value: " + mFilePart);
        }
        if (mStringPart != null) {
            for (Map.Entry<String, String> entry : mStringPart.entrySet()) {

                entity.addTextBody(entry.getKey(), entry.getValue());
                System.out.println(entry.getKey() + ": " + entry.getValue());
            }
        }
    }

    @Override
    public String getBodyContentType() {
        System.out.println("getBodyContentType()...");

        return httpentity.getContentType().getValue();
    }

    @Override
    public byte[] getBody() throws AuthFailureError {
        System.out.println("getBody()...");

		/*
         * ByteArrayOutputStream bos = new ByteArrayOutputStream();
		 * 
		 * try {
		 * 
		 * httpentity = entity.build(); httpentity.writeTo(bos);
		 * 
		 * } catch (IOException e) { VolleyLog.e(
		 * "IOException writing to ByteArrayOutputStream"); }
		 * System.out.println("getBody()... bos.toByteArray(): " +
		 * bos.toByteArray().toString());
		 */

        ByteArrayOutputStream bos = new ByteArrayOutputStream(1024);
        try {

            httpentity = entity.build();
            if (mFilePart != null) {
                httpentity.writeTo(new CountingOutputStream(bos, this.fileLength, multipartProgressListener));
            }
        } catch (Exception e) {
            VolleyLog.e("IOException writing to ByteArrayOutputStream");
        }

        return bos.toByteArray();
    }

    @Override
    protected Response<String> parseNetworkResponse(NetworkResponse response) {

        // try {
        // // solution 1:
        String jsonString;
        try {
            jsonString = new String(response.data, "UTF-8");
            Log.e("NetworkResponse", "NetworkResponse: " + response.toString());
            return Response.success(jsonString, getCacheEntry());
        } catch (UnsupportedEncodingException e) {
            Log.e("NetworkResponse", "NetworkResponse: ERROR:" + response.toString());
            return Response.error(new ParseError(e));
        }

    }

    @Override
    protected void deliverResponse(String response) {

        System.out.println("deliverResponse: " + response);
        mListener.onResponse(response);
    }

    public static interface MultipartProgressListener {
        void transferred(long transfered, int progress);
    }

    public static class CountingOutputStream extends FilterOutputStream {

        private final MultipartProgressListener progListener;
        private long transferred;
        private long fileLength;
        int uploadedByte = 0;

        public CountingOutputStream(final OutputStream out, long fileLength, final MultipartProgressListener listener) {

            super(out);
            this.fileLength = fileLength;
            this.progListener = listener;
            this.transferred = 0;
        }

        public void write(byte[] b, int off, int len) throws IOException {
            System.out.println("write(byte[] b, int off, int len)...");
            out.write(b, off, len);
            if (progListener != null) {

                uploadedByte += b.length;
                this.transferred += len;
                int prog = (int) (transferred * 100 / fileLength);
                this.progListener.transferred(this.transferred, prog);

                Log.e("write: ", ", off: " + off + ", len: " + len + ", transferred: " + transferred + ", prog: " + prog
                        + ", B length: " + b.length + ", uploadedByte: " + uploadedByte);
            }
        }

        public void write(int b) throws IOException {
            System.out.println("write(int b)...");
            out.write(b);
            if (progListener != null) {
                this.transferred++;
                int prog = (int) (transferred * 100 / fileLength);
                this.progListener.transferred(this.transferred, prog);
            }
        }
    }
}