package modules.http;

import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Created by om on 3/14/2015.
 */
public class LocalRequest<T> {

    private final Class<T> clazz;
    private final Object deserializer;
//    private ByteArrayInputStream reader = null;
    private String localFilePath;

    public LocalRequest(String localFilePath, Class<T> clazz, Object deserializer) {
        this.clazz = clazz;
        this.deserializer = deserializer;
        this.localFilePath = localFilePath;
    }

    public T normalXmlParsing(){

        T data = null;

        try {

            // InputStream stream = getResources().openRawResource(R.raw.normal);

            InputStream stream = new FileInputStream(localFilePath);


            StringBuilder builder = new StringBuilder();
            byte [] buffer = new byte[1024];
            int read;
            try {
                while ((read = stream.read(buffer)) >= 0) {
                    builder.append(new String(buffer, 0, read, "UTF-8"));
                }
            } catch (IOException e) {
                Log.e("Tag", "Problem when reading from stream", e);
            } finally {
                try {
                    stream.close();
                } catch (IOException e) {
                    Log.e("Tag", "Problem when closing input stream", e);
                }
            }
            String xml = builder.toString();
            //xml = xml.replaceAll("\"", "");
            //xml = xml.replaceAll("\\'", "");
            //xml = xml.replaceAll("\t'", "  ");
            Log.v("TAG", xml);


            //serializer = new Persister();
//            reader = new ByteArrayInputStream(xml.getBytes());

            //data1 = serializer.read(maindata.class, reader, false);
           // data1 = serializer.read(MainData.class, reader, false);

            GsonBuilder gsonBuilder = new GsonBuilder();
            gsonBuilder.registerTypeAdapter(clazz, deserializer);
            Gson gson = gsonBuilder.create();
            data = gson.fromJson(xml, clazz);




        } catch (Exception e) {
            e.printStackTrace();
            Log.v("TAG", "catch .. " + e.toString());

        } /*finally{

            if(reader != null){

                try{
                    reader.close();
                }catch (Exception e) {
                    Log.v("TAG","finallt : "+e.toString());
                }

            }

            reader = null;
        }*/
        return data;
    }
}
