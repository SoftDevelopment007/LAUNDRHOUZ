package modules.http;


import androidx.room.Ignore;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class ResponseData implements Serializable {


    @Ignore
    @SerializedName("status")
    private boolean status;
    @Ignore
    @SerializedName("message")
    private String message;
    @Ignore
    @SerializedName("data")
    private Object data;

    public void setResult(boolean status) {
        this.status = status;
    }

    public boolean getResult() {
        return status;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public Object getData() {
        return data;
    }

    public void release() {
//        result = null;
        message = null;
        data = null;
        callGC();
    }

    public void callGC() {
    }

}
