package modules.http;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.toolbox.HttpHeaderParser;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.UnsupportedEncodingException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import modules.base.LogUtil;

public class BaseHttpRequest<T> extends Request<T> {
    private static final int TIMEOUT_RETRY_POLICY = 60000;
    private final Object deserializer;
    private final Class<T> clazz;
    private final Listener<T> listener;
    private String access_token = "";
    private static Map<String, String> mHeader = new HashMap<String, String>();
    private static Map<String, String> mParams = new HashMap<String, String>();

    /**
     * Parameter ic_setting_tablayout access to your server must pass, keys etc.
     */
    static {
        //mHeader.put("APP-Key", "LBS-AAA");
        //mHeader.put("APP-Secret", "ad12msa234das232in");
    }

    /**
     * @param url
     * @param clazz         Our final conversion type
     *                      // * @param headers       Accompanying the request header information
     * @param listener      // * @param appendHeader  Additional head data
     * @param errorListener
     */
    public BaseHttpRequest(String url, Class<T> clazz, Map<String, String> params, Listener<T> listener,
                           ErrorListener errorListener, Object deserializer) {
        super(Method.POST, url, errorListener);
        LogUtil.debug(" ---- BaseHttpRequest URL : " + url);
        setRetryPolicy(new DefaultRetryPolicy(
                TIMEOUT_RETRY_POLICY,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        this.clazz = clazz;
        this.listener = listener;
        this.deserializer = deserializer;
        mParams.clear();
        mParams.putAll(params);
        LogUtil.debug(" ---- BaseHttpRequest param key : " + mParams);
    }

    public void setToken(String token) {
        access_token = token;
    }

    @Override
    public Map<String, String> getHeaders() throws AuthFailureError {
        Map<String, String> headers = super.getHeaders();

        if (headers == null
                || headers.equals(Collections.emptyMap())) {
            headers = new HashMap<String, String>();
        }
        if (access_token != null && access_token.trim().length() != 0) {
            headers.put("Authorization", access_token);
        }
//
// headers.put("content-type", "application/json");
//        headers.put("Content-Type", "application/json; charset=utf-8");
        return headers;
    }


    @Override
    protected Map<String, String> getParams() throws AuthFailureError {
        return mParams;
    }

    @Override
    protected void deliverResponse(T response) {
        listener.onResponse(response);
    }

    @Override
    protected Response<T> parseNetworkResponse(NetworkResponse response) {
        try {
            /**
             * Returns the data
             */
            //String jsonStr = new String(response.data, HttpHeaderParser.parseCharset(response.headers));

            String jsonStr = new String(response.data, "UTF-8");
            LogUtil.debug("--- Response : " + jsonStr);

            GsonBuilder gsonBuilder = new GsonBuilder();
            gsonBuilder.registerTypeAdapter(clazz, deserializer);
            Gson gson = gsonBuilder.create();

            /*String jsonStr =
            GsonBuilder gsonBuilder = new GsonBuilder();
            gsonBuilder.registerTypeAdapter(clazz, deserializer);
            Gson gson = gsonBuilder.create();
            ResponseData data = gson.fromJson(jsonStr, ResponseData.class);*/

            /**
             * Into the object
             */
            return Response.success(gson.fromJson(jsonStr, clazz), HttpHeaderParser.parseCacheHeaders(response));
            //return Response.success(jsonStr, HttpHeaderParser.parseCacheHeaders(response));

        } catch (UnsupportedEncodingException e) {
            LogUtil.debug("error_encode====>>>>>>" + e.getMessage());
            return Response.error(new ParseError(e));
        } catch (Exception e) {
            LogUtil.debug("error_response====>>>>>>" + e.getMessage());
            return Response.error(new ParseError(e));
        }
    }
}
