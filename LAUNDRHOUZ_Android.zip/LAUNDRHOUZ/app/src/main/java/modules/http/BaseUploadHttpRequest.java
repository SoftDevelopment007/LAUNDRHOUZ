package modules.http;

import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.HttpHeaderParser;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import modules.base.LogUtil;

public class BaseUploadHttpRequest<T> extends Request<T> {

    private static final int TIMEOUT_RETRY_POLICY = 15000;
    private String access_token = "";
    private static Map<String, String> mParams = new HashMap<String, String>();
    private static Map<String, File> mFiles = new HashMap<String, File>();

    /**
     * Parameter ic_setting_tablayout access to your server must pass, keys etc.
     */
    static {
        //mHeader.put("APP-Key", "LBS-AAA");
        //mHeader.put("APP-Secret", "ad12msa234das232in");
    }

    private final Object deserializer;
    private final Class<T> clazz;
    private final Listener<T> listener;
    private MultipartEntityBuilder mBuilder = MultipartEntityBuilder.create();

    /**
     * @param url
     * @param clazz         Our final conversion type //* @param headers       Accompanying the
     *                      request header information
     * @param listener      // * @param appendHeader  Additional head data
     * @param errorListener
     */
    public BaseUploadHttpRequest(String url, Class<T> clazz, Map<String, String> params, Map<String, File> files, Listener<T> listener,
                                 ErrorListener errorListener, Object deserializer) {
        super(Method.POST, url, errorListener);
        setRetryPolicy(new DefaultRetryPolicy(
                TIMEOUT_RETRY_POLICY,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        this.clazz = clazz;
        this.listener = listener;
        this.deserializer = deserializer;
        mFiles.putAll(files);
        //mHeader.putAll(appendHeader);
        mParams.putAll(params);

        buildMultipartEntity();
    }

    public void setToken(String token) {
        access_token = token;
    }

    @Override
    public Map<String, String> getHeaders() throws AuthFailureError {
        Map<String, String> headers = super.getHeaders();

        if (headers == null
                || headers.equals(Collections.emptyMap())) {
            headers = new HashMap<String, String>();
        }

        if (access_token != null && access_token.trim().length() != 0) {
            headers.put("Authorization", access_token);
        }

        LogUtil.debug("--- Request : header " + headers);
//        headers.put("content-type", "application/json");
//        headers.put("Content-Type", "application/json; charset=utf-8");
        return headers;
    }

    private void buildMultipartEntity() {
        int count = 0;
        for (String key : mFiles.keySet()) {
            File file = mFiles.get(key);
            String fileName = file.getName();
            LogUtil.debug("ImageUpload " + fileName);
            mBuilder.addBinaryBody(key, file, ContentType.create("image/jpeg"), fileName);
        }

        try {
            for (String key : mParams.keySet()) {
                mBuilder.addTextBody(key, mParams.get(key));
            }
        } catch (Exception e) {
            VolleyLog.e("Exception");
        }
        mBuilder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
        mBuilder.setLaxMode().setBoundary("xx").setCharset(Charset.forName("UTF-8"));
        mFiles.clear();
    }

    @Override
    public String getBodyContentType() {
        return mBuilder.build().getContentType().getValue();
    }

    @Override
    public byte[] getBody() throws AuthFailureError {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            mBuilder.build().writeTo(bos);
        } catch (IOException e) {
            VolleyLog.e("IOException writing to ByteArrayOutputStream bos, building the multipart request.");
        }

        return bos.toByteArray();
    }

    @Override
    protected void deliverResponse(T response) {
        listener.onResponse(response);
    }

    @Override
    protected Response<T> parseNetworkResponse(NetworkResponse response) {
        try {
            /**
             * Returns the data
             */

            String jsonStr = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
            Log.d("UPLOAD 111 : ", jsonStr);

            GsonBuilder gsonBuilder = new GsonBuilder();
            gsonBuilder.registerTypeAdapter(clazz, deserializer);
            Gson gson = gsonBuilder.create();

            /**
             * Into the object
             */
            return Response.success(gson.fromJson(jsonStr, clazz), HttpHeaderParser.parseCacheHeaders(response));
            //return Response.success(jsonStr, HttpHeaderParser.parseCacheHeaders(response));

        } catch (UnsupportedEncodingException e) {
            return Response.error(new ParseError(e));
        } catch (Exception e) {
            return Response.error(new ParseError(e));
        }
    }
}
