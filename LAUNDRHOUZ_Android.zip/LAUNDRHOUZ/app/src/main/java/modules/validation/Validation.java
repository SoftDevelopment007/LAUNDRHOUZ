package modules.validation;

import android.graphics.Color;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Pattern;

public class Validation {

    // Regular Expression
    // you can change the expression based on your need
    private static final String EMAIL_REGEX = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
    //    private static final String PHONE_REGEX = "^[0-9+-]+$";
    private static final String PHONE_REGEX = "\\d{3}\\d{7}";
    private static final String ZIPCODE_REGEX = "^[1-9][0-9]{5}$";
    public static final String GSTINFORMAT_REGEX = "[0-9]{2}[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9A-Za-z]{1}[Z]{1}[0-9a-zA-Z]{1}";
    public static final String CARD_REGX = "(?:0[1-9]|1[0-2])/[0-9]{2}";
    public static final String CARD_NUMBER_REGX = "^[0-9]{16}$";
    public static final String COUNTRY_CODE_REGX = "([+]?\\d{1,2}[.-\\s]?)?(\\d{3}[.-]?){2}\\d{4}";


    // Error Messages
    private static final String REQUIRED_MSG = "required";
    private static final String EMAIL_MSG = "invalid email";
    private static final String ZIPCODE_MSG = "invalid zipcode";
    private static final String PHONE_MSG = "invalid number";
    private static final String GSTIN_MSG = "invalid number";
    private static final String CONFIRM_PASSWORD = "not match password";
    private static final String CARD_MSG = "invalid date";
    private static final String CARD_NUMBER_MSG = "invalid card Number";

    private static final String COUNTRY_CODE_MSG = "invalid Phone Number";

    // call this method when you need to check email validation
    public static boolean isEmailAddress(EditText editText, boolean required) {
        return isValid(editText, EMAIL_REGEX, EMAIL_MSG, required);
    }

    public static boolean isPhoneNumberValid(EditText editText, boolean required) {
        return isValid(editText, COUNTRY_CODE_REGX, COUNTRY_CODE_MSG, required);
    }

    public static boolean isZipCode(EditText editText, boolean required) {
        return isValid(editText, ZIPCODE_REGEX, ZIPCODE_MSG, required);
    }

    public static boolean isCard(EditText editText, boolean required) {
        return isValid(editText, CARD_REGX, CARD_MSG, required);
    }

    public static boolean isCardNumber(EditText editText, boolean required) {
        return isValid(editText, CARD_NUMBER_REGX, CARD_NUMBER_MSG, required);
    }

    // call this method when you need to check phone number validation
    public static boolean isPhoneNumber(EditText editText, boolean required) {
        return isValid(editText, PHONE_REGEX, PHONE_MSG, required);
    }

    public static boolean isGstin(EditText editText, boolean required) {
        return isValid(editText, GSTINFORMAT_REGEX, GSTIN_MSG, required);
    }

    // return true if the input field is valid, based on the parameter passed
    public static boolean isValid(EditText editText, String regex,
                                  String errMsg, boolean required) {

        String text = editText.getText().toString().trim();
        // clearing the error, if it was previously set by some other values
        editText.setError(null);

        // text required and editText is blank, so return false
        if (required && !hasText(editText))
            return false;

        // pattern doesn't match so returning false
        if (required && !Pattern.matches(regex, text)) {
            editText.setError(errMsg);
            return false;
        };

        return true;
    }

    // check the input field has any text or not
    // return true if it contains text otherwise false
    public static boolean hasText(EditText editText) {

        String text = editText.getText().toString().trim();
        editText.setError(null);

        // length 0 means there is no text
        if (text.length() == 0) {
            editText.setError(REQUIRED_MSG);
            return false;
        }

        return true;
    }

    public static boolean hasSpinnerSelected(Spinner spinner) {

        int position = spinner.getSelectedItemPosition();

        // length 0 means there is no text
        if (position == 0) {
            TextView errorText = (TextView) spinner.getSelectedView();
            errorText.setError("");
            errorText.setTextColor(Color.RED);//just to highlight that this is an error
            errorText.setText("");//changes the selected item text to this
            return false;
        }

        return true;
    }

    public static boolean hasTextToast(EditText editText) {

        String text = editText.getText().toString().trim();

        editText.clearFocus();
        // length 0 means there is no text
        if (text.length() == 0) {
            editText.requestFocus();
            Toast.makeText(editText.getContext(), REQUIRED_MSG, Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    public static boolean isConfirmPassword(EditText editTextPassword, EditText editTextConfirmPasswords) {

        String password = editTextPassword.getText().toString().trim();
        String confirmPassword = editTextConfirmPasswords.getText().toString().trim();

        if (!password.equals(confirmPassword)) {
            editTextConfirmPasswords.setError(CONFIRM_PASSWORD);
            return false;
        }

        return true;
    }

}
