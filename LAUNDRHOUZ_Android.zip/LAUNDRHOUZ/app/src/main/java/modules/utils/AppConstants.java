package modules.utils;

public class AppConstants {

    public static final int ACTIVITY_FOR_RESULT_ADDRESS_DATA = 101;
    public static final int ACTIVITY_FOR_RESULT_EDIT_PRODUCT_DETAIL = 103;
    public static final int ACTIVITY_FOR_RESULT_ADD_PRODUCT_DETAIL = 104;
    public static final int ACTIVITY_FOR_RESULT_RATTING = 104;

    public static final String USER_DATA = "user_data";
    public static final String REGISTER_TYPE = "register_type";
    public static final String GENDER = "gender";
    public static final String USER_TYPE = "user_type";


    public static final String INTENT_CATEGORY_DETAIL = "categoryDetails";
    public static final String INTENT_SHOP_DETAIL = "shopDetails";
    public static final String INTENT_PRODUCT_DETAIL = "productDetails";
    public static final String INTENT_OFFER_DETAIL = "offerDetails";
    public static final String INTENT_SHOP_NAME = "shopName";
    public static final String INTENT_SELECTED_DATE_TIME = "selectedDateTime";
    public static final String INTENT_MASTERORDER_ID = "masterOrderId";
    public static final String LATITUDE = "latitude";
    public static final String LONGITUDE = "longitude";

    public static final String INTENT_NOTIFICATION_DETAILS = "longitude";
    public static final String NOTIFICATION_ORDER_ACCEPETED = "order_accepted";
    public static final String NOTIFICATION_ORDER_REJECTED = "order_rejected";
}
