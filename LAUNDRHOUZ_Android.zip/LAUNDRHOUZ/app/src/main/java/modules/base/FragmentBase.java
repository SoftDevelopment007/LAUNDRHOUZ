package modules.base;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.StrictMode;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import com.laundrhouz.android.R;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import modules.app.MyProgressDialog;
import modules.room_db.AppDatabase;


public class FragmentBase extends Fragment {

    public Context context;
    public Activity viewContext;
    public ApplicationPrefs prefs;
//    public DBHelper dbHelper;
    public MyProgressDialog pDialog;
    public String filePath = null;
    protected AppDatabase appDatabase;


    public void loadFragment(Fragment fragment) {
        FragmentTransaction transaction = Objects.requireNonNull(getFragmentManager()).beginTransaction();
        transaction.setCustomAnimations(R.anim.slide_in_left, R.anim.slide_out_right, R.anim.slide_in_right, R.anim.slide_out_left);
        transaction.replace(R.id.frame_container, fragment);
        transaction.commit();
    }

    @Override
    public void onCreate(Bundle arg0) {

        super.onCreate(arg0);
        context = getActivity().getApplicationContext();
        viewContext = getActivity();
        prefs = ApplicationPrefs.getInstance(context);
//        dbHelper = DBHelper.getInstance(context);
        appDatabase = AppDatabase.getAppDatabase(getActivity());


        checkPermission();
        initProgressDialog();
    }


    @SuppressLint("NewApi")
    public void checkPermission() {
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy =
                    new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
    }

    public void showMessage(String msg) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    }

    public void initProgressDialog() {
        pDialog = new MyProgressDialog(viewContext);
//        pDialog.setMessage("Loading...");
        pDialog.setCancelable(false);

    }

    public void showProgressDialog() {
        if (pDialog != null && !pDialog.isShowing())
            pDialog.show();
    }

    public void dismissProgressDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    public Map<String, String> getParam() {
        Map<String, String> param = new HashMap<>();
        // param.put("user_id", prefs.getUserId());
        return param;
    }

    public void showErrorMessage(Exception e) {
        LogUtil.debug("--- " + e.getLocalizedMessage());
        Toast.makeText(context, R.string.error_message, Toast.LENGTH_SHORT).show();
    }


    public boolean isOnline() {
        ConnectivityManager conMgr = (ConnectivityManager) viewContext.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = conMgr.getActiveNetworkInfo();

        if (netInfo == null || !netInfo.isConnected() || !netInfo.isAvailable()) {

            final AlertDialog alertDialog = new AlertDialog.Builder(viewContext).create();

            // Setting Dialog Title
            alertDialog.setTitle("Alert for Connection");

            // Setting Dialog Message
            alertDialog.setMessage("No Internet Connection");

            // Setting Icon to Dialog
            //  alertDialog.setIcon(R.drawable.success);

            // Setting OK Button
            alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    // Write your code here to execute after dialog closed
//                    Toast.makeText(getApplicationContext(), "You clicked on OK", Toast.LENGTH_SHORT).show();
                    alertDialog.dismiss();
                }
            });

            // Showing Alert Message
            alertDialog.show();
            return false;
        }
        return true;
    }

    public boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public void keyBoardHide() {
        final InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);

        if (imm != null && getView() != null)
            imm.hideSoftInputFromWindow(getView().getWindowToken(), 0);
    }

    @Override
    public void onDestroy() {
        //context = null;
        //viewContext = null;
        //prefs = null;
        //pDialog = null;
        //dbHelper = null;
        dismissProgressDialog();
        super.onDestroy();
        callGC();
    }

    public void callGC() {
        System.gc();
        Runtime.getRuntime().gc();
    }

    public boolean hasData(String text) {

        if (text == null || text.trim().length() == 0)
            return false;

        return true;
    }

}
