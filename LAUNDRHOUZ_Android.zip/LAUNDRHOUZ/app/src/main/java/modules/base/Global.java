package modules.base;

/**
 * Created by Om Info on 31-Oct-15.
 */
public class Global {

    public static int positionofselectedbid = -1;

    public static int getPositionofselectedbid() {
        return positionofselectedbid;
    }

    public static void setPositionofselectedbid(int positionofselectedbid) {
        Global.positionofselectedbid = positionofselectedbid;
    }
}

