package modules.base;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;

import modules.bean.UserDetails;

/**
 * Created by ominfowave on 2/6/15.
 */
public class ApplicationPrefs {
    private static ApplicationPrefs prefsT;
    protected Context context;

    public static final String PREF_NAME = "my_clean_bag";
    private static final String USER_DETAIL = "userDetail";
    private static final String USER_ID = "user_id";
    private static final String FIRST_NAME = "fname";
    private static final String LAST_NAME = "lname";
    private static final String EMAIL = "email";
    private static final String EMAIL_VERIFIED_AT = "email_verified_at";
    private static final String MOBILE_NUMBER = "mobile_no";
    private static final String DOB = "dob";
    private static final String GENDER = "gender";
    private static final String USER_IMAGE = "logo";
    private static final String LATITUDE = "latitude";
    private static final String LONGITUDE = "longitude";
    private static final String DEVICE_TYPE = "device_type";
    private static final String DEVICE_ID_1 = "device_id_1";
    private static final String GCM_ID = "gcm_id";
    private static final String USER_ROLE = "user_role";
    private static final String TOCKEN = "token";
    private static final String ACCESS_TOCKEN = "access_token";
    private static final String IS_VERIFY = "is_verify";
    private static final String IS_ACTIVE = "is_active";
    private static final String IS_DELETE = "is_delete";
    private static final String CREATED_AT = "created_at";
    private static final String UPDATE_AT = "updated_at";
    private static final String ADDRESS_ID = "add_id";
    private static final String DEFAULT_ADDRESS_ID = "default_address_id";
    private static final String ADDRESSS = "address";
    private static final String CITY = "city";
    private static final String PINCODE = "pincode";
    private static final String COUNTRY_ID = "country";
    private static final String PROMO_CODE = "promocode";
    private static final String PROMO_CODE_AMOUNT = "promocode_amount";

    private static final String DEFAULT_PAYMENT_ID = "payment_id";
    private static final String PAYMENT_ID = "payment_id";
    private static final String PLAN_ID = "plan_id";
    private static final String PAYMENT_METHOD = "payment_method";
    private static final String PAYMENT_UNIIQ_ID = "payment_uniqid";
    private static final String MY_REFRREL_CODE = "refrel_code";
    private static final String POSTCODE = "postcode";
    private static final String MM_YY = "mm_yy";


    private static final String CITY_ID = "city_id";
    private static final String DELIVERY_CHANGE = "delivery_charge";
    private static final String AREA_NAME = "area_name";
    private static final String AREA_ID = "area_id";

    private static final String USER_NAME = "username";
    private static final String ADDRESS1 = "address_line1";
    private static final String SELECTED_ADDRESS = "selected_address";
    private static final String ADDRESS2 = "address_line2";
    private static final String CURRENT_CURRENCY = "current_currency";
    private static final String USER_TYPE = "user_type";

    private static final String ADDRESS_DETAILS = "address_details";


    private static final String GCM_TOKEN = "gcmtoken";

    private static final String LOGIN_WITH = "login_with";


    private static final String GM_ID = "gm_id";

    private static final String LAST_PRODUCT_UPDATE_DATE = "last_product_update_time";


    public ApplicationPrefs(Context context) {
        this.context = context;
    }

    public static ApplicationPrefs getInstance(Context context) {
        if (prefsT == null) {
            prefsT = new ApplicationPrefs(context);
        }
        return prefsT;
    }


//    =======================================================================

    public boolean isLogin() {
        return getUserId() != null;
    }


    public UserDetails getUserDetail() {
        Gson gson = new Gson();
        return gson.fromJson(getPreferenceData(USER_DETAIL, ""), UserDetails.class);
    }

    public void setUserDetail(UserDetails userDetail) {
        Gson gson = new Gson();
        setPreferencesData(USER_DETAIL, gson.toJson(userDetail));
    }

    public void setUserId(String userId) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(USER_ID, userId);
        editor.commit();
    }

    public String getUserId() {
        return getPrefs().getString(USER_ID, null);
    }

    public void setFirstName(String firstName) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(FIRST_NAME, firstName);
        editor.commit();
    }

    public String getFirstName() {
        return getPrefs().getString(FIRST_NAME, null);
    }

    public void setLastName(String lastName) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(LAST_NAME, lastName);
        editor.commit();
    }

    public String getLastName() {
        return getPrefs().getString(LAST_NAME, null);
    }


    public void setEmail(String userId) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(EMAIL, userId);
        editor.commit();
    }

    public String getEmail() {
        return getPrefs().getString(EMAIL, "");
    }

    public void setEmailVerifiedAt(String emailVerifiedAt) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(EMAIL_VERIFIED_AT, emailVerifiedAt);
        editor.commit();
    }

    public String getEmailVerifiedAt() {
        return getPrefs().getString(EMAIL_VERIFIED_AT, "");
    }

    public void setMobileNumber(String userId) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(MOBILE_NUMBER, userId);
        editor.commit();
    }

    public String getMobileNumber() {
        return getPrefs().getString(MOBILE_NUMBER, "");
    }

    public void setDob(String userId) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(DOB, userId);
        editor.commit();
    }

    public String getDob() {
        return getPrefs().getString(DOB, "");
    }

    public void setGender(String userId) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(GENDER, userId);
        editor.commit();
    }

    public String getGender() {
        return getPrefs().getString(GENDER, "");
    }

    public void setUserImage(String userId) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(USER_IMAGE, userId);
        editor.commit();
    }

    public String getUserImage() {
        return getPrefs().getString(USER_IMAGE, "");
    }

    public void setLatitude(String latitude) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(LATITUDE, latitude);
        editor.commit();
    }

    public String getLatitude() {
        return getPrefs().getString(LATITUDE, "");
    }

    public void setLongitude(String longitude) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(LONGITUDE, longitude);
        editor.commit();
    }

    public String getLongitude() {
        return getPrefs().getString(LONGITUDE, "");
    }

    public void setDeviceType(String deviceType) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(DEVICE_TYPE, deviceType);
        editor.commit();
    }

    public String getDeviceType() {
        return getPrefs().getString(DEVICE_TYPE, "");
    }


    public void setDeviceId1(String deviceId1) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(DEVICE_ID_1, deviceId1);
        editor.commit();
    }

    public String getDeviceId1() {
        return getPrefs().getString(DEVICE_ID_1, "");
    }


    public void setGcmId(String gcmId) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(GCM_ID, gcmId);
        editor.commit();
    }

    public String getGcmId() {
        return getPrefs().getString(GCM_ID, "");
    }


    public void setUserRole(String userRole) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(USER_ROLE, userRole);
        editor.commit();
    }

    public String getUserRole() {
        return getPrefs().getString(USER_ROLE, "");
    }


    public void setTocken(String tocken) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(TOCKEN, tocken);
        editor.commit();
    }

    public String getTocken() {
        return getPrefs().getString(TOCKEN, "");
    }


    public void setAccessTocken(String accessTocken) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(ACCESS_TOCKEN, accessTocken);
        editor.commit();
    }

    public String getAccessTocken() {
        return getPrefs().getString(ACCESS_TOCKEN, "");
    }


    public void setIsVerify(String isVerify) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(IS_VERIFY, isVerify);
        editor.commit();
    }

    public String getIsVerify() {
        return getPrefs().getString(IS_VERIFY, "");
    }


    public void setIsActive(String isActive) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(IS_ACTIVE, isActive);
        editor.commit();
    }

    public String getIsActive() {
        return getPrefs().getString(IS_ACTIVE, "");
    }


    public void setIsDelete(String isDelete) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(IS_DELETE, isDelete);
        editor.commit();
    }

    public String getIsDelete() {
        return getPrefs().getString(IS_DELETE, "");
    }


    public void setCreatedAt(String createdAt) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(CREATED_AT, createdAt);
        editor.commit();
    }

    public String getCreatedAt() {
        return getPrefs().getString(CREATED_AT, "");
    }


    public void setUpdateAt(String updateAt) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(UPDATE_AT, updateAt);
        editor.commit();
    }

    public String getUpdateAt() {
        return getPrefs().getString(UPDATE_AT, "");
    }


    public void setDefaultAddressId(String updateAt) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(DEFAULT_ADDRESS_ID, updateAt);
        editor.commit();
    }

    public String getDefaultAddressId() {
        return getPrefs().getString(DEFAULT_ADDRESS_ID, "");
    }

    public void setAddressId(String addressId) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(ADDRESS_ID, addressId);
        editor.commit();
    }

    public String getAddressId() {
        return getPrefs().getString(ADDRESS_ID, "");
    }


    public void setAddress(String address) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(ADDRESSS, address);
        editor.commit();
    }

    public String getAddress() {
        return getPrefs().getString(ADDRESSS, "");
    }

    public void setCity(String name) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(CITY, name);
        editor.commit();
    }

    public String getCity() {
        return getPrefs().getString(CITY, "");
    }

    public void setPostCode(String pincode) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(PINCODE, pincode);
        editor.commit();
    }

    public String getPostCode() {
        return getPrefs().getString(PINCODE, "");
    }

    public void setCountryId(String country_id) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(COUNTRY_ID, country_id);
        editor.commit();
    }

    public String getCountryId() {
        return getPrefs().getString(COUNTRY_ID, "");
    }

//    -------------------------------------


    public void setDefaultPaymentId(String paymentId) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(DEFAULT_PAYMENT_ID, paymentId);
        editor.commit();
    }

    public String getDefaultPaymentId() {
        return getPrefs().getString(DEFAULT_PAYMENT_ID, "");
    }

    public void setPaymentId(String paymentId) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(PAYMENT_ID, paymentId);
        editor.commit();
    }

    public String getPaymentId() {
        return getPrefs().getString(PAYMENT_ID, "");
    }

    public void setPlanId(String planId) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(PLAN_ID, planId);
        editor.commit();
    }

    public String getPlanId() {
        return getPrefs().getString(PLAN_ID, "");
    }

    public void setPaymentMethod(String paymentMethod) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(PAYMENT_METHOD, paymentMethod);
        editor.commit();
    }

    public String getPaymentMethod() {
        return getPrefs().getString(PAYMENT_METHOD, "");
    }

    public void setPaymentUniiqId(String paymentUniiqId) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(PAYMENT_UNIIQ_ID, paymentUniiqId);
        editor.commit();
    }

    public String getMyRefrrelCode() {
        return getPrefs().getString(MY_REFRREL_CODE, "");
    }

    public void setMyRefrrelCode(String myRefrrelCode) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(MY_REFRREL_CODE, myRefrrelCode);
        editor.commit();
    }

    public String getPaymentUniiqId() {
        return getPrefs().getString(PAYMENT_UNIIQ_ID, "");
    }

    public void setPaymentPostcode(String postcode) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(POSTCODE, postcode);
        editor.commit();
    }

    public String getPaymentPostcode() {
        return getPrefs().getString(POSTCODE, "");
    }

    public void setMmYy(String postcode) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(MM_YY, postcode);
        editor.commit();
    }

    public String getMmYy() {
        return getPrefs().getString(MM_YY, "");
    }


    public boolean isPromocodeApplied() {
        return getPromoCode() != null;
    }

    public boolean isPromocodeAmountApplied() {
        return getPromoCode() != null;
    }

    public void setPromoCode(String promoCode) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(PROMO_CODE, promoCode);
        editor.commit();
    }

    public String getPromoCode() {
        return getPrefs().getString(PROMO_CODE, null);
    }


    public void setPromoCodeAmount(String promoCodeAmount) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(PROMO_CODE_AMOUNT, promoCodeAmount);
        editor.commit();
    }

    public String getPromoCodeAmount() {
        return getPrefs().getString(PROMO_CODE_AMOUNT, null);
    }



    public void setSelectedAddress(String address1) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(SELECTED_ADDRESS, address1);
        editor.commit();
    }

    public String getSelectedAddress() {
        return getPrefs().getString(SELECTED_ADDRESS, "");
    }

//    =======================================================================


    public void setCityId(String cityId) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(CITY_ID, cityId);
        editor.commit();
    }

    public String getCityId() {
        return getPrefs().getString(CITY_ID, null);
    }


    public void setAreaId(String areaid) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(AREA_ID, areaid);
        editor.commit();
    }

    public String getAreaId() {
        return getPrefs().getString(AREA_ID, "");
    }

    public void setAreaName(String areaid) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(AREA_NAME, areaid);
        editor.commit();
    }

    public String getAreaName() {
        return getPrefs().getString(AREA_NAME, "");
    }


    public void setLastProductUpdateDate(String date) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(LAST_PRODUCT_UPDATE_DATE, date);
        editor.commit();
    }

    public String getLastProductUpdateDate() {
        return getPrefs().getString(LAST_PRODUCT_UPDATE_DATE, "2010-01-01 00:00:00");
    }


    public void setUserName(String userId) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(USER_NAME, userId);
        editor.commit();
    }

    public String getUserName() {
        return getPrefs().getString(USER_NAME, "");
    }


    public void setAddress1(String address1) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(ADDRESS1, address1);
        editor.commit();
    }

    public String getAddress1() {
        return getPrefs().getString(ADDRESS1, "");
    }





    public void setAddress2(String address1) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(ADDRESS2, address1);
        editor.commit();
    }

    public String getAddress2() {
        return getPrefs().getString(ADDRESS2, "");
    }

    public void setLoginWith(int login) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putInt(LOGIN_WITH, login);
        editor.commit();
    }

    public int getLoginWith() {
        return getPrefs().getInt(LOGIN_WITH, 0);
    }

    public void setCurrentCurrency(String currency) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(CURRENT_CURRENCY, currency);
        editor.commit();
    }

    public String getCurrentCurrency() {
        return getPrefs().getString(CURRENT_CURRENCY, "USD");
    }

    public void setClientType(String type) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(USER_TYPE, type);
        editor.commit();
    }

    public String getClientType() {
        if (getClientTypeForMenu().equalsIgnoreCase("Dealer")) {
            return "Dealer";
        } else if (getClientTypeForMenu().equalsIgnoreCase("General")) {
            return "General";
        } else {
            return "Admin";
        }
    }

    public String getClientTypeForMenu() {
        return getPrefs().getString(USER_TYPE, "");
    }

    public void setDeliveryChange(float discount) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putFloat(DELIVERY_CHANGE, discount);
        editor.commit();
    }

    public float getDeliveryChange() {
        return getPrefs().getFloat(DELIVERY_CHANGE, 0f);
    }

    public void setGcmToken(String token) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(GCM_TOKEN, token);
        editor.commit();

    }

    public String getGcmToken() {
        return getPrefs().getString(GCM_TOKEN, "");
    }


    /*
     *  getPreferenceData String data from pref
     * */
    private String getPreferenceData(String key, String defaultValue) {
        return getPrefs().getString(key, defaultValue);
    }

    /*
     * Save string data type
     *
     * */
    private void setPreferencesData(String key, String value) {
        SharedPreferences.Editor editor = getPrefsEditor();
        editor.putString(key, value);
        editor.commit();
    }


    public void clearUser() {
        setUserId(null);
        setUserName("");
        setLoginWith(0);
    }

    public void clear() {
    }

    protected SharedPreferences getPrefs() {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    protected SharedPreferences.Editor getPrefsEditor() {
        return getPrefs().edit();
    }
}
