package modules.base;

import android.util.Log;

import com.laundrhouz.android.BuildConfig;


public class LogUtil {

    private static final String TAG = "MyCleanBag";
    private static final String ERROR_RECEIVER_NOT_REGISTERED = "Receiver not registered";
    private static final boolean DEBUG = BuildConfig.DEBUG;
    private static final boolean DEBUG2 = BuildConfig.DEBUG;
    private static final boolean DEBUG_ERROR = BuildConfig.DEBUG;

    public static void debug(String msg) {
        if (DEBUG) {
            Log.d(TAG, msg);
        }
    }

    public static void debug2(Object msg) {
        if (DEBUG2) {
            Log.d(TAG, String.valueOf(msg));
        }
    }

    public static void error(String msg) {
        if (DEBUG_ERROR) {
            Log.e(TAG, msg);
        }
    }

    public static void info(String msg) {
        if (DEBUG) {
            Log.e(TAG, msg);
        }
    }

    public static void error(Exception ex) {

        String msg = ex.getMessage();
        error(msg);

        if (msg != null && msg.contains(ERROR_RECEIVER_NOT_REGISTERED)) {
            return;
        }
        if (DEBUG_ERROR) {
            ex.printStackTrace();
        }
    }
}
