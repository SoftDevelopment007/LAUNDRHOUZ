package modules.base;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.NetworkResponse;
import com.android.volley.ServerError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.laundrhouz.android.R;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import modules.app.MyProgressDialog;
import modules.room_db.AppDatabase;


public class ActivityBase extends AppCompatActivity {

    public Context context;
    public Context viewContext;
    public Animation anim;
    public String currentLocation;
    public ApplicationPrefs prefs;
    public ActionBar actionBar;
    public ImageView imageOverFlow;
    public TextView textViewActivityName;
    public MyProgressDialog pDialog;
    public String filePath = null;
    //    protected DatabaseClient databaseClient;
    protected AppDatabase appDatabase;


    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        StrictMode.setThreadPolicy(
                new StrictMode.ThreadPolicy.Builder()
                        .detectDiskReads()
                        .detectDiskWrites()
                        .detectNetwork()
                        .penaltyLog()
                        .build());
        StrictMode.setVmPolicy(
                new StrictMode.VmPolicy.Builder()
                        .detectLeakedSqlLiteObjects()
                        .penaltyLog()
                        .build());

        enableStrictMode(this);
        super.onCreate(savedInstanceState);
        context = getApplicationContext();
        prefs = ApplicationPrefs.getInstance(context);
//        dbHelper = DBHelper.getInstance(context);
        viewContext = this;
//        databaseClient = DatabaseClient.getInstance(context);
        appDatabase = AppDatabase.getAppDatabase(getApplicationContext());

        initProgressDialog();
        checkPermission();
    }


    private void enableStrictMode(ActivityBase activityBase) {
    }

    public void init() {
    }


    public boolean onUnbind(Intent intent) {
        Log.d(this.getClass().getName(), "UNBIND");
        return true;
    }


    public Map<String, String> getParam() {
        Map<String, String> param = new HashMap<>();
        // param.put("user_id", prefs.getUserId());
        return param;
    }

    @SuppressLint("NewApi")
    public void checkPermission() {
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy =
                    new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
    }

    public boolean isConnectingToInternet() {

        ConnectivityManager connectivity = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity != null) {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null)
                for (int i = 0; i < info.length; i++)
                    if (info[i].getState() == NetworkInfo.State.CONNECTED) {
                        return true;
                    }
        }
        return false;
    }

    public void initProgressDialog() {
        pDialog = new MyProgressDialog(this);
//        pDialog.setMessage("Loading...");
        pDialog.setCancelable(false);
    }

    public void showProgressDialog() {
        if (pDialog != null && !pDialog.isShowing())
            pDialog.show();
    }

    public void dismissProgressDialog() {
        if (pDialog != null && pDialog.isShowing())
            pDialog.dismiss();
    }

    public boolean hashData(String text) {
        return text != null && text.trim().length() > 0;
    }

    public boolean isOnline() {
        ConnectivityManager conMgr = (ConnectivityManager) getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = conMgr.getActiveNetworkInfo();

        if (netInfo == null || !netInfo.isConnected() || !netInfo.isAvailable()) {

            final AlertDialog alertDialog = new AlertDialog.Builder(this).create();

            // Setting Dialog Title
            alertDialog.setTitle("Alert for Connection");

            // Setting Dialog Message
            alertDialog.setMessage("No Internet Connection");

            // Setting Icon to Dialog
            //  alertDialog.setIcon(R.drawable.success);

            // Setting OK Button
            alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    alertDialog.dismiss();
                }
            });

            // Showing Alert Message
            alertDialog.show();
            return false;
        }
        return true;
    }


    public boolean isLocationEnable() {

        LocationManager service = (LocationManager) getSystemService(LOCATION_SERVICE);
        boolean isEnabled = service.isProviderEnabled(LocationManager.GPS_PROVIDER);


        return isEnabled;
    }

    public boolean hasData(String... datas) {

        boolean hasData = true;
        for (String data : datas) {

            if (!hasData(data)) {
                hasData = false;
                break;
            }
        }
        return hasData;
    }

    public boolean hasData(String text) {

        if (text == null || text.length() == 0)
            return false;

        return true;
    }

    public boolean hasData(View view, Animation animation) {

        if (animation == null)
            return false;

        if (view == null)
            return false;

        return true;
    }

    public void startAnimation(TextView textView) {

        if (!hasData(textView, anim))
            return;

        textView.startAnimation(anim);
    }

    public void startAnimation(ImageView imageView) {

        if (!hasData(imageView, anim))
            return;

        imageView.startAnimation(anim);
    }

    public void showMessage(String msg) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    }

    public void showErrorMessage(VolleyError error) {
        dismissProgressDialog();
        if (error.getLocalizedMessage() == null) {
            NetworkResponse response = error.networkResponse;
            if (error instanceof ServerError && response != null) {
                try {
                    String res = new String(response.data,
                            HttpHeaderParser.parseCharset(response.headers, "utf-8"));
                    // Now you can use any deserializer to make sense of data

                    LogUtil.debug("--- " + res.toString());

                } catch (UnsupportedEncodingException e1) {
                    // Couldn't properly decode data to string
                    e1.printStackTrace();
                }
            }
        } else
            LogUtil.debug("--- " + error.getLocalizedMessage());
        Toast.makeText(context, R.string.error_message, Toast.LENGTH_SHORT).show();
    }

    public static final boolean isInternetAvailable(Context context) {
        ConnectivityManager connectivity = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity != null) {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null)
                for (int i = 0; i < info.length; i++)
                    if (info[i].getState() == NetworkInfo.State.CONNECTED) {
                        return true;
                    }

        }
        return false;
    }

    public void hideKeyBoard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        } catch (Exception e) {

        }
    }

    @Override
    protected void onDestroy() {
        dismissProgressDialog();
        context = null;
        viewContext = null;
        currentLocation = null;
        prefs = null;
//        databaseClient = null;
        //  actionBar = null;
        appDatabase = null;
        imageOverFlow = null;
        textViewActivityName = null;
        pDialog = null;
//        dbHelper = null;
        anim = null;
        super.onDestroy();
        callGC();
    }

    public void callGC() {
        System.gc();
        Runtime.getRuntime().gc();
    }
}